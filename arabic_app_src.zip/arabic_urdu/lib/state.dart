import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// صارف کی ترتیبات (تھیم، ہندسے، اسلامی تاریخ میں فرق)۔
class AppSettings extends ChangeNotifier {
  ThemeMode themeMode = ThemeMode.system;
  bool persianDigits = false;
  int hijriAdjust = 0;

  /// آواز کی رفتار (0.5–1.5) اور آواز کی جنس (عورت/مرد) — آن لائن TTS کے لیے۔
  double speechRate = 1.0;
  bool maleVoice = false;
  SharedPreferences? _prefs;

  Future<void> load() async {
    try {
      final p = await SharedPreferences.getInstance();
      _prefs = p;
      final t = p.getString('theme') ?? 'system';
      themeMode = ThemeMode.values
          .firstWhere((m) => m.name == t, orElse: () => ThemeMode.system);
      persianDigits = p.getBool('digits_v2') ?? false;
      hijriAdjust = p.getInt('hijriAdjust') ?? 0;
      speechRate = (p.getDouble('speech_rate') ?? 1.0).clamp(0.5, 1.5);
      maleVoice = p.getBool('speech_male_voice') ?? false;
    } catch (_) {}
  }

  void setThemeMode(ThemeMode m) {
    themeMode = m;
    _prefs?.setString('theme', m.name);
    notifyListeners();
  }

  void setPersianDigits(bool v) {
    persianDigits = v;
    _prefs?.setBool('digits_v2', v);
    notifyListeners();
  }

  void setHijriAdjust(int v) {
    hijriAdjust = v < -2 ? -2 : (v > 2 ? 2 : v);
    _prefs?.setInt('hijriAdjust', hijriAdjust);
    notifyListeners();
  }

  void setSpeechRate(double v) {
    speechRate = v.clamp(0.5, 1.5);
    _prefs?.setDouble('speech_rate', speechRate);
    notifyListeners();
  }

  void setMaleVoice(bool v) {
    maleVoice = v;
    _prefs?.setBool('speech_male_voice', v);
    notifyListeners();
  }
}

final AppSettings settings = AppSettings();
