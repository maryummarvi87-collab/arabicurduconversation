/// ایپ کی بنیادی ترتیبات۔
class AppConfig {
  static const String appName = 'عربی اُردو بول چال';

  /// ایپ کا لنک (پلے اسٹور یا اپنی ویب سائٹ)۔ ہر شیئر کے ساتھ یہی لنک جاتا ہے۔
  static const String appLink = 'https://maryummarvi87-collab.github.io/arabicurduconversation/';

  /// وہ پیغام جو "ایپ شیئر کریں" کے ساتھ جاتا ہے۔
  static const String shareMessage =
      'عربی بول چال اردو کے ذریعے سیکھیں: اسباق، گرامر، کہانیاں، لغت، قرآن و احادیث اور کیلنڈر۔ ایپ یہاں سے حاصل کریں:';

  /// آن لائن اپڈیٹ کے لیے content.json کا لنک (ویب سائٹ، GitHub Pages وغیرہ)۔
  static const String contentUrl = 'https://maryummarvi87-collab.github.io/arabicurduconversation/content.json';

  /// تصحیح و اضافہ کی تجاویز اس ای میل پر آئیں گی۔
  static const String feedbackEmail = 'example@example.com';

  /// اگر آپ کے پاس سرور ہے جو تجاویز JSON کی صورت میں لیتا ہے تو اس کا لنک دیں،
  /// ورنہ خالی چھوڑ دیں اور ای میل استعمال ہوگی۔
  static const String feedbackPostUrl = '';
}
