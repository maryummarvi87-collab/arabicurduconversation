/// عربی متن کا رومن (نقرحرفی) نظام — Ayesh کی ہدایت کے مطابق تنوین کا صحیح نظام:
///
///   تنوین فتح  ً (U+064B) → **an**   (كِتَابًا = kitāban)
///   تنوین ضم   ٌ (U+064C) → **un**   (كِتَابٌ = kitābun)
///   تنوین کسر  ٍ (U+064D) → **in**   (كِتَابٍ = kitābin)
///   شدّہ (U+0651) حرف کو دوگنا کرتا ہے: إِنَّ = **inna**، أَنَّ = **anna**
///
/// یہ خالص Dart فنکشن ہے (کوئی Flutter انحصار نہیں) تاکہ اسے الگ بھی جانچا جا سکے۔
library;

// اعراب و علامات
const String _fathatan = 'ً'; // ً
const String _dammatan = 'ٌ'; // ٌ
const String _kasratan = 'ٍ'; // ٍ
const String _fatha = 'َ'; // َ
const String _damma = 'ُ'; // ُ
const String _kasra = 'ِ'; // ِ
const String _shadda = 'ّ'; // ّ
const String _supAlif = 'ٰ'; // ٰ (چھوٹی الف، مثلاً رَحْمٰن)
const String _tatweel = 'ـ';

bool _isMark(String c) {
  final r = c.runes.first;
  return (r >= 0x064B && r <= 0x0652) || r == 0x0670 || r == 0x0640;
}

/// ایک حرف + اس کے اعراب
class _Seg {
  final String letter;
  String vowel = ''; // a / i / u
  String tanwin = ''; // an / un / in
  bool shadda = false;
  bool supAlif = false;
  _Seg(this.letter);
}

const Map<String, String> _cons = {
  'ب': 'b', 'ت': 't', 'ث': 'th', 'ج': 'j', 'ح': 'ḥ', 'خ': 'kh',
  'د': 'd', 'ذ': 'dh', 'ر': 'r', 'ز': 'z', 'س': 's', 'ش': 'sh',
  'ص': 'ṣ', 'ض': 'ḍ', 'ط': 'ṭ', 'ظ': 'ẓ', 'ع': 'ʿ', 'غ': 'gh',
  'ف': 'f', 'ق': 'q', 'ك': 'k', 'ل': 'l', 'م': 'm', 'ن': 'n',
  'ه': 'h', 'ة': 'a', // ة الگ سے نیچے سنبھالی جاتی ہے
};

const Set<String> _sun = {
  'ت', 'ث', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص', 'ض', 'ط', 'ظ', 'ل', 'ن'
};

List<_Seg> _segments(String word) {
  final segs = <_Seg>[];
  for (final r in word.runes) {
    final c = String.fromCharCode(r);
    if (c == _tatweel) continue;
    if (_isMark(c)) {
      if (segs.isEmpty) continue;
      final s = segs.last;
      switch (c) {
        case _fatha:
          s.vowel = 'a';
          break;
        case _damma:
          s.vowel = 'u';
          break;
        case _kasra:
          s.vowel = 'i';
          break;
        case _fathatan:
          s.tanwin = 'an';
          break;
        case _dammatan:
          s.tanwin = 'un';
          break;
        case _kasratan:
          s.tanwin = 'in';
          break;
        case _shadda:
          s.shadda = true;
          break;
        case _supAlif:
          s.supAlif = true;
          break;
        default:
          break; // سکون وغیرہ: کوئی آواز نہیں
      }
    } else {
      segs.add(_Seg(c));
    }
  }
  return segs;
}

String _romanWord(String word) {
  if (word.isEmpty) return word;
  final segs = _segments(word);
  if (segs.isEmpty) return word;

  // اللہ کی خاص صورتیں
  final stripped = segs.map((s) => s.letter).join();
  const allahForms = {
    'الله': 'allāh',
    'لله': 'lillāh',
    'بالله': 'billāh',
    'والله': 'wallāh',
    'تالله': 'tallāh',
  };
  final af = allahForms[stripped];
  if (af != null && segs.every((s) => s.tanwin.isEmpty)) return af;

  final out = StringBuffer();
  var i = 0;
  var noDoubleAt = -1; // اس نمبر والے حرف کی شدّہ دوگنا نہ ہو (لام تعریف کی شمسی ادغام پہلے سے حساب میں ہے)
  String prevVowel = ''; // پچھلے حرف کی سادہ حرکت (مد کے لیے)

  // لام تعریف (ال) — لفظ کے شروع میں یا درمیان میں (مثلاً بِالْكِتَابِ)
  bool isArticleAt(int idx) {
    if (idx + 2 > segs.length - 1) return false;
    final a = segs[idx], l = segs[idx + 1];
    return (a.letter == 'ا' || a.letter == 'ٱ') &&
        a.vowel.isEmpty &&
        a.tanwin.isEmpty &&
        !a.shadda &&
        l.letter == 'ل';
  }

  void emitArticle(int idx) {
    final next = segs[idx + 2];
    if (_sun.contains(next.letter)) {
      out.write('a${_cons[next.letter] ?? next.letter}-');
      if (next.shadda) noDoubleAt = idx + 2;
    } else {
      out.write('al-');
    }
  }

  while (i < segs.length) {
    final s = segs[i];
    final ch = s.letter;

    // --- لام تعریف ---
    if ((ch == 'ا' || ch == 'ٱ') &&
        s.vowel.isEmpty &&
        s.tanwin.isEmpty &&
        isArticleAt(i)) {
      emitArticle(i);
      i += 2; // ا اور ل چھوڑ دو؛ اگلا حرف معمول سے لکھا جائے گا
      prevVowel = '';
      continue;
    }

    // --- مدّہ کی ادغام: متحرک حرف + اسی جنس کا خاموش حرفِ مد (تَا = tā، بُو = bū، بِي = bī) ---
    if (s.tanwin.isEmpty && s.vowel.isNotEmpty && i + 1 < segs.length) {
      final nxt = segs[i + 1];
      final bare = nxt.vowel.isEmpty &&
          nxt.tanwin.isEmpty &&
          !nxt.shadda &&
          !nxt.supAlif;
      String? longV;
      if (bare) {
        if (s.vowel == 'a' && (nxt.letter == 'ا' || nxt.letter == 'ٱ')) {
          longV = 'ā';
        } else if (s.vowel == 'u' && nxt.letter == 'و') {
          longV = 'ū';
        } else if (s.vowel == 'i' && nxt.letter == 'ي') {
          longV = 'ī';
        }
      }
      String? base;
      if (_cons.containsKey(ch) && ch != 'ة') {
        base = (s.shadda && i != noDoubleAt)
            ? '${_cons[ch]}${_cons[ch]}'
            : _cons[ch];
      } else if (ch == 'و') {
        base = s.shadda ? 'ww' : 'w';
      } else if (ch == 'ي') {
        base = s.shadda ? 'yy' : 'y';
      } else if (ch == 'أ' || ch == 'إ' || ch == 'ء' || ch == 'ئ' || ch == 'ؤ') {
        base = i == 0 ? '' : 'ʾ';
      }
      if (longV != null && base != null) {
        out.write('$base$longV');
        prevVowel = '';
        i += 2;
        continue;
      }
    }

    // --- الف ---
    if (ch == 'ا' || ch == 'ٱ') {
      final prevTanwin = i > 0 && segs[i - 1].tanwin.isNotEmpty;
      if (prevTanwin) {
        // تنوین فتح کی خاموش الف (كِتَابًا) — کچھ نہ لکھو
      } else if (s.tanwin.isNotEmpty) {
        out.write(s.tanwin);
      } else if (s.vowel.isNotEmpty) {
        out.write(s.vowel);
      } else if (s.supAlif) {
        out.write('ā');
      } else if (i == 0) {
        out.write('a');
      } else {
        out.write('ā');
      }
      prevVowel = '';
      i++;
      continue;
    }

    // --- آ (مدّہ) ---
    if (ch == 'آ') {
      out.write('ā');
      if (s.tanwin.isNotEmpty) out.write(s.tanwin);
      prevVowel = '';
      i++;
      continue;
    }

    // --- الف مقصورہ ---
    if (ch == 'ى') {
      final prevTanwin = i > 0 && segs[i - 1].tanwin.isNotEmpty;
      if (prevTanwin) {
        // هُدًى = hudan — تنوین کے بعد ى خاموش ہے
      } else if (s.tanwin.isNotEmpty) {
        out.write(s.tanwin);
      } else {
        out.write('ā');
        if (s.vowel.isNotEmpty) out.write(s.vowel);
      }
      prevVowel = '';
      i++;
      continue;
    }

    // --- تاء مربوطہ ---
    if (ch == 'ة') {
      if (s.tanwin.isNotEmpty) {
        out.write('t${s.tanwin}'); // كَلِمَةً = kalimatan، كِتَابَةً = kitābatan
      } else {
        // اعراب دار متن میں ة کی آواز پچھلے حرف کی حرکت میں شامل ہے
        // (كِتَابَة = kitāba)؛ صرف تب 'a' جب لفظ میں کہیں اور کوئی حرکت نہ ہو
        final anyVowelBefore =
            segs.take(i).any((x) => x.vowel.isNotEmpty || x.tanwin.isNotEmpty);
        if (!anyVowelBefore && s.vowel.isEmpty) out.write('a');
      }
      prevVowel = '';
      i++;
      continue;
    }

    // --- ہمزہ والی صورتیں ---
    if (ch == 'أ' || ch == 'إ' || ch == 'ء' || ch == 'ئ' || ch == 'ؤ') {
      final v = s.vowel.isNotEmpty
          ? s.vowel
          : (ch == 'إ' ? 'i' : (s.tanwin.isNotEmpty ? '' : 'a'));
      if (i == 0) {
        // لفظ کے شروع میں ہمزہ رومن میں نہیں لکھا جاتا: أَنَّ = anna، إِنَّ = inna
        out.write(v);
      } else {
        out.write('ʾ$v');
      }
      if (s.tanwin.isNotEmpty) out.write(s.tanwin);
      prevVowel = s.vowel;
      i++;
      continue;
    }

    // --- واؤ ---
    if (ch == 'و') {
      if (s.tanwin.isNotEmpty || s.vowel.isNotEmpty || s.shadda) {
        out.write(s.shadda ? 'ww' : 'w');
        out.write(s.tanwin.isNotEmpty ? s.tanwin : s.vowel);
        prevVowel = s.vowel;
      } else if (s.supAlif) {
        out.write('wā');
        prevVowel = '';
      } else if (prevVowel == 'u') {
        out.write('ū'); // مدّہ: بَعْدُ + و = ū
        prevVowel = '';
      } else {
        out.write('w');
        prevVowel = '';
      }
      i++;
      continue;
    }

    // --- یاء ---
    if (ch == 'ي') {
      if (s.tanwin.isNotEmpty || s.vowel.isNotEmpty || s.shadda) {
        out.write(s.shadda ? 'yy' : 'y');
        out.write(s.tanwin.isNotEmpty ? s.tanwin : s.vowel);
        prevVowel = s.vowel;
      } else if (s.supAlif) {
        out.write('yā');
        prevVowel = '';
      } else if (prevVowel == 'i') {
        out.write('ī');
        prevVowel = '';
      } else {
        out.write('y');
        prevVowel = '';
      }
      i++;
      continue;
    }

    // --- عام حروف ---
    final base = _cons[ch];
    if (base != null) {
      final dbl = s.shadda && i != noDoubleAt;
      out.write(dbl ? '$base$base' : base);
      if (s.tanwin.isNotEmpty) {
        out.write(s.tanwin);
      } else if (s.supAlif) {
        out.write('ā');
      } else {
        out.write(s.vowel);
      }
      prevVowel = s.vowel;
      i++;
      continue;
    }

    // --- غیر عربی حروف (نشانات، ہندسے وغیرہ) ---
    if (ch == '؟') {
      out.write('?');
    } else if (ch == '،') {
      out.write(',');
    } else {
      out.write(ch);
    }
    prevVowel = '';
    i++;
  }
  return out.toString();
}

/// عربی متن کو رومن میں بدلو۔ تنوین: ً→an، ٌ→un، ٍ→in؛ شدّہ حرف دوگنا۔
/// مثالیں: كِتَابًا → kitāban، كِتَابٌ → kitābun، كِتَابٍ → kitābin،
/// إِنَّ → inna، أَنَّ → anna۔
String romanizeArabic(String input) {
  if (input.trim().isEmpty) return '';
  return input.split(' ').map(_romanWord).join(' ');
}
