import '../state.dart';

const String _faDigits = '۰۱۲۳۴۵۶۷۸۹';
const String _arDigits = '٠١٢٣٤٥٦٧٨٩';

/// فارسی/عربی ہندسوں کو انگریزی ہندسوں میں بدلتا ہے۔
String toLatinDigits(String s) {
  final b = StringBuffer();
  for (final r in s.runes) {
    final c = String.fromCharCode(r);
    var i = _faDigits.indexOf(c);
    if (i < 0) i = _arDigits.indexOf(c);
    b.write(i >= 0 ? '$i' : c);
  }
  return b.toString();
}

/// ترتیبات کے مطابق ہندسے دکھاتا ہے (۱۲۳ یا 123)۔
String localDigits(Object n) {
  final s = '$n';
  if (!settings.persianDigits) return s;
  final b = StringBuffer();
  for (final ch in s.split('')) {
    final i = int.tryParse(ch);
    b.write(i == null ? ch : _faDigits[i]);
  }
  return b.toString();
}

String two(int n) => n < 10 ? '0$n' : '$n';

const Map<String, String> _letterMap = {
  'ي': 'ی', 'ى': 'ی', 'ې': 'ی', 'ے': 'ی', 'ۓ': 'ی', 'ئ': 'ی',
  'ك': 'ک', 'ڪ': 'ک',
  'ہ': 'ه', 'ھ': 'ه', 'ة': 'ه', 'ۀ': 'ه', 'ۂ': 'ه', 'ۃ': 'ه',
  'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا',
  'ؤ': 'و',
  'ٹ': 'ت', 'ڈ': 'د', 'ڑ': 'ر', 'ں': 'ن',
};

final RegExp _strip = RegExp('[ً-ٰٟـ‌‍‎‏]');

/// تلاش کے لیے متن کو یکساں بناتا ہے: اردو اور فارسی کے ملتے جلتے حروف
/// (ی/ي/ے، ک/ك، ه/ہ/ھ)، اعراب، ZWNJ اور ہندسے ایک ہی شکل میں آ جاتے ہیں۔
String normalize(String input) {
  var s = toLatinDigits(input.toLowerCase()).replaceAll(_strip, '');
  final b = StringBuffer();
  for (final ch in s.split('')) {
    b.write(_letterMap[ch] ?? ch);
  }
  return b.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
}
