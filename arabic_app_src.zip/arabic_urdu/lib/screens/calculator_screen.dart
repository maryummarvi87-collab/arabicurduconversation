import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme.dart';

// ============================ جائزہ کار (parser) ============================

typedef _Fn = double Function(double x);

class _Parser {
  final String s;
  int pos = 0;
  final bool degrees;
  _Parser(String src, {this.degrees = true})
      : s = src
            .replaceAll('×', '*')
            .replaceAll('÷', '/')
            .replaceAll('−', '-')
            .replaceAll(' ', '');

  String? get _peek => pos < s.length ? s[pos] : null;

  _Fn parse() {
    final f = _expr();
    if (pos != s.length) throw const FormatException('اضافی حروف');
    return f;
  }

  _Fn _expr() {
    var f = _term();
    while (_peek == '+' || _peek == '-') {
      final op = s[pos++];
      final g = _term();
      final ff = f;
      f = op == '+' ? (x) => ff(x) + g(x) : (x) => ff(x) - g(x);
    }
    return f;
  }

  _Fn _term() {
    var f = _factor();
    while (true) {
      final c = _peek;
      if (c == '*' || c == '/') {
        pos++;
        final g = _factor();
        final ff = f;
        f = c == '*' ? (x) => ff(x) * g(x) : (x) => ff(x) / g(x);
      } else if (c != null &&
          (RegExp(r'[0-9.(√πa-zA-Z]').hasMatch(c))) {
        // مضمر ضرب: 2x، 3(x+1)، (x+1)(x-1)
        final g = _factor();
        final ff = f;
        f = (x) => ff(x) * g(x);
      } else {
        break;
      }
    }
    return f;
  }

  _Fn _factor() {
    final base = _unary();
    if (_peek == '^') {
      pos++;
      final exp = _factor();
      return (x) => math.pow(base(x), exp(x)).toDouble();
    }
    return base;
  }

  _Fn _unary() {
    if (_peek == '-') {
      pos++;
      final f = _unary();
      return (x) => -f(x);
    }
    if (_peek == '+') {
      pos++;
      return _unary();
    }
    return _postfix();
  }

  _Fn _postfix() {
    var f = _primary();
    while (true) {
      if (_peek == '!') {
        pos++;
        final ff = f;
        f = (x) => _factorial(ff(x));
      } else if (_peek == '%') {
        pos++;
        final ff = f;
        f = (x) => ff(x) / 100;
      } else if (_peek == '²') {
        pos++;
        final ff = f;
        f = (x) => ff(x) * ff(x);
      } else {
        break;
      }
    }
    return f;
  }

  double _factorial(double v) {
    if (v < 0 || v != v.roundToDouble() || v > 170) {
      throw const FormatException('فیکٹوریل صرف صحیح عدد پر');
    }
    var r = 1.0;
    for (var i = 2; i <= v.toInt(); i++) {
      r *= i;
    }
    return r;
  }

  _Fn _primary() {
    final c = _peek;
    if (c == null) throw const FormatException('نامکمل');
    if (c == '(') {
      pos++;
      final f = _expr();
      if (_peek != ')') throw const FormatException('قوس بند نہیں');
      pos++;
      return f;
    }
    if (c == '√') {
      pos++;
      final f = _primary();
      return (x) => math.sqrt(f(x));
    }
    if (RegExp(r'[0-9.]').hasMatch(c)) {
      final start = pos;
      while (pos < s.length && RegExp(r'[0-9.]').hasMatch(s[pos])) {
        pos++;
      }
      final v = double.tryParse(s.substring(start, pos));
      if (v == null) throw const FormatException('عدد درست نہیں');
      return (_) => v;
    }
    if (RegExp(r'[a-zA-Z]').hasMatch(c)) {
      final start = pos;
      while (pos < s.length && RegExp(r'[a-zA-Z]').hasMatch(s[pos])) {
        pos++;
      }
      final name = s.substring(start, pos);
      switch (name) {
        case 'x':
          return (x) => x;
        case 'e':
          return (_) => math.e;
        case 'sin':
        case 'cos':
        case 'tan':
        case 'ln':
        case 'log':
          if (_peek != '(') throw const FormatException('فنکشن کے بعد ( چاہیے');
          pos++;
          final inner = _expr();
          if (_peek != ')') throw const FormatException('قوس بند نہیں');
          pos++;
          final conv = degrees ? (math.pi / 180) : 1.0;
          switch (name) {
            case 'sin':
              return (x) => math.sin(inner(x) * conv);
            case 'cos':
              return (x) => math.cos(inner(x) * conv);
            case 'tan':
              return (x) => math.tan(inner(x) * conv);
            case 'ln':
              return (x) => math.log(inner(x));
            default:
              return (x) => math.log(inner(x)) / math.ln10;
          }
      }
      throw FormatException('نامعلوم نام: $name');
    }
    if (c == 'π') {
      pos++;
      return (_) => math.pi;
    }
    throw FormatException('غیر متوقع حرف: $c');
  }
}

double _eval(String expr, {double x = 0, bool degrees = true}) =>
    _Parser(expr, degrees: degrees).parse()(x);

String _fmt(double v) {
  if (v.isNaN) return '—';
  if (v.isInfinite) return v > 0 ? '∞' : '-∞';
  if (v == v.roundToDouble() && v.abs() < 1e15) return '${v.toInt()}';
  var s = v.toStringAsFixed(6);
  s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  return s;
}

// ============================ اسکرین ============================

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});
  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _expr = '';
  String _result = '';
  String _steps = '';
  bool _degrees = true;

  void _add(String t) => setState(() {
        _expr += t;
        _steps = '';
      });

  void _backspace() => setState(() {
        if (_expr.isNotEmpty) {
          // فنکشن کے نام اکٹھے مٹائیں
          for (final fn in ['sin(', 'cos(', 'tan(', 'ln(', 'log(', '√(']) {
            if (_expr.endsWith(fn)) {
              _expr = _expr.substring(0, _expr.length - fn.length);
              return;
            }
          }
          _expr = _expr.substring(0, _expr.length - 1);
        }
      });

  void _clear() => setState(() {
        _expr = '';
        _result = '';
        _steps = '';
      });

  void _toggleSign() => setState(() {
        if (_expr.startsWith('-(') && _expr.endsWith(')')) {
          _expr = _expr.substring(2, _expr.length - 1);
        } else if (_expr.isNotEmpty) {
          _expr = '-($_expr)';
        }
      });

  void _reciprocal() => setState(() {
        if (_expr.isNotEmpty) _expr = '1/($_expr)';
      });

  void _calculate() {
    final src = _expr.trim();
    if (src.isEmpty) return;
    try {
      if (src.contains('=')) {
        _solveEquation(src);
      } else if (src.contains('x')) {
        setState(() {
          _result = '';
          _steps = 'x کی قدر معلوم کرنے کے لیے مساوات لکھیں، مثلاً: 2x+4=10 یا x^2-5x+6=0';
        });
      } else {
        final v = _eval(src, degrees: _degrees);
        setState(() {
          _result = _fmt(v);
          _steps = '';
        });
      }
    } on FormatException catch (e) {
      setState(() {
        _result = '';
        _steps = 'حساب درست نہیں: ${e.message}';
      });
    } catch (_) {
      setState(() {
        _result = '';
        _steps = 'حساب درست نہیں — اظہار جانچ کر دوبارہ کوشش کریں۔';
      });
    }
  }

  void _solveEquation(String src) {
    final parts = src.split('=');
    if (parts.length != 2 || parts[0].isEmpty || parts[1].isEmpty) {
      throw const FormatException('مساوات میں ایک ہی = ہونا چاہیے');
    }
    final lf = _Parser(parts[0], degrees: _degrees).parse();
    final rf = _Parser(parts[1], degrees: _degrees).parse();
    double f(double t) => lf(t) - rf(t);
    final c = f(0), f1 = f(1), fm1 = f(-1);
    final b = (f1 - fm1) / 2;
    final a = (f1 + fm1) / 2 - c;
    const eps = 1e-9;
    final check2 = (f(2) - (4 * a + 2 * b + c)).abs();
    final check3 = (f(3) - (9 * a + 3 * b + c)).abs();
    final isPoly = check2 < 1e-6 && check3 < 1e-6;

    if (!isPoly) {
      // عددی طریقہ: وقفے میں جڑ تلاش کرو
      final roots = <double>[];
      var prevT = -100.0, prevV = f(-100);
      for (var t = -99.75; t <= 100.0; t += 0.25) {
        final v = f(t);
        if (v == 0) roots.add(t);
        if (prevV.isFinite && v.isFinite && prevV * v < 0) {
          var lo = prevT, hi = t, vlo = prevV;
          for (var i = 0; i < 60; i++) {
            final mid = (lo + hi) / 2;
            final vm = f(mid);
            if (vlo * vm <= 0) {
              hi = mid;
            } else {
              lo = mid;
              vlo = vm;
            }
          }
          roots.add((lo + hi) / 2);
        }
        prevT = t;
        prevV = v;
      }
      setState(() {
        if (roots.isEmpty) {
          _result = '';
          _steps = 'اس مساوات کی (قریبی) جڑ نہیں مل سکی۔ خطی یا دو درجی مساوات آزمائیں، مثلاً: x^2-5*x+6=0';
        } else {
          _result = roots.map((r) => 'x = ${_fmt(r)}').join('   •   ');
          _steps = 'یہ مساوات سادہ خطی/دو درجی شکل میں نہیں تھی؛ جواب عددی طریقے سے نکالا گیا ہے۔';
        }
      });
      return;
    }

    String form;
    if (a.abs() > eps) {
      form = '${_fmt(a)}x² ${_signNum(b)}x ${_signNum(c)} = 0';
    } else {
      form = '${_fmt(b)}x ${_signNum(c)} = 0';
    }
    if (a.abs() <= eps && b.abs() <= eps) {
      setState(() {
        _result = '';
        _steps = c.abs() <= eps
            ? 'یہ مساوات ہر x کے لیے درست ہے (لامتناہی حل)۔'
            : 'اس مساوات کا کوئی حل نہیں۔';
      });
      return;
    }
    if (a.abs() <= eps) {
      final x = -c / b;
      setState(() {
        _result = 'x = ${_fmt(x)}';
        _steps = 'معیاری شکل: $form\n'
            'یہ خطی مساوات ہے: x = −(${_fmt(c)}) ÷ (${_fmt(b)}) = ${_fmt(x)}';
      });
      return;
    }
    final d = b * b - 4 * a * c;
    if (d < -eps) {
      setState(() {
        _result = '';
        _steps = 'معیاری شکل: $form\n'
            'ممیز (b² − 4ac) = ${_fmt(d)} — منفی ہے، اس لیے حقیقی حل موجود نہیں۔';
      });
    } else if (d.abs() <= eps) {
      final x = -b / (2 * a);
      setState(() {
        _result = 'x = ${_fmt(x)}';
        _steps = 'معیاری شکل: $form\n'
            'ممیز (b² − 4ac) = 0، اس لیے ایک ہی حل: x = −b ÷ 2a = ${_fmt(x)}';
      });
    } else {
      final sq = math.sqrt(d);
      final x1 = (-b + sq) / (2 * a);
      final x2 = (-b - sq) / (2 * a);
      setState(() {
        _result = 'x₁ = ${_fmt(x1)}   •   x₂ = ${_fmt(x2)}';
        _steps = 'معیاری شکل: $form\n'
            'ممیز (b² − 4ac) = ${_fmt(d)}، √ممیز = ${_fmt(sq)}\n'
            'x = (−b ± √ممیز) ÷ 2a سے دونوں حل نکلے۔';
      });
    }
  }

  String _signNum(double v) => v < 0 ? '− ${_fmt(-v)}' : '+ ${_fmt(v)}';

  // ------------------------- UI -------------------------

  Widget _btn(String label, VoidCallback onTap,
      {Color? bg, Color? fg, double size = 20, int flex = 1}) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    return Expanded(
      flex: flex,
      child: Padding(
        padding: const EdgeInsets.all(3),
        child: Material(
          color: bg ?? (dark ? const Color(0xFF2A2A35) : const Color(0xFFF1F1F6)),
          borderRadius: BorderRadius.circular(14),
          child: InkWell(
            borderRadius: BorderRadius.circular(14),
            onTap: onTap,
            child: Container(
              height: 52,
              alignment: Alignment.center,
              child: Text(label,
                  textDirection: TextDirection.ltr,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: size,
                      fontWeight: FontWeight.w700,
                      color: fg ??
                          (dark ? Colors.white : const Color(0xFF10243E)))),
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final blue = dark ? const Color(0xFF82B1FF) : const Color(0xFF1565C0);
    const yellow = Color(0xFFFFD740);
    final opBg = dark ? const Color(0xFF3A3A28) : const Color(0xFFFFF3C4);

    return Scaffold(
      appBar: AppBar(title: const Text('کیلکولیٹر')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          // اظہار و نتیجہ
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: cardFill(context),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: blue.withAlpha(90)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(_expr.isEmpty ? 'حساب لکھیں…' : _expr,
                    textAlign: TextAlign.left,
                    textDirection: TextDirection.ltr,
                    style: TextStyle(
                        fontSize: 26,
                        fontWeight: FontWeight.w700,
                        color: _expr.isEmpty
                            ? (dark ? Colors.white54 : Colors.black45)
                            : (dark ? Colors.white : const Color(0xFF10243E)))),
                if (_result.isNotEmpty) ...[
                  const SizedBox(height: 6),
                  Text('= $_result',
                      textAlign: TextAlign.left,
                      textDirection: TextDirection.ltr,
                      style: TextStyle(
                          fontSize: 30,
                          fontWeight: FontWeight.w900,
                          color: dark ? yellow : const Color(0xFF1565C0))),
                ],
                if (_steps.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(_steps, style: urStyle(size: 14.5)),
                ],
              ],
            ),
          ),
          const SizedBox(height: 8),
          // زاویے کی اکائی — اپنی الگ صف
          Row(
            children: [
              ChoiceChip(
                label: const Text('درجہ (DEG)'),
                selected: _degrees,
                onSelected: (_) => setState(() => _degrees = true),
              ),
              const SizedBox(width: 8),
              ChoiceChip(
                label: const Text('ریڈین (RAD)'),
                selected: !_degrees,
                onSelected: (_) => setState(() => _degrees = false),
              ),
            ],
          ),
          const SizedBox(height: 6),
          // مختصر جملہ — ٹوگل سے الگ اپنی سطر میں
          Text('x والی مساوات بھی حل ہوتی ہے۔', style: urStyle(size: 12.5)),
          const SizedBox(height: 6),
          // سائنسی صف
          Row(children: [
            _btn('sin', () => _add('sin('), bg: opBg, size: 16),
            _btn('cos', () => _add('cos('), bg: opBg, size: 16),
            _btn('tan', () => _add('tan('), bg: opBg, size: 16),
            _btn('√', () => _add('√('), bg: opBg),
            _btn('x²', () => _add('²'), bg: opBg, size: 17),
          ]),
          Row(children: [
            _btn('ln', () => _add('ln('), bg: opBg, size: 16),
            _btn('log', () => _add('log('), bg: opBg, size: 16),
            _btn('π', () => _add('π'), bg: opBg),
            _btn('e', () => _add('e'), bg: opBg),
            _btn('n!', () => _add('!'), bg: opBg, size: 17),
          ]),
          Row(children: [
            _btn('(', () => _add('('), bg: opBg),
            _btn(')', () => _add(')'), bg: opBg),
            _btn('x^y', () => _add('^'), bg: opBg, size: 16),
            _btn('1/x', _reciprocal, bg: opBg, size: 16),
            _btn('x', () => _add('x'), bg: opBg),
          ]),
          // عددی پیڈ
          Row(children: [
            _btn('C', _clear, bg: const Color(0xFFB3261E), fg: Colors.white),
            _btn('⌫', _backspace, bg: opBg),
            _btn('%', () => _add('%'), bg: opBg),
            _btn('÷', () => _add('÷'), bg: opBg),
          ]),
          Row(children: [
            _btn('7', () => _add('7')),
            _btn('8', () => _add('8')),
            _btn('9', () => _add('9')),
            _btn('×', () => _add('×'), bg: opBg),
          ]),
          Row(children: [
            _btn('4', () => _add('4')),
            _btn('5', () => _add('5')),
            _btn('6', () => _add('6')),
            _btn('−', () => _add('-'), bg: opBg),
          ]),
          Row(children: [
            _btn('1', () => _add('1')),
            _btn('2', () => _add('2')),
            _btn('3', () => _add('3')),
            _btn('+', () => _add('+'), bg: opBg),
          ]),
          Row(children: [
            _btn('±', _toggleSign, bg: opBg),
            _btn('0', () => _add('0')),
            _btn('.', () => _add('.')),
            _btn('=', _calculate,
                bg: const Color(0xFF1565C0), fg: Colors.white),
          ]),
          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

