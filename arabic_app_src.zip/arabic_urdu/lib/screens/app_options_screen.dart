import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../data/repository.dart';
import '../state.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';
import 'feedback_screen.dart';
import 'update_screen.dart';

const _featuresUr = [
  'عربی کے اسباق',
  'مکمل عربی اُردو اور اُردو عربی لغت',
  'مکمل عربی گرامر (نحو و صرف)',
  'مضامین',
  'مصادر اور گردانیں',
  'جملے',
  'بول چال',
  'قرآن و احادیث',
  'اسباق شاعری',
  'آن لائن اپڈیٹ',
];

const _featuresEn = [
  'Arabic lessons',
  'Complete Arabic–Urdu and Urdu–Arabic dictionary',
  'Complete Arabic grammar (syntax and morphology)',
  'Essays',
  'Infinitives and conjugations',
  'Sentences',
  'Conversation',
  'Quran and Hadith',
  'Poetry lessons',
  'Online update',
];

const _featuresFa = [
  'دروس اللغة العربية',
  'قاموس كامل عربي ـ أردو وأردو ـ عربي',
  'قواعد كاملة للغة العربية (النحو والصرف)',
  'مقاله‌ها',
  'مصدرها و صرف فعل‌ها',
  'جمله‌ها',
  'گفت‌وگو',
  'القرآن والأحاديث',
  'درس‌های شعر',
  'به‌روزرسانی آنلاین',
];

/// ایپ کے آپشنز: ترتیبات، مواد کی معلومات اور ایپ سے متعلق کارروائیاں ایک جگہ
class AppOptionsScreen extends StatelessWidget {
  const AppOptionsScreen({super.key});

  Future<void> _openWebsite(BuildContext context) async {
    final ok = await launchUrl(Uri.parse(AppConfig.appLink),
        mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) showSnack(context, 'ویب سائٹ نہیں کھل سکی');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('ایپ کے بارے میں')),
      body: ListenableBuilder(
        listenable: settings,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
          children: [
            _sectionTitle(context, 'ترتیبات'),
            _card(
              context,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
                  child: Text('ایپ کا انداز (تھیم)',
                      style: TextStyle(color: cs.outline)),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
                  child: SegmentedButton<ThemeMode>(
                    segments: const [
                      ButtonSegment(
                          value: ThemeMode.light,
                          label: Text('روشن'),
                          icon: Icon(Icons.light_mode_rounded)),
                      ButtonSegment(
                          value: ThemeMode.dark,
                          label: Text('تاریک'),
                          icon: Icon(Icons.dark_mode_rounded)),
                      ButtonSegment(
                          value: ThemeMode.system,
                          label: Text('خودکار'),
                          icon: Icon(Icons.brightness_auto_rounded)),
                    ],
                    selected: {settings.themeMode},
                    onSelectionChanged: (s) =>
                        settings.setThemeMode(s.first),
                  ),
                ),
                SwitchListTile(
                  title: const Text('عربی ہندسے (١٢٣)'),
                  subtitle: const Text('بند کریں تو 123 دکھائی دیں گے'),
                  value: settings.persianDigits,
                  onChanged: settings.setPersianDigits,
                ),
              ],
            ),
            _sectionTitle(context, 'مواد'),
            _card(
              context,
              children: [
                _infoRow(context, 'مواد کا ورژن',
                    localDigits(repo.version)),
                _infoRow(context, 'آخری اپڈیٹ', repo.updated),
                _infoRow(context, 'لغت کے الفاظ',
                    localDigits(repo.list('dictionary').length)),
                _infoRow(context, 'مصادر',
                    localDigits(repo.list('verbs').length)),
                _infoRow(context, 'اسباق',
                    localDigits(repo.list('lessons').length)),
                _infoRow(context, 'جملے',
                    localDigits(repo.list('sentences').length)),
                ListTile(
                  leading: const Icon(Icons.cloud_download_rounded),
                  title: const Text('آن لائن اپڈیٹ'),
                  subtitle: const Text('نیا مواد انٹرنیٹ سے حاصل کریں'),
                  trailing: const Icon(Icons.chevron_left_rounded),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const UpdateScreen()),
                  ),
                ),
              ],
            ),
            _sectionTitle(context, 'ایپ'),
            _card(
              context,
              children: [
                ListTile(
                  leading: const Icon(Icons.language_rounded),
                  title: const Text('ویب سائٹ کھولیں'),
                  subtitle: const Text('تمام مواد براؤزر میں بھی موجود ہے'),
                  trailing: const Icon(Icons.chevron_left_rounded),
                  onTap: () => _openWebsite(context),
                ),
                ListTile(
                  leading: const Icon(Icons.ios_share_rounded),
                  title: const Text('ایپ شیئر کریں'),
                  subtitle: const Text('دوستوں کو عربی سیکھنے کی دعوت دیں'),
                  onTap: shareApp,
                ),
                ListTile(
                  leading: const Icon(Icons.edit_note_rounded),
                  title: const Text('تصحیح و اضافہ'),
                  subtitle: const Text('غلطی کی نشاندہی یا نئی تجویز بھیجیں'),
                  trailing: const Icon(Icons.chevron_left_rounded),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const FeedbackScreen()),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.link_rounded),
                  title: const Text('ایپ کا لنک'),
                  subtitle: Text(
                    AppConfig.appLink,
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.right,
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.copy_rounded),
                    onPressed: () => copyText(context, AppConfig.appLink),
                  ),
                ),
              ],
            ),
            _sectionTitle(context, 'ایپ کے بارے میں'),
            _card(
              context,
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(AppConfig.appName,
                          style: faStyle(size: 20, color: cs.primary)),
                      const SizedBox(height: 10),
                      const Text(
                        'یہ ایپ میں نے عربی سیکھنے والوں کے لیے بنائی ہے تاکہ لوگ بآسانی عربی سیکھ سکیں۔ اس ایپ میں:',
                        style: TextStyle(height: 2.0),
                      ),
                      const SizedBox(height: 6),
                      for (final f in _featuresUr)
                        _featureRow(context, f),
                      const SizedBox(height: 8),
                      const Text(
                        'اس میں مزید نئے فیچرز بھی شامل کیے جائیں گے۔',
                        style: TextStyle(height: 2.0),
                      ),
                      const Divider(height: 30),
                      const Text(
                        'I made this app for Arabic learners, so that people can learn Arabic easily. This app includes:',
                        textDirection: TextDirection.ltr,
                        style: TextStyle(height: 1.6),
                      ),
                      const SizedBox(height: 6),
                      for (final f in _featuresEn)
                        _featureRow(context, f, ltr: true),
                      const SizedBox(height: 8),
                      const Text(
                        'More new features will also be added to it.',
                        textDirection: TextDirection.ltr,
                        style: TextStyle(height: 1.6),
                      ),
                      const Divider(height: 30),
                      Text(
                        'صنعتُ هذا التطبيق لمتعلمي اللغة العربية حتى يتمكن الناس من تعلم العربية بسهولة. يشمل هذا التطبيق:',
                        style: faStyle(size: 16, w: FontWeight.w500),
                      ),
                      const SizedBox(height: 6),
                      for (final f in _featuresFa)
                        _featureRow(context, f),
                      const SizedBox(height: 8),
                      Text(
                        'وستُضاف إليه مزايا جديدة أخرى أيضاً.',
                        style: faStyle(size: 16, w: FontWeight.w500),
                      ),
                      const Divider(height: 30),
                      Center(
                        child: Column(
                          children: [
                            Text(
                              'سَیّدہ مریم',
                              style: urStyle(size: 19, color: cs.primary),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'پہلا والیوم — جدید ٹیکنالوجی کے ساتھ اینڈرائیڈ ایپلیکیشن',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: cs.outline, fontSize: 13.5),
                            ),
                            const SizedBox(height: 6),
                            Text('ایپ ورژن: 1.1.1',
                                style: TextStyle(
                                    color: cs.outline, fontSize: 12.5)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(6, 18, 6, 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 17,
          fontWeight: FontWeight.w800,
          color: Theme.of(context).colorScheme.primary,
        ),
      ),
    );
  }

  Widget _card(BuildContext context, {required List<Widget> children}) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(children: children),
    );
  }

  Widget _featureRow(BuildContext context, String text, {bool ltr = false}) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        textDirection: ltr ? TextDirection.ltr : TextDirection.rtl,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 9),
            child: Icon(Icons.check_circle_rounded,
                size: 16, color: cs.primary),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(text,
                textDirection: ltr ? TextDirection.ltr : TextDirection.rtl,
                style: const TextStyle(height: 1.9)),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(BuildContext context, String label, String value) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
      child: Row(
        children: [
          Expanded(child: Text(label, style: TextStyle(color: cs.outline))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
