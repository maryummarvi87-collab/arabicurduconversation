import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../data/repository.dart';
import '../services/tts_service.dart';
import '../state.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';
import 'feedback_screen.dart';
import 'update_screen.dart';

const _featuresUr = [
  'عربی کے اسباق',
  'مکمل عربی اُردو اور اُردو عربی لغت',
  'مکمل صرف و نحو (عربی گرامر)',
  'مضامین',
  'مصادر اور گردانیں',
  'جملے',
  'بول چال',
  'قرآن و احادیث',
  'اسباق شاعری',
  'آن لائن اپڈیٹ',
];

const _featuresEn = [
  'Arabic lessons',
  'Complete Arabic–Urdu and Urdu–Arabic dictionary',
  'Complete Arabic grammar (syntax and morphology)',
  'Essays',
  'Infinitives and conjugations',
  'Sentences',
  'Conversation',
  'Quran and Hadith',
  'Poetry lessons',
  'Online update',
];

const _featuresFa = [
  'دروس اللغة العربية',
  'قاموس كامل عربي ـ أردو وأردو ـ عربي',
  'قواعد كاملة للغة العربية (النحو والصرف)',
  'مقاله‌ها',
  'مصدرها و صرف فعل‌ها',
  'جمله‌ها',
  'گفت‌وگو',
  'القرآن والأحاديث',
  'درس‌های شعر',
  'به‌روزرسانی آنلاین',
];

/// ایپ کے آپشنز: ترتیبات، مواد کی معلومات اور ایپ سے متعلق کارروائیاں ایک جگہ
/// آواز کی رفتار کے تیار پری سیٹ (قدر، لیبل) — سیکھنے والوں کے لیے
/// ایک ٹیپ میں آہستہ/معمول/تیز منتخب ہو جائے۔
const _ratePresets = <(double, String)>[
  (0.7, 'بہت آہستہ'),
  (0.85, 'آہستہ'),
  (1.0, 'معمول'),
  (1.15, 'تیز'),
];

/// رفتار کی قدر کے لیے لفظی لیبل۔
String _rateWord(double r) {
  if (r <= 0.65) return 'بہت آہستہ';
  if (r <= 0.92) return 'آہستہ';
  if (r <= 1.07) return 'معمول';
  if (r <= 1.3) return 'تیز';
  return 'بہت تیز';
}

/// رفتار کی قدر کی نمائش، مثلاً 0.85x / 1.0x۔
String _rateText(double r) {
  var s = r.toStringAsFixed(2);
  if (s.endsWith('0')) s = s.substring(0, s.length - 1);
  return '${s}x';
}

class AppOptionsScreen extends StatelessWidget {
  const AppOptionsScreen({super.key});

  Future<void> _openWebsite(BuildContext context) async {
    final ok = await launchUrl(Uri.parse(AppConfig.appLink),
        mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) showSnack(context, 'ویب سائٹ نہیں کھل سکی');
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('ایپ کے بارے میں')),
      body: ListenableBuilder(
        listenable: settings,
        builder: (context, _) => ListView(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
          children: [
            _sectionTitle(context, 'ترتیبات'),
            _card(
              context,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
                  child: Text('ایپ کا انداز (تھیم)',
                      style: TextStyle(color: cs.outline)),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
                  child: SegmentedButton<ThemeMode>(
                    segments: const [
                      ButtonSegment(
                          value: ThemeMode.light,
                          label: Text('روشن'),
                          icon: Icon(Icons.light_mode_rounded)),
                      ButtonSegment(
                          value: ThemeMode.dark,
                          label: Text('تاریک'),
                          icon: Icon(Icons.dark_mode_rounded)),
                      ButtonSegment(
                          value: ThemeMode.system,
                          label: Text('خودکار'),
                          icon: Icon(Icons.brightness_auto_rounded)),
                    ],
                    selected: {settings.themeMode},
                    onSelectionChanged: (s) =>
                        settings.setThemeMode(s.first),
                  ),
                ),
                SwitchListTile(
                  title: const Text('عربی ہندسے (١٢٣)'),
                  subtitle: const Text('بند کریں تو 123 دکھائی دیں گے'),
                  value: settings.persianDigits,
                  onChanged: settings.setPersianDigits,
                ),
                const Divider(height: 1),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 14, 16, 4),
                  child: Text('آواز (آن لائن، قدرتی نیورل آواز)',
                      style: TextStyle(color: cs.outline)),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 6),
                  child: SegmentedButton<bool>(
                    segments: const [
                      ButtonSegment(
                          value: false,
                          label: Text('عورت کی آواز'),
                          icon: Icon(Icons.record_voice_over_rounded)),
                      ButtonSegment(
                          value: true,
                          label: Text('مرد کی آواز'),
                          icon: Icon(Icons.voice_over_off_rounded)),
                    ],
                    selected: {settings.maleVoice},
                    onSelectionChanged: (s) =>
                        settings.setMaleVoice(s.first),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                  child: Row(
                    children: [
                      const Text('آواز کی رفتار'),
                      const Spacer(),
                      Text(
                          '${_rateWord(settings.speechRate)} (${_rateText(settings.speechRate)})'),
                    ],
                  ),
                ),
                Slider(
                  value: settings.speechRate,
                  min: 0.5,
                  max: 1.5,
                  divisions: 20,
                  onChanged: settings.setSpeechRate,
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 2),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('آہستہ',
                          style:
                              TextStyle(fontSize: 12, color: cs.outline)),
                      Text('تیز',
                          style:
                              TextStyle(fontSize: 12, color: cs.outline)),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 2),
                  child: Wrap(
                    spacing: 8,
                    children: [
                      for (final p in _ratePresets)
                        ChoiceChip(
                          label: Text(p.$2),
                          selected:
                              (settings.speechRate - p.$1).abs() < 0.03,
                          onSelected: (_) => settings.setSpeechRate(p.$1),
                        ),
                    ],
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 6),
                  child: Text(
                    'یہ رفتار ایپ کی تمام زبانوں کی آوازوں پر لگتی ہے — سیکھنے کے لیے آہستہ رفتار پر سننا آسان رہتا ہے۔',
                    style: TextStyle(fontSize: 12.5, color: cs.outline),
                  ),
                ),
                const AudioCacheTile(),
              ],
            ),
            _sectionTitle(context, 'مواد'),
            _card(
              context,
              children: [
                _infoRow(context, 'مواد کا ورژن',
                    localDigits(repo.version)),
                _infoRow(context, 'آخری اپڈیٹ', repo.updated),
                _infoRow(context, 'لغت کے الفاظ',
                    localDigits(repo.list('dictionary').length)),
                _infoRow(context, 'مصادر',
                    localDigits(repo.list('verbs').length)),
                _infoRow(context, 'اسباق',
                    localDigits(repo.list('lessons').length)),
                _infoRow(context, 'جملے',
                    localDigits(repo.list('sentences').length)),
                ListTile(
                  leading: const Icon(Icons.cloud_download_rounded),
                  title: const Text('آن لائن اپڈیٹ'),
                  subtitle: const Text('نیا مواد انٹرنیٹ سے حاصل کریں'),
                  trailing: const Icon(Icons.chevron_left_rounded),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const UpdateScreen()),
                  ),
                ),
              ],
            ),
            _sectionTitle(context, 'ایپ'),
            _card(
              context,
              children: [
                ListTile(
                  leading: const Icon(Icons.language_rounded),
                  title: const Text('ویب سائٹ کھولیں'),
                  subtitle: const Text('تمام مواد براؤزر میں بھی موجود ہے'),
                  trailing: const Icon(Icons.chevron_left_rounded),
                  onTap: () => _openWebsite(context),
                ),
                ListTile(
                  leading: const Icon(Icons.ios_share_rounded),
                  title: const Text('ایپ شیئر کریں'),
                  subtitle: const Text('دوستوں کو عربی سیکھنے کی دعوت دیں'),
                  onTap: shareApp,
                ),
                ListTile(
                  leading: const Icon(Icons.edit_note_rounded),
                  title: const Text('تصحیح و اضافہ'),
                  subtitle: const Text('غلطی کی نشاندہی یا نئی تجویز بھیجیں'),
                  trailing: const Icon(Icons.chevron_left_rounded),
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const FeedbackScreen()),
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.link_rounded),
                  title: const Text('ایپ کا لنک'),
                  subtitle: Text(
                    AppConfig.appLink,
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.right,
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.copy_rounded),
                    onPressed: () => copyText(context, AppConfig.appLink),
                  ),
                ),
              ],
            ),
            _sectionTitle(context, 'ایپ کے بارے میں'),
            _card(
              context,
              children: [
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(AppConfig.appName,
                          style: faStyle(size: 20, color: cs.primary)),
                      const SizedBox(height: 10),
                      const Text(
                        'یہ ایپ میں نے عربی سیکھنے والوں کے لیے بنائی ہے تاکہ لوگ بآسانی عربی سیکھ سکیں۔ اس ایپ میں:',
                        style: TextStyle(height: 2.0),
                      ),
                      const SizedBox(height: 6),
                      for (final f in _featuresUr)
                        _featureRow(context, f),
                      const SizedBox(height: 8),
                      const Text(
                        'اس میں مزید نئے فیچرز بھی شامل کیے جائیں گے۔',
                        style: TextStyle(height: 2.0),
                      ),
                      const Divider(height: 30),
                      const Text(
                        'I made this app for Arabic learners, so that people can learn Arabic easily. This app includes:',
                        textDirection: TextDirection.ltr,
                        style: TextStyle(height: 1.6),
                      ),
                      const SizedBox(height: 6),
                      for (final f in _featuresEn)
                        _featureRow(context, f, ltr: true),
                      const SizedBox(height: 8),
                      const Text(
                        'More new features will also be added to it.',
                        textDirection: TextDirection.ltr,
                        style: TextStyle(height: 1.6),
                      ),
                      const Divider(height: 30),
                      Text(
                        'صنعتُ هذا التطبيق لمتعلمي اللغة العربية حتى يتمكن الناس من تعلم العربية بسهولة. يشمل هذا التطبيق:',
                        style: faStyle(size: 16, w: FontWeight.w500),
                      ),
                      const SizedBox(height: 6),
                      for (final f in _featuresFa)
                        _featureRow(context, f),
                      const SizedBox(height: 8),
                      Text(
                        'وستُضاف إليه مزايا جديدة أخرى أيضاً.',
                        style: faStyle(size: 16, w: FontWeight.w500),
                      ),
                      const Divider(height: 30),
                      Center(
                        child: Column(
                          children: [
                            Text(
                              'سَیّدہ مریم',
                              style: urStyle(size: 19, color: cs.primary),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'پہلا والیوم — جدید ٹیکنالوجی کے ساتھ اینڈرائیڈ ایپلیکیشن',
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                  color: cs.outline, fontSize: 13.5),
                            ),
                            const SizedBox(height: 6),
                            Text('ایپ ورژن: 1.1.1',
                                style: TextStyle(
                                    color: cs.outline, fontSize: 12.5)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(6, 18, 6, 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 17,
          fontWeight: FontWeight.w800,
          color: Theme.of(context).colorScheme.primary,
        ),
      ),
    );
  }

  Widget _card(BuildContext context, {required List<Widget> children}) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
      ),
      clipBehavior: Clip.antiAlias,
      child: Column(children: children),
    );
  }

  Widget _featureRow(BuildContext context, String text, {bool ltr = false}) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        textDirection: ltr ? TextDirection.ltr : TextDirection.rtl,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 9),
            child: Icon(Icons.check_circle_rounded,
                size: 16, color: cs.primary),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(text,
                textDirection: ltr ? TextDirection.ltr : TextDirection.rtl,
                style: const TextStyle(height: 1.9)),
          ),
        ],
      ),
    );
  }

  Widget _infoRow(BuildContext context, String label, String value) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 7),
      child: Row(
        children: [
          Expanded(child: Text(label, style: TextStyle(color: cs.outline))),
          Text(value, style: const TextStyle(fontWeight: FontWeight.w700)),
        ],
      ),
    );
  }
}
