import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:shared_preferences/shared_preferences.dart';

import '../theme.dart';
import '../widgets/common.dart';

/// مکمل قرآن مجید — نورِ قرآن خط (انڈوپاک رسم الخط) + جالندھری اردو ترجمہ
/// ڈیٹا: assets/data/quran_indopak.json — {basmala, surahs: [{n, name, basmala, ayahs: [], ur: []}]}
class MushafData {
  static Map<String, dynamic>? _cache;
  static Future<Map<String, dynamic>> load() async {
    if (_cache != null) return _cache!;
    final s = await rootBundle.loadString('assets/data/quran_indopak.json');
    _cache = jsonDecode(s) as Map<String, dynamic>;
    return _cache!;
  }
}

String _arabDigits(int n) =>
    n.toString().replaceAllMapped(RegExp(r'[0-9]'), (m) => '٠١٢٣٤٥٦٧٨٩'[int.parse(m[0]!)]);

class MushafScreen extends StatefulWidget {
  const MushafScreen({super.key});

  @override
  State<MushafScreen> createState() => _MushafScreenState();
}

class _MushafScreenState extends State<MushafScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('قرآن مجید — تلاوت')),
      body: FutureBuilder<Map<String, dynamic>>(
        future: MushafData.load(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final surahs = (snap.data!['surahs'] as List).cast<Map<String, dynamic>>();
          final q = _q.trim();
          final shown = surahs.where((s) {
            if (q.isEmpty) return true;
            return s['name'].toString().contains(q) || s['n'].toString() == q;
          }).toList();
          return Column(
            children: [
              SearchBox(
                hint: 'سورت تلاش کریں…',
                onChanged: (v) => setState(() => _q = v),
              ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.only(top: 4, bottom: 32),
                  itemCount: shown.length,
                  itemBuilder: (context, i) {
                    final s = shown[i];
                    final ayahs = (s['ayahs'] as List).length;
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                      decoration: BoxDecoration(
                        color: cardFill(context),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: AppColors.gold.withOpacity(0.35)),
                      ),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: AppColors.gold.withOpacity(0.15),
                          child: Text(_arabDigits(s['n'] as int),
                              style: const TextStyle(
                                  fontFamily: 'NoorQuran',
                                  color: AppColors.gold,
                                  fontWeight: FontWeight.bold)),
                        ),
                        title: Text('سورة ${s['name']}',
                            textDirection: TextDirection.rtl,
                            style: const TextStyle(fontFamily: 'NoorQuran', fontSize: 24)),
                        subtitle: Text('${_arabDigits(ayahs)} آیات', style: urStyle(size: 13)),
                        trailing: const Icon(Icons.chevron_left, color: AppColors.gold),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => SurahReaderScreen(
                                surah: s, basmala: snap.data!['basmala'].toString()),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class SurahReaderScreen extends StatefulWidget {
  final Map<String, dynamic> surah;
  final String basmala;
  const SurahReaderScreen({super.key, required this.surah, required this.basmala});

  @override
  State<SurahReaderScreen> createState() => _SurahReaderScreenState();
}

class _SurahReaderScreenState extends State<SurahReaderScreen> {
  double _size = 30;
  bool _showUr = true;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (!mounted) return;
      setState(() {
        _size = p.getDouble('mushaf_font_size') ?? 30;
        _showUr = p.getBool('mushaf_show_ur') ?? true;
      });
    });
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('mushaf_font_size', _size);
    await p.setBool('mushaf_show_ur', _showUr);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.surah;
    final ayahs = (s['ayahs'] as List).cast<String>();
    final urs = (s['ur'] as List).cast<String>();
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text('سورة ${s['name']}',
            style: const TextStyle(fontFamily: 'NoorQuran', fontSize: 22)),
        actions: [
          IconButton(
            icon: const Icon(Icons.text_decrease),
            tooltip: 'حروف چھوٹے',
            onPressed: () {
              setState(() => _size = (_size - 2).clamp(20, 52));
              _save();
            },
          ),
          IconButton(
            icon: const Icon(Icons.text_increase),
            tooltip: 'حروف بڑے',
            onPressed: () {
              setState(() => _size = (_size + 2).clamp(20, 52));
              _save();
            },
          ),
          IconButton(
            icon: Icon(Icons.translate, color: _showUr ? AppColors.gold : null),
            tooltip: 'اردو ترجمہ',
            onPressed: () {
              setState(() => _showUr = !_showUr);
              _save();
            },
          ),
        ],
      ),
      body: ListView.builder(
        padding: const EdgeInsets.fromLTRB(18, 12, 18, 48),
        itemCount: ayahs.length + ((s['basmala'] == true) ? 1 : 0),
        itemBuilder: (context, i) {
          if (s['basmala'] == true && i == 0) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 18),
              child: Text(
                widget.basmala,
                textDirection: TextDirection.rtl,
                textAlign: TextAlign.center,
                style: TextStyle(fontFamily: 'NoorQuran', fontSize: _size, height: 2.0),
              ),
            );
          }
          final idx = i - ((s['basmala'] == true) ? 1 : 0);
          return Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text.rich(
                  TextSpan(children: [
                    TextSpan(text: ayahs[idx]),
                    TextSpan(
                      text: ' ﴿${_arabDigits(idx + 1)}﴾',
                      style: const TextStyle(color: AppColors.gold),
                    ),
                  ]),
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.justify,
                  style: TextStyle(fontFamily: 'NoorQuran', fontSize: _size, height: 2.1),
                ),
                if (_showUr && idx < urs.length)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      urs[idx],
                      textDirection: TextDirection.rtl,
                      style: urStyle(size: 15, color: cs.onSurface.withOpacity(0.8)),
                    ),
                  ),
              ],
            ),
          );
        },
      ),
    );
  }
}
