import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/mushaf_data.dart';
import '../services/tts_service.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/ayah_word_sheet.dart';
import '../widgets/common.dart';

/// ہر سورت کی آیات کی معیاری تعداد — عالمی آیت نمبر (1–6236) کے لیے
/// (تلاوت CDN کی فی آیت فائلیں اسی عالمی نمبر سے ملتی ہیں)۔
const List<int> _surahAyahCounts = [
  7, 286, 200, 176, 120, 165, 206, 75, 129, 109,
  123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
  112, 78, 118, 64, 77, 227, 93, 88, 69, 60,
  34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
  54, 53, 89, 59, 37, 35, 38, 29, 18, 45,
  60, 49, 62, 55, 78, 96, 29, 22, 24, 13,
  14, 11, 11, 18, 12, 12, 30, 52, 52, 44,
  28, 28, 20, 56, 40, 31, 50, 40, 46, 42,
  29, 19, 36, 25, 22, 17, 19, 26, 30, 20,
  15, 21, 11, 8, 8, 19, 5, 8, 8, 11,
  11, 8, 3, 9, 5, 4, 7, 3, 6, 3,
  5, 4, 5, 6,
];

int _globalAyah(int surahNum, int ayahNum) {
  var g = ayahNum;
  for (var i = 0; i < surahNum - 1 && i < _surahAyahCounts.length; i++) {
    g += _surahAyahCounts[i];
  }
  return g;
}

/// ہر پارے (جز) کا آغاز — [سورت نمبر، آیت نمبر]، پارہ 1 تا 30 کی ترتیب میں۔
const List<List<int>> _juzStarts = [
  [1, 1], [2, 142], [2, 253], [3, 93], [4, 24],
  [4, 148], [5, 82], [6, 111], [7, 88], [8, 41],
  [9, 93], [11, 6], [12, 53], [15, 1], [17, 1],
  [18, 75], [21, 1], [23, 1], [25, 21], [27, 56],
  [29, 46], [33, 31], [36, 28], [39, 32], [41, 47],
  [46, 1], [51, 31], [58, 1], [67, 1], [78, 1],
];

/// پاروں کے روایتی نام (ان کے ابتدائی الفاظ) — پارہ 1 تا 30۔
const List<String> _paraNames = [
  'آلم', 'سیقول', 'تلک الرسل', 'لن تنالوا', 'والمحصنات',
  'لا یحب اللہ', 'واذا سمعوا', 'ولو اننا', 'قال الملأ', 'واعلموا',
  'یعتذرون', 'وما من دابۃ', 'وما ابری', 'ربما', 'سبحان الذی',
  'قال الم', 'اقترب للناس', 'قد افلح', 'وقال الذین', 'امن خلق',
  'اتل ما اوحی', 'ومن یقنت', 'وما لی', 'فمن اظلم', 'الیہ یرد',
  'حم', 'قال فما خطبکم', 'قد سمع اللہ', 'تبارک الذی', 'عم یتساءلون',
];

/// اس (سورت، آیت) سے کون سا پارہ شروع ہوتا ہے؟ نہ ہوتا ہو تو null۔
int? _paraStartingAt(int surah, int ayah) {
  for (var p = 0; p < _juzStarts.length; p++) {
    if (_juzStarts[p][0] == surah && _juzStarts[p][1] == ayah) return p + 1;
  }
  return null;
}

/// ریڈر کی فہرست کا ایک آئٹم: بسملہ، پارہ بار یا آیت۔
class _ReaderEntry {
  final int kind; // 0 = بسملہ، 1 = پارہ بار، 2 = آیت
  final int value; // پارہ نمبر (1–30) یا آیت کا 0-based اشاریہ
  const _ReaderEntry(this.kind, this.value);
}

const List<Color> _ayahColors = [
  Color(0xFF000000),
  Color(0xFF14532D),
  Color(0xFF5D4037),
  Color(0xFF0D47A1),
];
const List<Color> _ayahColorsDark = [
  Color(0xFFF5EFE0),
  Color(0xFF81C784),
  Color(0xFFBCAAA4),
  Color(0xFF90CAF9),
];
const List<String> _ayahColorNames = ['کالا', 'گہرا سبز', 'بھورا', 'نیلا'];
const List<Color> _badgeCycle = [
  Color(0xFF14532D),
  Color(0xFF5D4037),
  Color(0xFF0D47A1),
  Color(0xFF212121),
];
const Color _pageBg = Color(0xFFFFFDF4);
const Color _pageBgDark = Color(0xFF101010);

class MushafScreen extends StatefulWidget {
  const MushafScreen({super.key});

  @override
  State<MushafScreen> createState() => _MushafScreenState();
}

class _MushafScreenState extends State<MushafScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('قرآن مجید — تلاوت'),
        actions: [
          IconButton(
            icon: const Icon(Icons.account_tree_outlined),
            tooltip: 'افعال کے مادے',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const VerbRootsScreen()),
            ),
          ),
        ],
      ),
      body: FutureBuilder<Map<String, dynamic>>(
        future: MushafData.loadQuran(),
        builder: (context, snap) {
          if (!snap.hasData) {
            return const Center(child: CircularProgressIndicator());
          }
          final surahs = (snap.data!['surahs'] as List).cast<Map<String, dynamic>>();
          final q = _q.trim();
          final shown = surahs.where((s) {
            if (q.isEmpty) return true;
            return s['name'].toString().contains(q) || s['n'].toString() == q;
          }).toList();
          return Column(
            children: [
              SearchBox(
                hint: 'سورت تلاش کریں…',
                onChanged: (v) => setState(() => _q = v),
              ),
              Expanded(
                child: ListView.builder(
                  padding: const EdgeInsets.only(top: 4, bottom: 32),
                  itemCount: shown.length,
                  itemBuilder: (context, i) {
                    final s = shown[i];
                    final n = s['n'] as int;
                    final ayahs = (s['ayahs'] as List).length;
                    final badge = _badgeCycle[(n - 1) % _badgeCycle.length];
                    return Container(
                      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
                      decoration: BoxDecoration(
                        color: cardFill(context),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(color: badge.withOpacity(0.45)),
                      ),
                      child: ListTile(
                        leading: CircleAvatar(
                          backgroundColor: badge,
                          child: Text('$n',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 15)),
                        ),
                        title: Text('سورة ${s['name']}',
                            textDirection: TextDirection.rtl,
                            style: const TextStyle(fontFamily: 'NoorQuran', fontSize: 24)),
                        subtitle: Text(
                            '${s['place']} • $ayahs آیات • ${s['rukus']} رکوع',
                            style: urStyle(size: 13)),
                        trailing: const Icon(Icons.chevron_left, color: AppColors.gold),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => SurahReaderScreen(
                                surah: s, basmala: snap.data!['basmala'].toString()),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class SurahReaderScreen extends StatefulWidget {
  final Map<String, dynamic> surah;
  final String basmala;
  const SurahReaderScreen({super.key, required this.surah, required this.basmala});

  @override
  State<SurahReaderScreen> createState() => _SurahReaderScreenState();
}

class _SurahReaderScreenState extends State<SurahReaderScreen> {
  double _size = 30;
  bool _showUr = true;
  int _colorIdx = 0;
  double? _pinchStart;
  Map<String, dynamic>? _words;

  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) {
      if (!mounted) return;
      setState(() {
        _size = p.getDouble('mushaf_font_size') ?? 30;
        _showUr = p.getBool('mushaf_show_ur') ?? true;
        _colorIdx = p.getInt('mushaf_color') ?? 0;
      });
    });
    MushafData.loadWords().then((w) {
      if (!mounted) return;
      setState(() {
        _words = (w['words'] as Map).cast<String, dynamic>();
      });
    });
  }

  @override
  void dispose() {
    // اسکرین چھوڑتے ہی تلاوت، پارہ سماعت و ترجمہ آواز رک جائیں
    recitation.stop();
    paraAudio.stop();
    translationAudio.stop();
    super.dispose();
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('mushaf_font_size', _size);
    await p.setBool('mushaf_show_ur', _showUr);
    await p.setInt('mushaf_color', _colorIdx);
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.surah;
    final ayahs = (s['ayahs'] as List).cast<String>();
    final urs = (s['ur'] as List).cast<String>();
    final hasBasmala = s['basmala'] == true;
    final dark = Theme.of(context).brightness == Brightness.dark;
    final color = dark ? _ayahColorsDark[_colorIdx] : _ayahColors[_colorIdx];
    final badgeColor = _ayahColors[_colorIdx];
    // فہرست کے آئٹمز ترتیب سے: بسملہ (اگر ہو)، ہر پارے کے آغاز پر اس کی
    // پہلی آیت سے فوراً پہلے پارہ بار، اور آیات۔
    final surahNum = s['n'] as int;
    final entries = <_ReaderEntry>[];
    if (hasBasmala) entries.add(const _ReaderEntry(0, 0));
    for (var a = 1; a <= ayahs.length; a++) {
      final para = _paraStartingAt(surahNum, a);
      if (para != null) entries.add(_ReaderEntry(1, para));
      entries.add(_ReaderEntry(2, a - 1));
    }
    return Scaffold(
      appBar: AppBar(
        title: Text('سورة ${s['name']}',
            style: const TextStyle(fontFamily: 'NoorQuran', fontSize: 22)),
        actions: [
          IconButton(
            icon: Icon(dark ? Icons.light_mode_outlined : Icons.dark_mode_outlined),
            tooltip: dark ? 'روشن انداز' : 'ڈارک موڈ (پوری ایپ)',
            onPressed: () => settings
                .setThemeMode(dark ? ThemeMode.light : ThemeMode.dark),
          ),
          IconButton(
            icon: const Icon(Icons.account_tree_outlined),
            tooltip: 'افعال کے مادے',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const VerbRootsScreen()),
            ),
          ),
          PopupMenuButton<int>(
            icon: const Icon(Icons.palette_outlined),
            tooltip: 'آیت کا رنگ',
            initialValue: _colorIdx,
            onSelected: (v) {
              setState(() => _colorIdx = v);
              _save();
            },
            itemBuilder: (_) => [
              for (int i = 0; i < _ayahColors.length; i++)
                PopupMenuItem(
                  value: i,
                  child: Row(children: [
                    CircleAvatar(radius: 9, backgroundColor: _ayahColors[i]),
                    const SizedBox(width: 10),
                    Text(_ayahColorNames[i], style: urStyle(size: 14)),
                  ]),
                ),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.text_decrease),
            tooltip: 'حروف چھوٹے',
            onPressed: () {
              setState(() => _size = (_size - 2).clamp(20, 52));
              _save();
            },
          ),
          IconButton(
            icon: const Icon(Icons.text_increase),
            tooltip: 'حروف بڑے',
            onPressed: () {
              setState(() => _size = (_size + 2).clamp(20, 52));
              _save();
            },
          ),
          IconButton(
            icon: Icon(Icons.translate, color: _showUr ? AppColors.gold : null),
            tooltip: 'اردو ترجمہ',
            onPressed: () {
              setState(() => _showUr = !_showUr);
              _save();
            },
          ),
        ],
      ),
      body: Container(
        color: dark ? _pageBgDark : _pageBg,
        child: GestureDetector(
          behavior: HitTestBehavior.translucent,
          onScaleStart: (d) => _pinchStart = _size,
          onScaleUpdate: (d) {
            if (_pinchStart == null || d.scale == 1.0) return;
            setState(() => _size = (_pinchStart! * d.scale).clamp(20, 72));
          },
          onScaleEnd: (_) {
            _pinchStart = null;
            _save();
          },
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 48),
            itemCount: entries.length,
            itemBuilder: (context, i) {
              final entry = entries[i];
              if (entry.kind == 0) {
                return Padding(
                  padding: const EdgeInsets.only(bottom: 18),
                  child: Text(
                    widget.basmala,
                    textDirection: TextDirection.rtl,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontFamily: 'NoorQuran',
                        fontSize: _size,
                        height: 2.0,
                        color: color),
                  ),
                );
              }
              if (entry.kind == 1) {
                return _ParaBar(
                  key: ValueKey('para:${entry.value}'),
                  para: entry.value,
                  dark: dark,
                );
              }
              final idx = entry.value;
              final key = '${s['n']}:${idx + 1}';
              return _AyahBlock(
                key: ValueKey(key),
                surahNum: s['n'] as int,
                ayahNum: idx + 1,
                text: ayahs[idx],
                urdu: (_showUr && idx < urs.length) ? urs[idx] : null,
                fontSize: _size,
                color: color,
                badgeColor: badgeColor,
                dark: dark,
                wordRec: _words?[key] as Map<String, dynamic>?,
                surahName: s['name'].toString(),
              );
            },
          ),
        ),
      ),
    );
  }
}

class _AyahBlock extends StatefulWidget {
  final int surahNum;
  final int ayahNum;
  final String text;
  final String? urdu;
  final double fontSize;
  final Color color;
  final Color badgeColor;
  final bool dark;
  final Map<String, dynamic>? wordRec;
  final String surahName;
  const _AyahBlock({
    super.key,
    required this.surahNum,
    required this.ayahNum,
    required this.text,
    required this.urdu,
    required this.fontSize,
    required this.color,
    required this.badgeColor,
    required this.dark,
    required this.wordRec,
    required this.surahName,
  });

  @override
  State<_AyahBlock> createState() => _AyahBlockState();
}

class _AyahBlockState extends State<_AyahBlock> {
  final List<TapGestureRecognizer> _recs = [];

  @override
  void dispose() {
    for (final r in _recs) {
      r.dispose();
    }
    super.dispose();
  }

  void _showWord(String token, List<int> wordIdxs) {
    showAyahWordSheet(context,
        token: token, wordIdxs: wordIdxs, wordRec: widget.wordRec!);
  }

  /// آیت پر ٹیپ — اختیارات شیٹ
  void _showAyahOptions() {
    showModalBottomSheet(
      context: context,
      builder: (_) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('سورة ${widget.surahName} — آیت ${widget.ayahNum}',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.center,
                  style: urStyle(size: 16)),
              const Divider(height: 20),
              if (widget.wordRec != null)
                ListTile(
                  leading: const Icon(Icons.touch_app_outlined,
                      color: AppColors.gold),
                  title: Text('لفظ کی تفصیل', style: urStyle(size: 16)),
                  subtitle: Text(
                      'آیت کے کسی لفظ پر ٹیپ کریں — معنی، مادہ، قسمِ کلام اور تکرار نظر آئے گی',
                      style: urStyle(size: 12)),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final tokens = widget.text.split(' ');
    final rec = widget.wordRec;
    final List<List<int>>? amap = rec == null
        ? null
        : (rec['m'] != null
            ? (rec['m'] as List)
                .map((x) => (x as List).map((e) => e as int).toList())
                .toList()
            : List.generate(tokens.length, (i) => [i]));
    final spans = <TextSpan>[];
    for (int i = 0; i < tokens.length; i++) {
      TapGestureRecognizer? rec2;
      if (amap != null && i < amap.length) {
        final idxs = amap[i];
        rec2 = TapGestureRecognizer()..onTap = () => _showWord(tokens[i], idxs);
        _recs.add(rec2);
      }
      spans.add(TextSpan(text: tokens[i], recognizer: rec2));
      if (i < tokens.length - 1) spans.add(const TextSpan(text: ' '));
    }
    spans.add(TextSpan(
      text:
          ' ﴿${widget.ayahNum.toString().replaceAllMapped(RegExp(r'[0-9]'), (m) => '٠١٢٣٤٥٦٧٨٩'[int.parse(m[0]!)])}﴾',
      style: const TextStyle(color: AppColors.gold),
    ));
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          InkWell(
            onTap: _showAyahOptions,
            borderRadius: BorderRadius.circular(8),
            child: Row(
              children: [
                CircleAvatar(
                  radius: 13,
                  backgroundColor: widget.badgeColor.withOpacity(0.85),
                child: Text('${widget.ayahNum}',
                    style: const TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.bold)),
              ),
              const SizedBox(width: 8),
                const Spacer(),
                ValueListenableBuilder<int?>(
                  valueListenable: recitation.playingAyah,
                  builder: (context, playing, _) {
                    final global = _globalAyah(widget.surahNum, widget.ayahNum);
                    final isPlaying = playing == global;
                    return IconButton(
                      tooltip: isPlaying ? 'تلاوت روکیں' : 'تلاوت سنیں',
                      visualDensity: VisualDensity.compact,
                      icon: Icon(
                        isPlaying
                            ? Icons.stop_circle_rounded
                            : Icons.play_circle_fill_rounded,
                        size: 23,
                        color: AppColors.gold,
                      ),
                      onPressed: () async {
                        try {
                          await recitation.toggle(global);
                        } catch (_) {
                          if (context.mounted) {
                            showSnack(context, 'انٹرنیٹ سے تلاوت نہیں آ سکی');
                          }
                        }
                      },
                    );
                  },
                ),
                Icon(Icons.touch_app_outlined,
                    size: 16,
                    color: widget.dark ? Colors.white38 : Colors.black38),
              ],
            ),
          ),
          const SizedBox(height: 4),
          GestureDetector(
            behavior: HitTestBehavior.translucent,
            onTap: _showAyahOptions,
            child: Text.rich(
              TextSpan(children: spans),
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.justify,
              style: TextStyle(
                  fontFamily: 'NoorQuran',
                  fontSize: widget.fontSize,
                  height: 2.1,
                  color: widget.color),
            ),
          ),
          if (widget.urdu != null)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    child: Text(
                      widget.urdu!,
                      textDirection: TextDirection.rtl,
                      style: urStyle(
                          size: 15,
                          color: widget.dark
                              ? const Color(0xFFE8E8E8)
                              : Colors.black87),
                    ),
                  ),
                  _TranslationButton(
                      surahNum: widget.surahNum, ayahNum: widget.ayahNum),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// فی آیت اردو ترجمے کی ریکارڈ شدہ آواز کا بٹن — شمشاد علی خان
/// (جالندھری ترجمہ)۔ یہ TTS نہیں؛ اصل ریکارڈنگ EveryAyah سے چلتی
/// ہے اور کیش بھی ہوتی ہے۔ چل رہا ہو تو رکاوٹ (اسٹاپ) بن جاتا ہے۔
class _TranslationButton extends StatelessWidget {
  final int surahNum;
  final int ayahNum;
  const _TranslationButton({required this.surahNum, required this.ayahNum});

  @override
  Widget build(BuildContext context) {
    final key = '$surahNum:$ayahNum';
    return ValueListenableBuilder<String?>(
      valueListenable: translationAudio.playingKey,
      builder: (context, playing, _) {
        final isPlaying = playing == key;
        return IconButton(
          tooltip: 'ترجمہ سنیں — شمشاد علی خان',
          visualDensity: VisualDensity.compact,
          icon: Icon(
            isPlaying ? Icons.stop_circle_rounded : Icons.volume_up_rounded,
            size: 19,
            color: Theme.of(context).colorScheme.primary,
          ),
          onPressed: () async {
            try {
              await translationAudio.toggle(surahNum, ayahNum);
            } catch (_) {
              if (context.mounted) {
                showSnack(context, 'انٹرنیٹ سے آواز نہیں آ سکی');
              }
            }
          },
        );
      },
    );
  }
}

/// قرآن کے افعال کے مادے — ہر مادے کے افعال (اصل صورتیں) گنتی کے ساتھ
class VerbRootsScreen extends StatefulWidget {
  const VerbRootsScreen({super.key});

  @override
  State<VerbRootsScreen> createState() => _VerbRootsScreenState();
}

class _VerbRootsScreenState extends State<VerbRootsScreen> {
  String _q = '';
  List<Map<String, dynamic>>? _roots;

  @override
  void initState() {
    super.initState();
    MushafData.loadWords().then((w) {
      final words = (w['words'] as Map).cast<String, dynamic>();
      final byRoot = <String, Map<String, dynamic>>{};
      for (final rec in words.values) {
        final entries = ((rec as Map)['w'] as List).cast<List<dynamic>>();
        for (final e in entries) {
          // e = [اردو معنی, مادہ, مادے کی تکرار, اصل صورت, اصل صورت کی تکرار, قسمِ کلام]
          if (e.length < 6 || e[5].toString() != 'فعل') continue;
          final root = e[1].toString();
          if (root.isEmpty) continue;
          final r = byRoot.putIfAbsent(
              root,
              () => <String, dynamic>{
                    'root': root,
                    'count': e[2] as int,
                    'lemmas': <String, Map<String, dynamic>>{},
                  });
          final lemma = e[3].toString();
          if (lemma.isNotEmpty) {
            (r['lemmas'] as Map<String, Map<String, dynamic>>).putIfAbsent(
                lemma,
                () => <String, dynamic>{
                      'lemma': lemma,
                      'count': e[4] as int,
                      'ur': e[0].toString(),
                    });
          }
        }
      }
      final list = byRoot.values.toList()
        ..sort((a, b) => (b['count'] as int).compareTo(a['count'] as int));
      if (!mounted) return;
      setState(() => _roots = list);
    });
  }

  void _showRoot(Map<String, dynamic> r) {
    final lemmas = (r['lemmas'] as Map<String, Map<String, dynamic>>)
        .values
        .toList()
      ..sort((a, b) => (b['count'] as int).compareTo(a['count'] as int));
    final rootSpaced = r['root'].toString().split('').join(' ');
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('مادہ: $rootSpaced',
                  textDirection: TextDirection.rtl, style: urStyle(size: 18)),
              Text('اس مادے کے الفاظ قرآن میں ${r['count']} بار آئے ہیں',
                  textDirection: TextDirection.rtl, style: urStyle(size: 14)),
              const Divider(height: 24),
              Text('اس مادے کے افعال:',
                  textDirection: TextDirection.rtl, style: urStyle(size: 15)),
              const SizedBox(height: 6),
              for (final l in lemmas)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Row(
                    textDirection: TextDirection.rtl,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Text(l['lemma'].toString(),
                            textDirection: TextDirection.rtl,
                            style: const TextStyle(
                                fontFamily: 'NoorQuran',
                                fontSize: 21,
                                color: Colors.black)),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                            '${l['ur']} — ${l['count']} بار',
                            textDirection: TextDirection.rtl,
                            style: urStyle(size: 13)),
                      ),
                    ],
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('قرآن کے افعال کے مادے')),
      body: _roots == null
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                SearchBox(
                  hint: 'مادہ تلاش کریں…',
                  onChanged: (v) => setState(() => _q = v),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
                  child: Text(
                      'کل ${_roots!.length} مادے — کسی مادے پر ٹیپ کریں، اس کے افعال نظر آئیں گے',
                      style: urStyle(size: 13)),
                ),
                Expanded(
                  child: ListView.builder(
                    padding: const EdgeInsets.only(bottom: 32),
                    itemCount: _roots!.length,
                    itemBuilder: (context, i) {
                      final r = _roots![i];
                      final q = _q.replaceAll(' ', '');
                      if (q.isNotEmpty &&
                          !r['root'].toString().replaceAll(' ', '').contains(q)) {
                        return const SizedBox.shrink();
                      }
                      final lemmaCount =
                          (r['lemmas'] as Map<String, dynamic>).length;
                      return Container(
                        margin: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 4),
                        decoration: BoxDecoration(
                          color: cardFill(context),
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                              color: AppColors.gold.withOpacity(0.35)),
                        ),
                        child: ListTile(
                          title: Text(r['root'].toString(),
                              textDirection: TextDirection.rtl,
                              style: const TextStyle(
                                  fontFamily: 'NoorQuran', fontSize: 23)),
                          subtitle: Text(
                              'اس مادے کے الفاظ قرآن میں ${r['count']} بار • $lemmaCount افعال',
                              style: urStyle(size: 13)),
                          trailing: const Icon(Icons.chevron_left,
                              color: AppColors.gold),
                          onTap: () => _showRoot(r),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
    );
  }
}


/// ریڈر کے اندر پارہ بار — جہاں نیا پارہ شروع ہوتا ہے وہیں اس کی پہلی
/// آیت سے فوراً پہلے آتی ہے (Ayesh کی اصلاح، 24 نومبر 2026: سماعت الگ
/// اسکرین میں نہیں، مکمل قرآن کے مطالعے کے اندر ہی ہو)۔ اسی پارے کی
/// مکمل سماعت: تلاوت (العفاسی) + اردو ترجمہ (جالندھری، آواز: معراج
/// الدین خان) — آن لائن اسٹریمنگ، کوئی فائل فون میں محفوظ نہیں ہوتی۔
class _ParaBar extends StatelessWidget {
  final int para;
  final bool dark;
  const _ParaBar({super.key, required this.para, required this.dark});

  String _fmt(Duration d) {
    final s = d.inSeconds.remainder(60).toString().padLeft(2, '0');
    return '${d.inMinutes}:$s';
  }

  Future<void> _toggle(BuildContext context) async {
    try {
      await paraAudio.toggle(para);
    } catch (_) {
      if (context.mounted) showSnack(context, 'انٹرنیٹ سے آواز نہیں آ سکی');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 10),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.gold.withValues(alpha: 0.55)),
      ),
      child: ValueListenableBuilder<int?>(
        valueListenable: paraAudio.playingPara,
        builder: (context, playing, _) {
          final selected = playing == para;
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundColor: AppColors.gold,
                    child: Text('$para',
                        style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14)),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('پارہ $para', style: urStyle(size: 15)),
                        Text(_paraNames[para - 1],
                            textDirection: TextDirection.rtl,
                            textAlign: TextAlign.right,
                            style: const TextStyle(
                                fontFamily: 'NoorQuran', fontSize: 19)),
                      ],
                    ),
                  ),
                  if (selected)
                    IconButton(
                      tooltip: 'روکیں',
                      icon: const Icon(Icons.stop_circle_rounded,
                          color: AppColors.gold, size: 26),
                      onPressed: () => paraAudio.stop(),
                    ),
                  ValueListenableBuilder<bool>(
                    valueListenable: paraAudio.paused,
                    builder: (context, paused, _) {
                      final showPause = selected && !paused;
                      return IconButton(
                        tooltip: showPause ? 'موقوف کریں' : 'ترجمے کے ساتھ چلائیں',
                        icon: Icon(
                          showPause
                              ? Icons.pause_circle_filled_rounded
                              : Icons.play_circle_fill_rounded,
                          color: AppColors.gold,
                          size: 30,
                        ),
                        onPressed: () => _toggle(context),
                      );
                    },
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                'تلاوت: مشاری العفاسی — اردو ترجمہ: فتح محمد خان جالندھری — آواز: معراج الدین خان',
                textDirection: TextDirection.rtl,
                style: urStyle(
                    size: 11.5,
                    color: dark ? Colors.white60 : Colors.black54),
              ),
              if (selected) _progress(),
            ],
          );
        },
      ),
    );
  }

  Widget _progress() {
    return ValueListenableBuilder<Duration?>(
      valueListenable: paraAudio.duration,
      builder: (context, dur, _) {
        return ValueListenableBuilder<Duration>(
          valueListenable: paraAudio.position,
          builder: (context, pos, _) {
            if (dur == null || dur.inSeconds == 0) {
              return const Padding(
                padding: EdgeInsets.fromLTRB(4, 8, 4, 2),
                child: LinearProgressIndicator(minHeight: 3),
              );
            }
            final total = dur.inSeconds.toDouble();
            final cur = pos.inSeconds.clamp(0, dur.inSeconds).toDouble();
            return Padding(
              padding: const EdgeInsets.fromLTRB(0, 2, 0, 0),
              child: Row(
                children: [
                  Text(_fmt(pos), style: urStyle(size: 11.5)),
                  Expanded(
                    child: Slider(
                      value: cur,
                      max: total,
                      activeColor: AppColors.gold,
                      onChanged: (v) =>
                          paraAudio.seek(Duration(seconds: v.round())),
                    ),
                  ),
                  Text(_fmt(dur), style: urStyle(size: 11.5)),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
