import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';

/// جملے: فارسی جملے اردو ترجمے کے ساتھ، تلاش کے خانے سمیت
class SentencesScreen extends StatefulWidget {
  const SentencesScreen({super.key});

  @override
  State<SentencesScreen> createState() => _SentencesScreenState();
}

class _SentencesScreenState extends State<SentencesScreen> {
  late final List<Map<String, dynamic>> _all;
  String _q = '';

  @override
  void initState() {
    super.initState();
    _all = repo.list('sentences');
  }

  @override
  Widget build(BuildContext context) {
    final nq = normalize(_q);
    final shown = nq.isEmpty
        ? _all
        : _all
            .where((s) =>
                normalize('${str(s['fa'])} ${str(s['ur'])} ${str(s['ro'])}').contains(nq))
            .toList();
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('جملے')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _q = v),
              decoration: InputDecoration(
                hintText: 'جملہ تلاش کریں (عربی، اردو یا انگریزی)',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: cardFill(context),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                '${localDigits(shown.length)} جملے',
                style: TextStyle(color: cs.outline, fontSize: 13),
              ),
            ),
          ),
          Expanded(
            child: shown.isEmpty
                ? const EmptyState(message: 'ابھی کوئی جملہ شامل نہیں۔')
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 96),
                    itemCount: shown.length,
                    itemBuilder: (context, i) {
                      final s = shown[i];
                      return PhraseCard(
                        fa: str(s['fa']),
                        ur: str(s['ur']),
                        roman: str(s['ro']),
                        vocalized: str(s['v']),
                        words: s['w'] as List<dynamic>?,
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}
