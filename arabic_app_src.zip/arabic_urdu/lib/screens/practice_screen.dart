import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/repository.dart';
import '../sarf/sarf_engine.dart';
import '../theme.dart';

/// ایک مشقی سوال
class _Q {
  final String type; // معنی / لفظ / جملہ / صرف / خالی جگہ
  final String instruction; // اردو ہدایت
  final String arabic; // بڑا عربی متن (خالی ہو تو نہیں دکھے گا)
  final String urduPrompt; // اردو متن (الٹے سوال کے لیے)
  final List<String> options;
  final int correct;
  final bool optionsArabic;
  final String review; // نتیجہ کارڈ کے لیے: سوال + درست جواب
  const _Q(this.type, this.instruction, this.arabic, this.urduPrompt,
      this.options, this.correct, this.optionsArabic, this.review);
}

class PracticeScreen extends StatefulWidget {
  const PracticeScreen({super.key});
  @override
  State<PracticeScreen> createState() => _PracticeScreenState();
}

class _PracticeScreenState extends State<PracticeScreen> {
  final _rnd = Random();
  // ذخیرہ شدہ پیش رفت
  int _points = 0;
  int _bestStreak = 0;
  int _bestTimed = 0;
  final Map<String, List<int>> _stats = {}; // type -> [درست, کل]

  // ڈیٹا
  late final List<Map<String, dynamic>> _dict;
  late final List<Map<String, dynamic>> _sentences;
  late final List<Map<String, dynamic>> _bank;

  // کھیل کی حالت
  String _mode = ''; // '' = انتخاب، 'free'، 'timed'
  _Q? _q;
  int _qNo = 0;
  int _correctCount = 0;
  int _earned = 0;
  int _streak = 0;
  int? _picked;
  bool _finished = false;
  final List<String> _mistakes = [];
  final List<_Q> _retry = [];
  Timer? _timer;
  int _left = 60;

  static const _freeTotal = 10;

  @override
  void initState() {
    super.initState();
    _dict = repo
        .list('dictionary')
        .where((e) => str(e['fa']).isNotEmpty && str(e['ur']).isNotEmpty)
        .toList();
    _sentences = repo
        .list('sentences')
        .where((e) => str(e['fa']).isNotEmpty && str(e['ur']).isNotEmpty)
        .toList();
    _bank = repo
        .list('sarfbank')
        .where((e) => str(e['root']).isNotEmpty)
        .toList();
    _loadProgress();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _loadProgress() async {
    final p = await SharedPreferences.getInstance();
    setState(() {
      _points = p.getInt('practice_points') ?? 0;
      _bestStreak = p.getInt('practice_best_streak') ?? 0;
      _bestTimed = p.getInt('practice_best_timed') ?? 0;
      for (final t in ['معنی', 'لفظ', 'جملہ', 'صرف', 'خالی جگہ']) {
        final v = p.getString('practice_stat_$t');
        if (v != null) {
          final parts = v.split('/');
          _stats[t] = [int.tryParse(parts[0]) ?? 0, int.tryParse(parts[1]) ?? 0];
        }
      }
    });
  }

  Future<void> _saveProgress() async {
    final p = await SharedPreferences.getInstance();
    await p.setInt('practice_points', _points);
    await p.setInt('practice_best_streak', _bestStreak);
    await p.setInt('practice_best_timed', _bestTimed);
    for (final e in _stats.entries) {
      await p.setString('practice_stat_${e.key}', '${e.value[0]}/${e.value[1]}');
    }
  }

  int get _level => 1 + (_points ~/ 150);

  List<String> get _types {
    final t = <String>['معنی', 'لفظ'];
    if (_level >= 2 || _points >= 60) t.addAll(['جملہ', 'خالی جگہ']);
    if (_level >= 3 || _points >= 140) t.add('صرف');
    return t;
  }

  // ------------------------- سوالات کی تیاری -------------------------

  String _wordFa(Map<String, dynamic> e) =>
      str(e['v']).isNotEmpty ? str(e['v']) : str(e['fa']);

  List<String> _pick3<T>(List<T> pool, bool Function(T) ok, String Function(T) txt,
      String exclude) {
    final cands = pool.where(ok).map(txt).where((s) => s != exclude).toSet().toList()
      ..shuffle(_rnd);
    return cands.take(3).toList();
  }

  _Q? _makeWordToUrdu() {
    if (_dict.length < 4) return null;
    final e = _dict[_rnd.nextInt(_dict.length)];
    final opts = _pick3(_dict, (_) => true, (x) => str(x['ur']), str(e['ur']));
    if (opts.length < 3) return null;
    final all = [...opts, str(e['ur'])]..shuffle(_rnd);
    return _Q('معنی', 'اس عربی لفظ کا درست اردو معنی چنیں:', _wordFa(e), '', all,
        all.indexOf(str(e['ur'])), false, '${_wordFa(e)} — ${str(e['ur'])}');
  }

  _Q? _makeUrduToWord() {
    if (_dict.length < 4) return null;
    final e = _dict[_rnd.nextInt(_dict.length)];
    final target = _wordFa(e);
    final opts = _pick3(_dict, (_) => true, _wordFa, target);
    if (opts.length < 3) return null;
    final all = [...opts, target]..shuffle(_rnd);
    return _Q('لفظ', 'اس اردو معنی کا عربی لفظ چنیں:', '', str(e['ur']), all,
        all.indexOf(target), true, '${str(e['ur'])} — $target');
  }

  _Q? _makeSentence() {
    if (_sentences.length < 4) return null;
    final e = _sentences[_rnd.nextInt(_sentences.length)];
    final opts =
        _pick3(_sentences, (_) => true, (x) => str(x['ur']), str(e['ur']));
    if (opts.length < 3) return null;
    final all = [...opts, str(e['ur'])]..shuffle(_rnd);
    return _Q('جملہ', 'اس عربی جملے کا درست اردو ترجمہ چنیں:', str(e['fa']), '',
        all, all.indexOf(str(e['ur'])), false, '${str(e['fa'])} — ${str(e['ur'])}');
  }

  _Q? _makeSarf() {
    if (_bank.isEmpty) return null;
    final e = _bank[_rnd.nextInt(_bank.length)];
    final urFull = str(e['ur']);
    final urFirst = urFull.split('،').first.trim();
    SarfResult r;
    try {
      r = conjugate(str(e['root']), (e['bab'] as num).toInt(), str(e['masdar']),
          urFirst.isEmpty ? 'کرنا' : urFirst);
    } catch (_) {
      return null;
    }
    final groups = _level >= 4 ? r.groups : r.groups.take(3).toList();
    final g = groups[_rnd.nextInt(groups.length)];
    final f = g.forms[_rnd.nextInt(g.forms.length)];
    var distract = g.forms
        .where((x) => x.form != f.form)
        .map((x) => x.form)
        .toSet()
        .toList()
      ..shuffle(_rnd);
    if (distract.length < 3) {
      final extra = r.groups
          .expand((x) => x.forms)
          .map((x) => x.form)
          .where((x) => x != f.form && !distract.contains(x))
          .toSet()
          .toList()
        ..shuffle(_rnd);
      distract = [...distract, ...extra].take(3).toList();
    }
    if (distract.length < 3) return null;
    final all = [...distract.take(3), f.form]..shuffle(_rnd);
    final masdar = str(e['masdar']).isNotEmpty ? str(e['masdar']) : str(e['root']);
    return _Q(
        'صرف',
        'فعل «$masdar» (${urFirst.isEmpty ? urFull : urFirst}) — زمانہ «${g.name}» میں «${f.pronounAr}» کی درست صورت چنیں:',
        masdar,
        '',
        all,
        all.indexOf(f.form),
        true,
        '${g.name} • ${f.pronounAr} — ${f.form} (${f.urdu})');
  }

  static bool _isMark(int r) =>
      (r >= 0x064B && r <= 0x0652) || r == 0x0670 || r == 0x0640;

  static String _normChar(String c) {
    const m = {'أ': 'ا', 'إ': 'ا', 'آ': 'ا', 'ٱ': 'ا', 'ى': 'ي', 'ة': 'ه', 'ؤ': 'و', 'ئ': 'ي'};
    return m[c] ?? c;
  }

  /// جملے میں سے لفظ خالی کر دو؛ کامیابی پر (نیا جملہ، درست لفظ)
  (String, String)? _blankOut(Map<String, dynamic> s) {
    final fa = str(s['fa']);
    final words = asMaps(s['w']);
    if (words.isEmpty) return null;
    final fr = fa.runes.toList();
    final stripped = StringBuffer();
    final indexMap = <int>[];
    for (var i = 0; i < fr.length; i++) {
      if (_isMark(fr[i])) continue;
      indexMap.add(i);
      stripped.write(_normChar(String.fromCharCode(fr[i])));
    }
    final sfa = stripped.toString();
    final shuffled = [...words]..shuffle(_rnd);
    for (final w in shuffled) {
      final wf = str(w['f']);
      if (wf.isEmpty) continue;
      final wNorm = wf.runes
          .where((r) => !_isMark(r))
          .map((r) => _normChar(String.fromCharCode(r)))
          .join();
      if (wNorm.length < 2) continue;
      final idx = sfa.indexOf(wNorm);
      if (idx < 0) continue;
      final startRune = indexMap[idx];
      var endRune = idx + wNorm.length < indexMap.length
          ? indexMap[idx + wNorm.length]
          : fr.length;
      while (endRune < fr.length && _isMark(fr[endRune])) {
        endRune++;
      }
      final blanked =
          '${String.fromCharCodes(fr.sublist(0, startRune))} ‏_____ ‏${String.fromCharCodes(fr.sublist(endRune))}';
      return (blanked, wf);
    }
    return null;
  }

  _Q? _makeFill() {
    if (_sentences.isEmpty || _dict.length < 3) return null;
    final shuffledS = [..._sentences]..shuffle(_rnd);
    for (final s in shuffledS.take(6)) {
      final res = _blankOut(s);
      if (res == null) continue;
      final (blanked, answer) = res;
      final pool = <String>{
        for (final d in _dict) str(d['fa']),
        for (final ss in _sentences)
          for (final w in asMaps(ss['w'])) str(w['f']),
      }..remove(answer);
      final opts = pool.toList()..shuffle(_rnd);
      if (opts.length < 3) continue;
      final all = [...opts.take(3), answer]..shuffle(_rnd);
      return _Q('خالی جگہ', 'جملے میں خالی جگہ کے لیے درست لفظ چنیں:', blanked, '',
          all, all.indexOf(answer), true, '$blanked — $answer');
    }
    return null;
  }

  _Q _nextQuestion() {
    // غلط ہوئے سوال پہلے دوبارہ (مشق خودکار بڑھتی ہے)
    if (_retry.isNotEmpty && _qNo % 3 == 2) {
      return _retry.removeAt(0);
    }
    final types = _types;
    // جس قسم میں غلطیاں زیادہ، اس کا وزن زیادہ
    final weighted = <String>[];
    for (final t in types) {
      final st = _stats[t] ?? [0, 0];
      final wrong = st[1] - st[0];
      weighted.add(t);
      if (wrong >= 2) weighted.add(t);
      if (wrong >= 5) weighted.add(t);
    }
    final order = [...weighted]..shuffle(_rnd);
    for (final t in order) {
      final q = switch (t) {
        'معنی' => _makeWordToUrdu(),
        'لفظ' => _makeUrduToWord(),
        'جملہ' => _makeSentence(),
        'صرف' => _makeSarf(),
        _ => _makeFill(),
      };
      if (q != null) return q;
    }
    return _makeWordToUrdu() ?? _makeUrduToWord()!;
  }

  // ------------------------- کھیل کا بہاؤ -------------------------

  void _start(String mode) {
    _timer?.cancel();
    setState(() {
      _mode = mode;
      _qNo = 0;
      _correctCount = 0;
      _earned = 0;
      _streak = 0;
      _picked = null;
      _finished = false;
      _mistakes.clear();
      _retry.clear();
      _left = 60;
      _q = _nextQuestion();
    });
    if (mode == 'timed') {
      _timer = Timer.periodic(const Duration(seconds: 1), (t) {
        if (!mounted) return;
        setState(() => _left--);
        if (_left <= 0) _finish();
      });
    }
  }

  void _answer(int i) {
    if (_q == null || _picked != null || _finished) return;
    final q = _q!;
    final ok = i == q.correct;
    setState(() {
      _picked = i;
      _stats.putIfAbsent(q.type, () => [0, 0]);
      _stats[q.type]![1]++;
      if (ok) {
        _stats[q.type]![0]++;
        _correctCount++;
        _streak++;
        if (_streak > _bestStreak) _bestStreak = _streak;
        var gain = 10;
        if (_streak % 5 == 0) gain += 5; // اسٹریک انعام
        _earned += gain;
        _points += gain;
      } else {
        _streak = 0;
        _mistakes.add(q.review);
        if (_mode == 'free') _retry.add(q);
      }
    });
    _saveProgress();
    if (_mode == 'timed') {
      Future.delayed(const Duration(milliseconds: 850), () {
        if (mounted && _mode == 'timed' && !_finished) _advance();
      });
    }
  }

  void _advance() {
    if (_mode == 'free' && _qNo + 1 >= _freeTotal) {
      _finish();
      return;
    }
    setState(() {
      _qNo++;
      _picked = null;
      _q = _nextQuestion();
    });
  }

  void _finish() {
    _timer?.cancel();
    setState(() {
      _finished = true;
      if (_mode == 'timed' && _earned > _bestTimed) _bestTimed = _earned;
    });
    _saveProgress();
  }

  // ------------------------- UI -------------------------

  @override
  Widget build(BuildContext context) {
    final dark = Theme.of(context).brightness == Brightness.dark;
    final blue = dark ? const Color(0xFF82B1FF) : const Color(0xFF1565C0);
    const yellow = Color(0xFFFFD740);
    return Scaffold(
      appBar: AppBar(title: const Text('مشق و کھیل')),
      body: _mode == ''
          ? _homeView(blue, yellow)
          : _finished
              ? _resultView(blue)
              : _playView(blue, yellow, dark),
    );
  }

  Widget _statChip(IconData icon, String text, Color color) => Chip(
        avatar: Icon(icon, size: 17, color: color),
        label: Text(text, style: const TextStyle(fontWeight: FontWeight.w700)),
      );

  Widget _homeView(Color blue, Color yellow) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardFill(context),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.gold.withAlpha(120)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('اپنی عربی آزمائیں — کھیل کھیل میں سیکھیں',
                  style: TextStyle(
                      fontSize: 19, fontWeight: FontWeight.w900, color: blue)),
              const SizedBox(height: 8),
              Text(
                  'سوالات ایپ کے الفاظ، جملوں اور گردان سے خودکار بنتے ہیں۔ جتنے پوائنٹس بڑھیں گے، مشق اتنی ہی اونچی سطح کی اور مشکل ہوتی جائے گی؛ غلط ہونے والی اقسام دوبارہ آئیں گی۔',
                  style: urStyle(size: 14.5)),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                runSpacing: 4,
                children: [
                  _statChip(Icons.stars_rounded, 'سطح ${_level}', blue),
                  _statChip(Icons.score_rounded, 'پوائنٹس $_points', blue),
                  _statChip(Icons.local_fire_department_rounded,
                      'بہترین اسٹریک $_bestStreak', Colors.orange),
                  if (_bestTimed > 0)
                    _statChip(Icons.timer_rounded, 'وقتی بہترین $_bestTimed', blue),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 18),
        FilledButton.icon(
          onPressed: () => _start('free'),
          icon: const Icon(Icons.play_arrow_rounded),
          label: const Text('آزاد مشق — ۱۰ سوال'),
          style: FilledButton.styleFrom(
              minimumSize: const Size.fromHeight(54),
              textStyle:
                  const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
        ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: () => _start('timed'),
          icon: const Icon(Icons.timer_rounded),
          label: const Text('دماغ کا امتحان — ۶۰ سیکنڈ'),
          style: FilledButton.styleFrom(
              backgroundColor: const Color(0xFFB3261E),
              minimumSize: const Size.fromHeight(54),
              textStyle:
                  const TextStyle(fontSize: 17, fontWeight: FontWeight.w800)),
        ),
        const SizedBox(height: 16),
        Text('سوالات کی اقسام',
            style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.w800, color: blue)),
        const SizedBox(height: 6),
        Text(
            '• عربی لفظ کا اردو معنی\n• اردو معنی سے عربی لفظ\n• عربی جملے کا اردو ترجمہ\n• خالی جگہ پُر کرنا\n• صرف و گردان کی درست صورت (اونچی سطح پر)',
            style: urStyle(size: 14.5)),
      ],
    );
  }

  Widget _playView(Color blue, Color yellow, bool dark) {
    final q = _q;
    if (q == null) {
      return const Center(child: Text('سوالات تیار نہیں ہو سکے'));
    }
    final total = _mode == 'free' ? _freeTotal : null;
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Row(
          children: [
            _statChip(Icons.help_rounded,
                total != null ? 'سوال ${_qNo + 1} از $total' : 'سوال ${_qNo + 1}',
                blue),
            const SizedBox(width: 6),
            _statChip(Icons.score_rounded, '$_earned', blue),
            const SizedBox(width: 6),
            _statChip(Icons.local_fire_department_rounded, '$_streak',
                Colors.orange),
            const Spacer(),
            if (_mode == 'timed')
              Chip(
                avatar: Icon(Icons.timer_rounded,
                    size: 17, color: _left <= 10 ? Colors.red : blue),
                label: Text('$_left ثانیے',
                    style: TextStyle(
                        fontWeight: FontWeight.w900,
                        color: _left <= 10 ? Colors.red : null)),
              ),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: cardFill(context),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: blue.withAlpha(90)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Chip(
                  label: Text(q.type,
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  backgroundColor: AppColors.gold.withAlpha(60)),
              const SizedBox(height: 8),
              Text(q.instruction, style: urStyle(size: 15.5)),
              if (q.arabic.isNotEmpty) ...[
                const SizedBox(height: 10),
                Center(
                  child: Text(q.arabic,
                      textAlign: TextAlign.center,
                      style: faStyle(size: 27)),
                ),
              ],
              if (q.urduPrompt.isNotEmpty) ...[
                const SizedBox(height: 10),
                Center(
                  child: Text(q.urduPrompt,
                      textAlign: TextAlign.center,
                      style: urStyle(size: 19)),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 14),
        for (var i = 0; i < q.options.length; i++) ...[
          _optionTile(q, i, dark),
          const SizedBox(height: 8),
        ],
        if (_picked != null) ...[
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _picked == q.correct
                  ? Colors.green.withAlpha(38)
                  : Colors.red.withAlpha(32),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Text(
              _picked == q.correct
                  ? 'درست! شاباش — اسٹریک $_streak'
                  : 'غلط — درست جواب: ${q.options[q.correct]}',
              style: urStyle(size: 15),
            ),
          ),
          if (_mode == 'free') ...[
            const SizedBox(height: 10),
            FilledButton(
              onPressed: _advance,
              style: FilledButton.styleFrom(
                  minimumSize: const Size.fromHeight(50)),
              child: Text(_qNo + 1 >= _freeTotal ? 'نتیجہ دیکھیں' : 'اگلا سوال'),
            ),
          ],
        ],
      ],
    );
  }

  Widget _optionTile(_Q q, int i, bool dark) {
    final picked = _picked;
    Color? bg;
    if (picked != null) {
      if (i == q.correct) {
        bg = Colors.green.withAlpha(70);
      } else if (i == picked) {
        bg = Colors.red.withAlpha(60);
      }
    }
    return Material(
      color: bg ?? cardFill(context),
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () => _answer(i),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
                color: Theme.of(context).colorScheme.outlineVariant),
          ),
          child: q.optionsArabic
              ? Text(q.options[i], style: faStyle(size: 21))
              : Text(q.options[i], style: urStyle(size: 16)),
        ),
      ),
    );
  }

  Widget _resultView(Color blue) {
    final total = _mode == 'free' ? _freeTotal : _qNo + (_picked != null ? 1 : 0);
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: cardFill(context),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.gold.withAlpha(130)),
          ),
          child: Column(
            children: [
              const Icon(Icons.emoji_events_rounded,
                  size: 52, color: Color(0xFFC9A227)),
              const SizedBox(height: 8),
              Text(_mode == 'timed' ? 'وقت ختم — نتیجہ' : 'راؤنڈ مکمل — نتیجہ',
                  style: TextStyle(
                      fontSize: 20, fontWeight: FontWeight.w900, color: blue)),
              const SizedBox(height: 10),
              Text('درست جواب: $_correctCount از $total',
                  style: urStyle(size: 17)),
              Text('حاصل پوائنٹس: $_earned', style: urStyle(size: 17)),
              Text('موجودہ سطح: $_level  •  کل پوائنٹس: $_points',
                  style: urStyle(size: 15)),
              if (_mode == 'timed')
                Text('وقتی موڈ کا بہترین اسکور: $_bestTimed',
                    style: urStyle(size: 15)),
            ],
          ),
        ),
        if (_mistakes.isNotEmpty) ...[
          const SizedBox(height: 16),
          Text('غلط سوالوں کے درست جواب',
              style: TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w800, color: blue)),
          const SizedBox(height: 8),
          for (final m in _mistakes)
            Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: cardFill(context),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(m, style: urStyle(size: 14.5)),
            ),
        ] else ...[
          const SizedBox(height: 16),
          Text('کوئی غلطی نہیں — بہت خوب!', style: urStyle(size: 16)),
        ],
        const SizedBox(height: 14),
        FilledButton.icon(
          onPressed: () => _start(_mode),
          icon: const Icon(Icons.replay_rounded),
          label: const Text('پھر کھیلیں'),
          style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(50)),
        ),
        const SizedBox(height: 8),
        OutlinedButton(
          onPressed: () => setState(() => _mode = ''),
          style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
          child: const Text('مشق کے آغاز پر واپس'),
        ),
      ],
    );
  }
}
