import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';
import 'book_page_screen.dart';

/// اسباق / بول چال / کہانیاں / شاعری کی فہرست — تلاش کے ساتھ
/// ڈیٹا کی شکل: [{title, subtitle, items: [{fa, ur, who?}]}]
class CollectionScreen extends StatefulWidget {
  final String dataKey;
  final String title;
  const CollectionScreen({super.key, required this.dataKey, required this.title});

  @override
  State<CollectionScreen> createState() => _CollectionScreenState();
}

class _CollectionScreenState extends State<CollectionScreen> {
  String _q = '';

  bool _itemMatches(Map<String, dynamic> it, String nq) =>
      normalize('${str(it['fa'])} ${str(it['ur'])} ${str(it['who'])} ${str(it['ro'])}')
          .contains(nq);

  @override
  Widget build(BuildContext context) {
    final sets = repo.list(widget.dataKey);
    final cs = Theme.of(context).colorScheme;
    final nq = normalize(_q);
    // ہر سیٹ کے ساتھ: عنوان ملا؟ اور کتنے جملے ملے؟
    final shown = <(Map<String, dynamic>, bool, int)>[];
    for (final s in sets) {
      final items = asMaps(s['items']);
      if (nq.isEmpty) {
        shown.add((s, true, items.length));
        continue;
      }
      final titleHit = normalize(
              '${str(s['title'])} ${str(s['subtitle'])} ${str(s['body'])}')
          .contains(nq);
      final matched = items.where((it) => _itemMatches(it, nq)).length;
      if (titleHit || matched > 0) shown.add((s, titleHit, matched));
    }
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: sets.isEmpty
          ? const EmptyState(
              message: 'ابھی یہاں کوئی مواد نہیں۔\nآن لائن اپڈیٹ سے نیا مواد حاصل کریں۔')
          : Column(
              children: [
                SearchBox(
                  hint: 'عنوان یا جملہ تلاش کریں…',
                  onChanged: (v) => setState(() => _q = v),
                ),
                Expanded(
                  child: shown.isEmpty
                      ? const EmptyState(message: 'کوئی نتیجہ نہیں ملا۔')
                      : ListView.builder(
                          padding: const EdgeInsets.only(top: 4, bottom: 24),
                          itemCount: shown.length,
                          itemBuilder: (context, i) {
                            final (s, titleHit, matched) = shown[i];
                            final count = asMaps(s['items']).length;
                            final sub = str(s['subtitle']);
                            final searching = nq.isNotEmpty;
                            final detail = searching && !titleHit
                                ? '${localDigits(matched)} جملے ملے'
                                : (str(s['body']).isNotEmpty && count == 0
                                    ? 'کتاب کا صفحہ'
                                    : '$count جملے');
                            return Container(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 6),
                              decoration: BoxDecoration(
                                color: cardFill(context),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                    color: cs.outlineVariant.withAlpha(110)),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withAlpha(16),
                                    blurRadius: 14,
                                    offset: const Offset(0, 5),
                                  ),
                                ],
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 6),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20)),
                                leading: CircleAvatar(
                                  backgroundColor: cs.primary.withAlpha(30),
                                  foregroundColor: cs.primary,
                                  child: Text(
                                      '${localDigits(sets.indexOf(s) + 1)}',
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w800)),
                                ),
                                title: Text(str(s['title']),
                                    style: const TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700)),
                                subtitle: Text(
                                  sub.isEmpty ? detail : '$sub  ·  $detail',
                                ),
                                trailing:
                                    const Icon(Icons.chevron_left_rounded),
                                onTap: () => Navigator.of(context).push(
                                  MaterialPageRoute(
                                    builder: (_) =>
                                        // کتابی سبق (سیدھا متن) — خانوں کی بجائے صفحے کی طرح
                                        str(s['body']).isNotEmpty &&
                                                asMaps(s['items']).isEmpty
                                            ? BookPageScreen(item: s)
                                            : PhraseSetScreen(
                                                data: s,
                                                initialQuery:
                                                    (searching && !titleHit)
                                                        ? _q
                                                        : '',
                                              ),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

/// ایک سبق / مکالمہ / کہانی / نظم کے جملے — اندر بھی تلاش
class PhraseSetScreen extends StatefulWidget {
  final Map<String, dynamic> data;
  final String initialQuery;
  const PhraseSetScreen({super.key, required this.data, this.initialQuery = ''});

  @override
  State<PhraseSetScreen> createState() => _PhraseSetScreenState();
}

class _PhraseSetScreenState extends State<PhraseSetScreen> {
  late String _q = widget.initialQuery;

  @override
  Widget build(BuildContext context) {
    final items = asMaps(widget.data['items']);
    final title = str(widget.data['title']);
    final sub = str(widget.data['subtitle']);
    final nq = normalize(_q);
    final shown = nq.isEmpty
        ? items
        : items
            .where((it) => normalize(
                    '${str(it['fa'])} ${str(it['ur'])} ${str(it['who'])} ${str(it['ro'])}')
                .contains(nq))
            .toList();
    final all = StringBuffer(title);
    for (final it in items) {
      all.write('\n\n${str(it['fa'])}\n${str(it['ur'])}');
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          IconButton(
            tooltip: 'پورا شیئر کریں',
            icon: const Icon(Icons.ios_share_rounded),
            onPressed: () => shareText(all.toString()),
          ),
        ],
      ),
      body: Column(
        children: [
          SearchBox(
            hint: 'اس حصے میں تلاش کریں…',
            initialValue: widget.initialQuery,
            onChanged: (v) => setState(() => _q = v),
          ),
          Expanded(
            child: shown.isEmpty
                ? const EmptyState(message: 'کوئی جملہ نہیں ملا۔')
                : ListView(
                    padding: const EdgeInsets.only(top: 4, bottom: 28),
                    children: [
                      if (sub.isNotEmpty)
                        Padding(
                          padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                          child: Text(sub,
                              style: TextStyle(
                                  color:
                                      Theme.of(context).colorScheme.outline)),
                        ),
                      for (final it in shown)
                        PhraseCard(
                          fa: str(it['fa']),
                          ur: str(it['ur']),
                          who: str(it['who']).isEmpty ? null : str(it['who']),
                          roman: str(it['ro']),
                          vocalized: str(it['v']),
                          words: it['w'] as List<dynamic>?,
                        ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}

/// گرامر / مضامین کی فہرست — عنوان اور متن میں تلاش
/// ڈیٹا کی شکل: [{title, body}]
class TextCollectionScreen extends StatefulWidget {
  final String dataKey;
  final String title;
  const TextCollectionScreen({super.key, required this.dataKey, required this.title});

  @override
  State<TextCollectionScreen> createState() => _TextCollectionScreenState();
}

class _TextCollectionScreenState extends State<TextCollectionScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final items = repo.list(widget.dataKey);
    final cs = Theme.of(context).colorScheme;
    final nq = normalize(_q);
    final shown = nq.isEmpty
        ? items
        : items
            .where((it) =>
                normalize('${str(it['title'])} ${str(it['body'])}').contains(nq))
            .toList();
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: items.isEmpty
          ? const EmptyState(
              message: 'ابھی یہاں کوئی مواد نہیں۔\nآن لائن اپڈیٹ سے نیا مواد حاصل کریں۔')
          : Column(
              children: [
                SearchBox(
                  hint: 'عنوان یا متن تلاش کریں…',
                  onChanged: (v) => setState(() => _q = v),
                ),
                Expanded(
                  child: shown.isEmpty
                      ? const EmptyState(message: 'کوئی نتیجہ نہیں ملا۔')
                      : ListView.builder(
                          padding: const EdgeInsets.only(top: 4, bottom: 24),
                          itemCount: shown.length,
                          itemBuilder: (context, i) {
                            final it = shown[i];
                            return Container(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 6),
                              decoration: BoxDecoration(
                                color: cardFill(context),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                    color: cs.outlineVariant.withAlpha(110)),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withAlpha(16),
                                    blurRadius: 14,
                                    offset: const Offset(0, 5),
                                  ),
                                ],
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 6),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(20)),
                                leading: CircleAvatar(
                                  backgroundColor:
                                      AppColors.gold.withAlpha(40),
                                  foregroundColor: AppColors.gold,
                                  child: const Icon(Icons.notes_rounded),
                                ),
                                title: Text(str(it['title']),
                                    style: const TextStyle(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w700)),
                                trailing:
                                    const Icon(Icons.chevron_left_rounded),
                                onTap: () => Navigator.of(context).push(
                                  MaterialPageRoute(
                                      builder: (_) =>
                                          TextDetailScreen(item: it)),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

class TextDetailScreen extends StatelessWidget {
  final Map<String, dynamic> item;
  const TextDetailScreen({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final title = str(item['title']);
    final body = str(item['body']);
    final full = '$title\n\n$body';
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          IconButton(
            tooltip: 'کاپی',
            icon: const Icon(Icons.copy_rounded),
            onPressed: () => copyText(context, full),
          ),
          IconButton(
            tooltip: 'شیئر',
            icon: const Icon(Icons.ios_share_rounded),
            onPressed: () => shareText(full),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Theme.of(context).brightness == Brightness.dark
                  ? const Color(0xFF0D1526)
                  : Colors.white,
              borderRadius: BorderRadius.circular(22),
              border: Border.all(
                  color: Theme.of(context).brightness == Brightness.dark
                      ? const Color(0xFF2A3F66)
                      : const Color(0xFFB9CBE8)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final raw in body.split('\n')) _line(context, raw),
              ],
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => openFeedback(context, full),
            icon: const Icon(Icons.edit_note_rounded),
            label: const Text('تصحیح / اضافے کی تجویز'),
          ),
        ],
      ),
    );
  }

  // رنگ صرف تین: پیلا، نیلا، سفید/گہرا — ڈارک موڈ میں روشن اور لائٹ موڈ میں گاڑھے،
  // تاکہ دونوں موڈوں میں صاف نظر آئیں؛ بھورا اور سبز ختم (Ayesh کی ہدایت، 26 اکتوبر)
  Color _yellow(BuildContext c) => Theme.of(c).brightness == Brightness.dark
      ? const Color(0xFFFFD740)
      : const Color(0xFF9C7C00);
  Color _blue(BuildContext c) => Theme.of(c).brightness == Brightness.dark
      ? const Color(0xFF82B1FF)
      : const Color(0xFF0D47A1);
  Color _urdu(BuildContext c) => Theme.of(c).brightness == Brightness.dark
      ? const Color(0xFFFFFFFF)
      : const Color(0xFF10243E);

  bool _isSentence(String ar) {
    final words =
        ar.split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (ar.contains('؟') || ar.contains('!')) return true;
    if (words.length >= 3) return true;
    if (words.length == 2) {
      const starters = {
        'هُوَ', 'هِيَ', 'هُمْ', 'هُمَا', 'هُنَّ', 'أَنَا', 'نَحْنُ',
        'أَنْتَ', 'أَنْتِ', 'أَنْتُمْ', 'أَنْتُنَّ', 'هَذَا', 'هَذِهِ',
        'هَذَانِ', 'هَاتَانِ', 'هَؤُلَاءِ', 'ذَلِكَ', 'تِلْكَ', 'أُولَئِكَ',
      };
      if (starters.contains(words[0])) return true;
      if (words[0].startsWith('إِنَّ')) return true;
    }
    return false;
  }

  Widget _line(BuildContext context, String raw) {
    final line = raw.trim();
    if (line.isEmpty) return const SizedBox(height: 10);
    final yellow = _yellow(context);
    final blue = _blue(context);
    final urdu = _urdu(context);
    final sep = Theme.of(context).brightness == Brightness.dark
        ? const Color(0x8AFFFFFF)
        : const Color(0xFF8A97A8);
    // حصے کا عنوان: ١) ...
    if (RegExp(r'^[١٢٣٤٥٦٧٨٩٠]+\)').hasMatch(line)) {
      return Padding(
        padding: const EdgeInsets.only(top: 18, bottom: 6),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 5,
              height: 26,
              margin: const EdgeInsets.only(left: 10, top: 4),
              decoration: BoxDecoration(
                color: blue,
                borderRadius: BorderRadius.circular(3),
              ),
            ),
            Expanded(
              child: Text(
                line,
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w800,
                  color: yellow,
                  height: 1.9,
                ),
              ),
            ),
          ],
        ),
      );
    }
    // ذیلی عنوان: آخر میں :
    if (line.endsWith(':') || line.endsWith('：')) {
      return Padding(
        padding: const EdgeInsets.only(top: 12, bottom: 2),
        child: Text(
          line,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: blue,
            height: 1.9,
          ),
        ),
      );
    }
    // جوڑا: عربی — اردو
    final di = line.indexOf(' — ');
    if (di > 0) {
      var left = line.substring(0, di);
      final right = line.substring(di + 3);
      String? label;
      final ci = left.indexOf(': ');
      if (ci > 0 && ci < 10) {
        label = left.substring(0, ci);
        left = left.substring(ci + 2);
      }
      final sentence = _isSentence(left);
      return Padding(
        padding: const EdgeInsets.symmetric(vertical: 2.5),
        child: RichText(
          text: TextSpan(
            children: [
              if (label != null)
                TextSpan(
                  text: '$label: ',
                  style: TextStyle(
                    fontSize: 16.5,
                    fontWeight: FontWeight.w800,
                    color: yellow,
                    height: 1.9,
                  ),
                ),
              TextSpan(
                text: left,
                style: faStyle(
                  size: 20,
                  w: FontWeight.w700,
                  color: sentence ? blue : yellow,
                ),
              ),
              TextSpan(
                text: ' — ',
                style: TextStyle(fontSize: 16, color: sep),
              ),
              TextSpan(
                text: right,
                style: urStyle(size: 16.5, color: urdu)
                    .copyWith(fontWeight: FontWeight.w600),
              ),
            ],
          ),
        ),
      );
    }
    // سادہ سطر: عربی الفاظ پیلے، باقی اردو رنگ میں
    final spans = <TextSpan>[];
    for (final m in RegExp(r'\S+|\s+').allMatches(line)) {
      final tok = m.group(0)!;
      final isArabic = RegExp(r'[؀-ۿ]').hasMatch(tok) &&
          RegExp(r'[ا-ي]').hasMatch(tok);
      spans.add(TextSpan(
        text: tok,
        style: isArabic
            ? faStyle(size: 19, w: FontWeight.w700, color: yellow)
            : TextStyle(fontSize: 16.5, height: 1.9, color: urdu),
      ));
    }
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2.5),
      child: RichText(text: TextSpan(children: spans)),
    );
  }
}
