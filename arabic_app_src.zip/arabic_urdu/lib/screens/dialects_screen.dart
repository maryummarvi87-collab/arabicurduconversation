import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';
import '../widgets/detail_sheet.dart';

/// فارسی کے لہجے: ایران، افغانستان (دری)، تاجکستان — تلاش کے ساتھ
/// ڈیٹا کی شکل: [{name, region, note, phrases: [{ur, fa}]}]
class DialectsScreen extends StatefulWidget {
  const DialectsScreen({super.key});

  @override
  State<DialectsScreen> createState() => _DialectsScreenState();
}

class _DialectsScreenState extends State<DialectsScreen> {
  String _q = '';

  bool _phraseMatches(Map<String, dynamic> p, String nq) {
    if (_isComparison(p)) {
      return normalize(
              '${str(p['lit'])} ${str(p['ir'])} ${str(p['da'])} ${str(p['ta'])} ${str(p['ur'])}')
          .contains(nq);
    }
    return normalize('${str(p['fa'])} ${str(p['ur'])} ${str(p['ro'])}').contains(nq);
  }

  @override
  Widget build(BuildContext context) {
    final dialects = repo.list('dialects');
    final cs = Theme.of(context).colorScheme;
    final nq = normalize(_q);
    final searching = nq.isNotEmpty;
    // تلاش ہو تو صرف ملنے والے جملے اور لہجے دکھاؤ
    final visible = <(Map<String, dynamic>, List<Map<String, dynamic>>)>[];
    for (final d in dialects) {
      final phrases = asMaps(d['phrases']);
      if (!searching) {
        visible.add((d, phrases));
        continue;
      }
      final nameHit =
          normalize('${str(d['name'])} ${str(d['region'])}').contains(nq);
      final matched =
          nameHit ? phrases : phrases.where((p) => _phraseMatches(p, nq)).toList();
      if (matched.isNotEmpty) visible.add((d, matched));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('عربی لہجے')),
      body: dialects.isEmpty
          ? const EmptyState(message: 'ابھی لہجوں کا مواد موجود نہیں۔')
          : Column(
              children: [
                SearchBox(
                  hint: 'لہجوں میں تلاش کریں…',
                  onChanged: (v) => setState(() => _q = v),
                ),
                Expanded(
                  child: visible.isEmpty
                      ? const EmptyState(message: 'کوئی جملہ نہیں ملا۔')
                      : ListView.builder(
                          padding: const EdgeInsets.only(top: 4, bottom: 24),
                          itemCount: visible.length,
                          itemBuilder: (context, i) {
                            final (d, phrases) = visible[i];
                            final note = str(d['note']);
                            return Container(
                              margin: const EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 6),
                              decoration: BoxDecoration(
                                color: cardFill(context),
                                borderRadius: BorderRadius.circular(20),
                                border: Border.all(
                                    color: cs.outlineVariant.withAlpha(110)),
                              ),
                              clipBehavior: Clip.antiAlias,
                              child: Theme(
                                data: Theme.of(context)
                                    .copyWith(dividerColor: Colors.transparent),
                                child: ExpansionTile(
                                  initiallyExpanded: i == 0 || searching,
                                  leading: CircleAvatar(
                                    backgroundColor:
                                        AppColors.emerald.withAlpha(35),
                                    foregroundColor: AppColors.emerald,
                                    child: const Icon(
                                        Icons.record_voice_over_rounded),
                                  ),
                                  title: Text(str(d['name']),
                                      style: const TextStyle(
                                          fontSize: 16.5,
                                          fontWeight: FontWeight.w700)),
                                  subtitle: Text(str(d['region'])),
                                  childrenPadding:
                                      const EdgeInsets.only(bottom: 10),
                                  children: [
                                    if (note.isNotEmpty)
                                      Padding(
                                        padding: const EdgeInsets.fromLTRB(
                                            20, 0, 20, 8),
                                        child: Text(note,
                                            style: TextStyle(
                                                color: cs.outline)),
                                      ),
                                    for (final p in phrases)
                                      _isComparison(p)
                                          ? _ComparisonCard(p: p)
                                          : PhraseCard(
                                              fa: str(p['fa']),
                                              ur: str(p['ur']),
                                              roman: str(p['ro']),
                                              vocalized: str(p['v']),
                                              words: p['w'] as List<dynamic>?,
                                            ),
                                  ],
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

/// لہجوں کا موازنہ: ادبی، ایرانی، دری، تاجیکی
bool _isComparison(Map<String, dynamic> p) =>
    p.containsKey('lit') ||
    p.containsKey('ir') ||
    p.containsKey('da') ||
    p.containsKey('ta');

class _ComparisonCard extends StatelessWidget {
  final Map<String, dynamic> p;
  const _ComparisonCard({required this.p});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final rows = [
      ('📜 ادبی', str(p['lit'])),
      ('🇮🇷 ایرانی', str(p['ir'])),
      ('🇦🇫 دری', str(p['da'])),
      ('🇹🇯 تاجیکی', str(p['ta'])),
    ];
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => openDetail(
            context,
            fa: str(p['lit']),
            ur: str(p['ur']),
            tag: 'لہجوں کا فرق',
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 8),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (final r in rows)
                  if (r.$2.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 3),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            width: 86,
                            child: Text(r.$1,
                                style: TextStyle(
                                    fontSize: 13,
                                    color: cs.primary,
                                    fontWeight: FontWeight.w700)),
                          ),
                          Expanded(
                              child: Text(r.$2, style: faStyle(size: 18))),
                        ],
                      ),
                    ),
                if (str(p['ur']).isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 4),
                    child: Text(str(p['ur']),
                        style:
                            urStyle(color: cs.onSurface.withAlpha(200))),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
