import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../data/repository.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// تصحیح، اضافہ یا تجویز بھیجنے کا فارم
class FeedbackScreen extends StatefulWidget {
  final String prefill;
  const FeedbackScreen({super.key, this.prefill = ''});

  @override
  State<FeedbackScreen> createState() => _FeedbackScreenState();
}

class _FeedbackScreenState extends State<FeedbackScreen> {
  static const _types = ['تصحیح', 'اضافہ', 'تجویز'];
  String _type = _types.first;
  late final TextEditingController _text;
  final _name = TextEditingController();
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _text = TextEditingController(
        text: widget.prefill.isEmpty ? '' : 'متعلقہ متن:\n${widget.prefill}\n\nتصحیح / تجویز:\n');
    _type = widget.prefill.isEmpty ? _types[1] : _types[0];
  }

  @override
  void dispose() {
    _text.dispose();
    _name.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final body = _text.text.trim();
    if (body.isEmpty) {
      showSnack(context, 'پہلے اپنی بات لکھیں');
      return;
    }
    final full = '$body\n\nنام: ${_name.text.trim()}\nمواد کا ورژن: ${repo.version}';
    setState(() => _busy = true);
    try {
      if (AppConfig.feedbackPostUrl.isNotEmpty) {
        final res = await http
            .post(
              Uri.parse(AppConfig.feedbackPostUrl),
              headers: {'Content-Type': 'application/json; charset=utf-8'},
              body: json.encode({
                'type': _type,
                'text': body,
                'name': _name.text.trim(),
                'version': repo.version,
              }),
            )
            .timeout(const Duration(seconds: 20));
        if (!mounted) return;
        if (res.statusCode >= 200 && res.statusCode < 300) {
          showSnack(context, 'شکریہ! آپ کی تجویز بھیج دی گئی۔');
          Navigator.of(context).pop();
        } else {
          showSnack(context, 'بھیجنے میں مسئلہ آیا۔ دوبارہ کوشش کریں۔');
        }
      } else {
        // ویب سائٹ کے تصحیح فارم پر بھیجیں (ای میل کی جگہ)
        final uri = Uri.parse(
            '${AppConfig.appLink}?correct=${Uri.encodeComponent('[$_type]\n$full')}');
        final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
        if (!mounted) return;
        if (!ok) showSnack(context, 'ویب سائٹ نہیں کھل سکی۔');
      }
    } catch (_) {
      if (mounted) showSnack(context, 'بھیجنے میں مسئلہ آیا۔ انٹرنیٹ چیک کریں۔');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('تصحیح و اضافہ')),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 96),
        children: [
          Text(
            'کوئی غلطی نظر آئے یا کوئی لفظ، جملہ یا سبق شامل کروانا ہو تو یہاں لکھ بھیجیں۔',
            style: TextStyle(color: cs.outline),
          ),
          const SizedBox(height: 14),
          Wrap(
            spacing: 8,
            children: [
              for (final t in _types)
                ChoiceChip(
                  label: Text(t),
                  selected: _type == t,
                  onSelected: (_) => setState(() => _type = t),
                ),
            ],
          ),
          const SizedBox(height: 14),
          TextField(
            controller: _text,
            minLines: 7,
            maxLines: 14,
            decoration: InputDecoration(
              hintText: 'یہاں لکھیں…',
              filled: true,
              fillColor: cardFill(context),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _name,
            decoration: InputDecoration(
              hintText: 'آپ کا نام (اختیاری)',
              prefixIcon: const Icon(Icons.person_outline_rounded),
              filled: true,
              fillColor: cardFill(context),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          const SizedBox(height: 18),
          FilledButton.icon(
            onPressed: _busy ? null : _send,
            icon: _busy
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.send_rounded),
            label: Text(AppConfig.feedbackPostUrl.isEmpty
                ? 'ویب سائٹ پر بھیجیں'
                : 'بھیجیں'),
            style: FilledButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 14),
            ),
          ),
        ],
      ),
    );
  }
}
