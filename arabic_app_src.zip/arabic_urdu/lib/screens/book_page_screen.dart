import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../services/tts_service.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/ayah_card.dart';
import '../widgets/common.dart';
import '../widgets/sentence_detail.dart';
import '../widgets/word_tap_text.dart';

/// کتابی سبق کا صفحہ — کتاب کی طرح سیدھا بہتا ہوا متن، خوبصورت رنگوں میں۔
/// ہر سطر: اعراب‌دار فارسی — رومن — اردو معنی؛ فارسی لفظ پر ٹچ کرنے سے معنی کھلتا ہے۔
/// اوپر کاپی اور شیئر کے بٹن — پورا سبق ایک ٹچ میں کاپی ہو جاتا ہے۔
class BookPageScreen extends StatefulWidget {
  final Map<String, dynamic> item;
  const BookPageScreen({super.key, required this.item});

  @override
  State<BookPageScreen> createState() => _BookPageScreenState();
}

class _BookPageScreenState extends State<BookPageScreen> {
  late final String _title;
  late final String _sub;
  late final String _body;
  late final bool _quranSection;

  /// سطروں کی درجہ بندی صفحہ کھلتے ہی ایک بار ہوتی ہے؛ ہر سطر کا وجٹ صرف
  /// اس وقت بنتا ہے جب وہ اسکرین پر آنے والی ہو (سست رینڈرنگ) — ورنہ بڑے
  /// اندراجات کھولتے ہی ہزاروں وجٹ ایک ساتھ بن کر ایپ ہینگ ہو جاتی تھی۔
  late final List<Widget Function(BuildContext)> _lineBuilders;

  @override
  void initState() {
    super.initState();
    _title = str(widget.item['title']);
    _sub = str(widget.item['subtitle']);
    _body = str(widget.item['body']);
    // قرآن و حدیث سیکشن: قرآنی عربی و حدیثی عربی پر کمپیوٹر آواز بالکل نہیں
    // (آیات پر اصل تلاوت، باقی عربی بے اسپیکر) — ترجمہ/شرح کی آواز بدستور۔
    // تفسیر عنوان والا اندراج Books سے کھلے تب بھی یہی تحفظات لاگو رہتے ہیں۔
    _quranSection = _title.contains('تفسیر') ||
        repo.list('quran').any((e) =>
            identical(e, widget.item) ||
            (str(e['title']) == _title && str(e['subtitle']) == _sub));
    _lineBuilders = _buildLineBuilders(_body);
  }

  @override
  Widget build(BuildContext context) {
    final title = _title;
    final sub = _sub;
    final full = '$_title\n\n$_body';
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          IconButton(
            tooltip: 'پورا سبق کاپی کریں',
            icon: const Icon(Icons.copy_rounded),
            onPressed: () => copyText(context, full),
          ),
          IconButton(
            tooltip: 'شیئر',
            icon: const Icon(Icons.ios_share_rounded),
            onPressed: () => shareText(full),
          ),
        ],
      ),
      body: CustomScrollView(
        slivers: [
          // رنگین سرخی پٹی
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 0),
            sliver: SliverToBoxAdapter(
              child: Container(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.deepTeal, AppColors.teal],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(
                  color: AppColors.teal.withAlpha(60),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('📖', style: TextStyle(fontSize: 26)),
                const SizedBox(height: 6),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    height: 1.6,
                  ),
                ),
                if (sub.isNotEmpty)
                  Text(
                    sub,
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.white.withAlpha(210),
                      height: 1.8,
                    ),
                  ),
              ],
            ),
          ),
            ),
          ),
          // کتاب کا صفحہ — ایک ہی بہاؤ میں سارا سبق؛ سطریں سست رینڈرنگ سے
          // صرف نظر آنے پر بنتی ہیں، کارڈ کا پس منظر/سایہ ایک ہی رہتا ہے
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
            sliver: DecoratedSliver(
              decoration: BoxDecoration(
                color: cardFill(context),
                borderRadius: BorderRadius.circular(22),
                border: Border.all(color: cs.outlineVariant.withAlpha(110)),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withAlpha(14),
                    blurRadius: 14,
                    offset: const Offset(0, 5),
                  ),
                ],
              ),
              sliver: SliverPadding(
                padding: const EdgeInsets.fromLTRB(20, 18, 20, 22),
                sliver: SliverList.builder(
                  itemCount: _lineBuilders.length,
                  itemBuilder: (ctx, i) => _lineBuilders[i](ctx),
                ),
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
            sliver: SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  OutlinedButton.icon(
                    onPressed: () => copyText(context, full),
                    icon: const Icon(Icons.copy_rounded),
                    label: const Text('پورا سبق کاپی کریں'),
                  ),
                  const SizedBox(height: 8),
                  OutlinedButton.icon(
                    onPressed: () => openFeedback(context, full),
                    icon: const Icon(Icons.edit_note_rounded),
                    label: const Text('تصحیح / اضافے کی تجویز'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  /// مشق والی سطروں کا رنگ — پیلا (سنہری)، تاکہ کتاب کے عام متن سے الگ صاف نظر آئیں؛
  /// ڈارک موڈ میں روشن پیلا، ورنہ گہرا سنہرا پس منظر میں گم ہو جاتا ہے
  Color _exerciseColorOf(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFFFFD740)
          : AppColors.gold;

  /// سرخی کا رنگ: ڈارک موڈ میں روشن پیلا (deepTeal وہاں نظر ہی نہیں آتا)، لائٹ میں گہرا
  Color _headingColorOf(BuildContext context, bool exercise) => exercise
      ? _exerciseColorOf(context)
      : (Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFFFFD740)
          : AppColors.deepTeal);

  /// لیبل کا رنگ: ڈارک میں روشن آسمانی، لائٹ میں گلابی بھورا
  Color _labelColorOf(BuildContext context, bool exercise) => exercise
      ? _exerciseColorOf(context)
      : (Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFF82B1FF)
          : AppColors.rose);

  /// رومن کا رنگ: ڈارک میں روشن آسمانی، لائٹ میں گہرا نیلا (saffron دونوں میں مدھم تھا)
  Color _romanColorOf(BuildContext context, bool exercise) => exercise
      ? _exerciseColorOf(context)
      : (Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFF82B1FF)
          : const Color(0xFF0D47A1));

  bool _isExerciseStart(String line) =>
      line.contains('مشق') ||
      line.contains('کامل کنید') ||
      line.contains('انتخاب کنید') ||
      line.contains('بنویسید') ||
      line.contains('......');

  bool _isExerciseEnd(String line) =>
      line.contains('گوش کنید') ||
      line.contains('آوازیں') ||
      line.contains('توجّه') ||
      line.startsWith('بخوانید') ||
      line.startsWith('درسِ');

  /// سطر کی زبان آواز کے لیے: خالص لاطینی متن انگریزی، ورنہ ایپ کی زبان (عربی)
  String _speakLang(String s) =>
      (!RegExp(r'[؀-ۿ]').hasMatch(s) && RegExp(r'[a-zA-Z]').hasMatch(s))
          ? 'en'
          : 'ar';

  /// سطروں کی درجہ بندی — نتیجہ وجٹ نہیں، وجٹ بنانے والے فنکشن ہیں؛
  /// اصل وجٹ SliverList.builder صرف نظر آنے والی سطروں کے لیے بناتا ہے۔
  List<Widget Function(BuildContext)> _buildLineBuilders(String body) {
    final out = <Widget Function(BuildContext)>[];
    var inExercise = false;
    for (final raw in body.split('\n')) {
      final line = raw.trim();
      if (line.isEmpty) {
        out.add((_) => const SizedBox(height: 10));
        continue;
      }
      if (_isExerciseStart(line)) inExercise = true;
      if (_isExerciseEnd(line)) inExercise = false;
      final ex = inExercise;
      // مزین سرخی ﴿ … ﴾ — آیت کارڈ: میچ پر اصل تلاوت + ٹچ ایبل الفاظ،
      // ورنہ سادہ سنہرا کارڈ؛ قرآنی عربی پر کمپیوٹر آواز کبھی نہیں
      final orn = RegExp(r'^﴿\s*(.+?)\s*﴾$').firstMatch(line);
      if (orn != null) {
        final ayahText = orn.group(1)!;
        out.add((ctx) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: AyahCard(text: ayahText),
            ));
        continue;
      }
      // فاصلہ سطر — صرف ۞ نشانات
      if (line.replaceAll(' ', '') == '۞۞۞' || line == '۞') {
        out.add((_) => const Padding(
              padding: EdgeInsets.symmetric(vertical: 4),
              child: Center(
                child: Text(
                  '۞ ۞ ۞',
                  style: TextStyle(
                    fontSize: 15,
                    letterSpacing: 4,
                    color: AppColors.gold,
                  ),
                ),
              ),
            ));
        continue;
      }
      // عنوانی سطر (آخر میں :) — داخلے سے پہلے جانچو
      if (line.endsWith(':') || line.endsWith('：')) {
        out.add((ctx) =>
            _heading(ctx, line, exercise: ex, quranSection: _quranSection));
        continue;
      }
      if (line.contains(' — ')) {
        for (final seg in line.split('؛')) {
          final s = seg.trim();
          if (s.isNotEmpty) {
            out.add((ctx) =>
                _entry(ctx, s, exercise: ex, quranSection: _quranSection));
          }
        }
        continue;
      }
      if (line.contains('آوازیں')) {
        out.add((ctx) => _soundStrip(ctx, line));
        continue;
      }
      out.add((ctx) =>
          _prose(ctx, line, exercise: ex, quranSection: _quranSection));
    }
    return out;
  }

  Widget _heading(BuildContext context, String line,
      {bool exercise = false, bool quranSection = false}) {
    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 5,
            height: 26,
            margin: const EdgeInsets.only(left: 10, top: 4),
            decoration: BoxDecoration(
              color: AppColors.gold,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          Expanded(
            child: UrduTapText(
              ur: line,
              style: TextStyle(
                fontSize: 18.5,
                fontWeight: FontWeight.w800,
                color: _headingColorOf(context, exercise),
                height: 1.9,
              ),
              hideFaSpeaker: quranSection,
            ),
          ),
        ],
      ),
    );
  }

  Widget _soundStrip(BuildContext context, String line) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.saffron.withAlpha(28),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.saffron.withAlpha(90)),
      ),
      child: Text(
        line,
        style: faStyle(
            size: 19,
            color: Theme.of(context).brightness == Brightness.dark
                ? const Color(0xFFFFD740)
                : AppColors.deepTeal),
      ),
    );
  }

  Widget _prose(BuildContext context, String line,
      {bool exercise = false, bool quranSection = false}) {
    final cs = Theme.of(context).colorScheme;
    // قرآن سیکشن میں اردو سطر کے اندر آئے قرآنی عربی الفاظ (مثلاً تعلیم
    // القرآن کی گرامری تحلیل) اردو آواز نہیں بولتی — صرف اردو حصہ بولے گا
    final spoken = quranSection ? urduSpeechText(line) : line;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: UrduTapText(
              ur: line,
              style: urStyle(
                  size: 16.5,
                  color: exercise
                      ? _exerciseColorOf(context)
                      : cs.onSurface.withAlpha(225)),
              hideFaSpeaker: quranSection,
            ),
          ),
          // اردو نثر/وضاحت کی سطر اردو آواز میں سننے کے لیے — قرآن سیکشن
          // میں مکمل اعراب والی خالص عربی سطر (حدیث/عبارت) بے اسپیکر رہتی ہے
          if (!quranSection ||
              (_urduProseLine(line) && spoken.isNotEmpty))
            SpeakButton(text: spoken, lang: 'ur', size: 19),
        ],
      ),
    );
  }

  /// ایک داخلہ: فارسی — رومن — اردو (رومن نہ ہو تو فارسی — اردو)
  Widget _entry(BuildContext context, String seg,
      {bool exercise = false, bool quranSection = false}) {
    final cs = Theme.of(context).colorScheme;
    var parts = seg.split(' — ');
    String fa, ur;
    String? ro;
    // زبان کی پہچان — ہر اسپیکر بٹن صرف اپنی زبان کا متن بولے، اس لیے
    // عربی/اردو کی سرحد درست نکالنا ضروری ہے۔ اردو کے مخصوص حروف
    // (ٹ ڈ ڑ ھ ے) عربی میں نہیں ہوتے؛ اردو کے عام الفاظ بھی نشانی ہیں۔
    bool urduLike(String s) {
      if (RegExp(r'[ٹڈڑھے]').hasMatch(s)) return true;
      final hits = RegExp(
              r'(?:^|\s)(ہے|ہیں|کا|کی|کے|میں|نے|اور|یہ|وہ|نہیں|بھی|سے|پر|کو|تھا|تھی|ہو|کر|گا|گی|گے)(?=\s|$|[۔،؟!؛:])')
          .allMatches(s)
          .length;
      return hits >= 2;
    }

    // آخری حصہ خالص لاطینی ہو تو وہ رومن ہے، اردو نہیں
    // (مثلاً حروفِ تہجی کی سطر: «ا — اَلِف — alef»)
    if (parts.length >= 2 &&
        RegExp(r'[a-zA-Z]').hasMatch(parts.last) &&
        !RegExp(r'[؀-ۿ]').hasMatch(parts.last)) {
      ro = parts.removeLast();
    }
    if (parts.length >= 3 &&
        RegExp(r'[a-zA-Z]').hasMatch(parts[parts.length - 2])) {
      fa = parts.sublist(0, parts.length - 2).join(' — ');
      ro = parts[parts.length - 2];
      ur = parts[parts.length - 1];
    } else if (parts.length >= 2) {
      // اردو درمیان سے بھی شروع ہو سکتی ہے — اردو متن کے اندر « — » آ جائے
      // تو پرانا طریقہ اردو کا ابتدائی حصہ عربی میں ملا دیتا تھا اور
      // عربی بٹن اردو بھی پڑھ دیتا تھا۔ اردو نما حصے سے آگے سب اردو ہے۔
      var urStart = -1;
      for (var i = 1; i < parts.length; i++) {
        if (urduLike(parts[i])) {
          urStart = i;
          break;
        }
      }
      if (urStart > 0) {
        fa = parts.sublist(0, urStart).join(' — ');
        ur = parts.sublist(urStart).join(' — ');
      } else if (ro != null) {
        // رومن الگ ہو چکی اور کوئی حصہ اردو نما نہیں — باقی سب عربی ہے
        fa = parts.join(' — ');
        ur = '';
      } else {
        fa = parts.sublist(0, parts.length - 1).join(' — ');
        ur = parts[parts.length - 1];
      }
    } else {
      fa = parts[0];
      ur = '';
    }
    // پوری سطر ہی اردو نثر ہو (گرامر وضاحت وغیرہ) تو «عربی» حصہ بھی اصل
    // میں اردو ہے — اسے اردو میں ملا دو: عربی بٹن (خالی متن) خودکار بند
    // رہے گا اور اردو بٹن پوری سطر پڑھے گا۔
    if (fa.isNotEmpty && urduLike(fa)) {
      ur = ur.isEmpty ? fa : '$fa — $ur';
      fa = '';
    }
    // لیبل الگ کرو، جیسے «پلیٹ: آن بشقاب است»
    String? label;
    final ci = fa.indexOf(': ');
    if (ci > 0 && ci < 14) {
      label = fa.substring(0, ci);
      fa = fa.substring(ci + 2);
    }
    // نمبر الگ کرو، جیسے «۱۔ آب»
    String? num;
    final m = RegExp(r'^([۰-۹0-9]+۔)\s*').firstMatch(fa);
    if (m != null) {
      num = m.group(1);
      fa = fa.substring(m.end);
    }
    // قرآن سیکشن میں اردو حصے کے اندر آئے قرآنی عربی الفاظ اردو آواز نہ بولے
    final urSpoken = quranSection ? urduSpeechText(ur) : ur;
    final row = Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (num != null)
            Padding(
              padding: const EdgeInsets.only(left: 8, top: 5),
              child: Text(
                num,
                style: TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: Theme.of(context).brightness == Brightness.dark
                      ? const Color(0xFFFFD740)
                      : AppColors.gold,
                ),
              ),
            ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (label != null)
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                      color: _labelColorOf(context, exercise),
                    ),
                  ),
                WordTapText(
                    fa: fa,
                    style: faStyle(
                        size: 21,
                        color: exercise ? _exerciseColorOf(context) : null),
                    hideFaSpeaker: quranSection),
                if (ro != null && ro.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 1),
                    child: Text(
                      ro,
                      style: TextStyle(
                        fontSize: 14,
                        fontStyle: FontStyle.italic,
                        color: _romanColorOf(context, exercise),
                        fontWeight: FontWeight.w600,
                      ),
                      textDirection: TextDirection.ltr,
                    ),
                  ),
                if (ur.isNotEmpty)
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: UrduTapText(
                          ur: ur,
                          style: urStyle(
                              size: 16,
                              color: exercise
                                  ? _exerciseColorOf(context)
                                  : cs.onSurface.withAlpha(215)),
                          hideFaSpeaker: quranSection,
                        ),
                      ),
                      if (urSpoken.isNotEmpty)
                        SpeakButton(text: urSpoken, lang: 'ur', size: 19),
                    ],
                  ),
              ],
            ),
          ),
          // پوری سطر (عربی/انگریزی) براہ راست سننے کے لیے اسپیکر بٹن —
          // قرآن سیکشن میں عربی ٹکڑے پر کمپیوٹر آواز نہیں (صرف ترجمہ بولے گا)
          if (!quranSection)
            SpeakButton(text: fa, lang: _speakLang(fa), size: 20),
        ],
      ),
    );
    // پورا داخلہ ٹچ کرنے پر جملے کی مکمل تفصیل (معانی + گرامر) کھلتی ہے؛
    // انفرادی الفاظ پر ٹچ ان کے اپنے معنی کھولتا ہے
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => openSentenceDetail(context,
            fa: fa, roman: ro, ur: ur, hideFaSpeaker: quranSection),
        child: row,
      ),
    );
  }
}

/// قرآن سیکشن کی نثری سطر اردو/وضاحت ہے یا خالص عربی؟
/// اردو نشانی (مخصوص حروف یا عام اردو لفظ) ہو تو اردو؛ ورنہ اعراب کی
/// کثافت دیکھو — مکمل اعراب والی سطر عربی عبارت ہے، بے اسپیکر رہے گی۔
bool _urduProseLine(String s) {
  if (RegExp(r'[ٹڈڑھے]').hasMatch(s)) return true;
  final hits = RegExp(
          r'(?:^|\s)(ہے|ہیں|کا|کی|کے|میں|نے|اور|یہ|وہ|نہیں|بھی|سے|پر|کو|تھا|تھی|ہو|کر|گا|گی|گے)(?=\s|$|[۔،؟!؛:])')
      .allMatches(s)
      .length;
  if (hits >= 1) return true;
  var marks = 0, letters = 0;
  for (final r in s.runes) {
    if ((r >= 0x064B && r <= 0x065F) || r == 0x0670 || (r >= 0x06D6 && r <= 0x06ED)) {
      marks++;
    }
    if (r >= 0x0621 && r <= 0x06D3) letters++;
  }
  if (letters == 0) return true;
  return marks / letters < 0.25;
}
