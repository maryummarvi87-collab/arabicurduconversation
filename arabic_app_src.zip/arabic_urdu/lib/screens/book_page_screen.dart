import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../widgets/common.dart';
import '../widgets/sentence_detail.dart';
import '../widgets/word_tap_text.dart';

/// کتابی سبق کا صفحہ — کتاب کی طرح سیدھا بہتا ہوا متن، خوبصورت رنگوں میں۔
/// ہر سطر: اعراب‌دار فارسی — رومن — اردو معنی؛ فارسی لفظ پر ٹچ کرنے سے معنی کھلتا ہے۔
/// اوپر کاپی اور شیئر کے بٹن — پورا سبق ایک ٹچ میں کاپی ہو جاتا ہے۔
class BookPageScreen extends StatelessWidget {
  final Map<String, dynamic> item;
  const BookPageScreen({super.key, required this.item});

  @override
  Widget build(BuildContext context) {
    final title = str(item['title']);
    final sub = str(item['subtitle']);
    final body = str(item['body']);
    final full = '$title\n\n$body';
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        actions: [
          IconButton(
            tooltip: 'پورا سبق کاپی کریں',
            icon: const Icon(Icons.copy_rounded),
            onPressed: () => copyText(context, full),
          ),
          IconButton(
            tooltip: 'شیئر',
            icon: const Icon(Icons.ios_share_rounded),
            onPressed: () => shareText(full),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          // رنگین سرخی پٹی
          Container(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [AppColors.deepTeal, AppColors.teal],
                begin: Alignment.topRight,
                end: Alignment.bottomLeft,
              ),
              borderRadius: BorderRadius.circular(22),
              boxShadow: [
                BoxShadow(
                  color: AppColors.teal.withAlpha(60),
                  blurRadius: 16,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('📖', style: TextStyle(fontSize: 26)),
                const SizedBox(height: 6),
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    height: 1.6,
                  ),
                ),
                if (sub.isNotEmpty)
                  Text(
                    sub,
                    style: TextStyle(
                      fontSize: 15,
                      color: Colors.white.withAlpha(210),
                      height: 1.8,
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 14),
          // کتاب کا صفحہ — ایک ہی بہاؤ میں سارا سبق
          Container(
            padding: const EdgeInsets.fromLTRB(20, 18, 20, 22),
            decoration: BoxDecoration(
              color: cardFill(context),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: cs.outlineVariant.withAlpha(110)),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withAlpha(14),
                  blurRadius: 14,
                  offset: const Offset(0, 5),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: _buildLines(context, body),
            ),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: () => copyText(context, full),
            icon: const Icon(Icons.copy_rounded),
            label: const Text('پورا سبق کاپی کریں'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => openFeedback(context, full),
            icon: const Icon(Icons.edit_note_rounded),
            label: const Text('تصحیح / اضافے کی تجویز'),
          ),
        ],
      ),
    );
  }

  /// مشق والی سطروں کا رنگ — پیلا (سنہری)، تاکہ کتاب کے عام متن سے الگ صاف نظر آئیں
  static const Color _exerciseColor = AppColors.gold;

  bool _isExerciseStart(String line) =>
      line.contains('مشق') ||
      line.contains('کامل کنید') ||
      line.contains('انتخاب کنید') ||
      line.contains('بنویسید') ||
      line.contains('......');

  bool _isExerciseEnd(String line) =>
      line.contains('گوش کنید') ||
      line.contains('آوازیں') ||
      line.contains('توجّه') ||
      line.startsWith('بخوانید') ||
      line.startsWith('درسِ');

  List<Widget> _buildLines(BuildContext context, String body) {
    final out = <Widget>[];
    var inExercise = false;
    for (final raw in body.split('\n')) {
      final line = raw.trim();
      if (line.isEmpty) {
        out.add(const SizedBox(height: 10));
        continue;
      }
      if (_isExerciseStart(line)) inExercise = true;
      if (_isExerciseEnd(line)) inExercise = false;
      // عنوانی سطر (آخر میں :) — داخلے سے پہلے جانچو
      if (line.endsWith(':') || line.endsWith('：')) {
        if (!inExercise && !_isExerciseStart(line)) inExercise = false;
        out.add(_heading(context, line, exercise: inExercise));
        continue;
      }
      if (line.contains(' — ')) {
        for (final seg in line.split('؛')) {
          final s = seg.trim();
          if (s.isNotEmpty) out.add(_entry(context, s, exercise: inExercise));
        }
        continue;
      }
      if (line.contains('آوازیں')) {
        out.add(_soundStrip(context, line));
        continue;
      }
      out.add(_prose(context, line, exercise: inExercise));
    }
    return out;
  }

  Widget _heading(BuildContext context, String line, {bool exercise = false}) {
    return Padding(
      padding: const EdgeInsets.only(top: 16, bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 5,
            height: 26,
            margin: const EdgeInsets.only(left: 10, top: 4),
            decoration: BoxDecoration(
              color: AppColors.gold,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          Expanded(
            child: Text(
              line,
              style: TextStyle(
                fontSize: 18.5,
                fontWeight: FontWeight.w800,
                color: exercise ? _exerciseColor : AppColors.deepTeal,
                height: 1.9,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _soundStrip(BuildContext context, String line) {
    return Container(
      margin: const EdgeInsets.symmetric(vertical: 8),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: AppColors.saffron.withAlpha(28),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.saffron.withAlpha(90)),
      ),
      child: Text(
        line,
        style: faStyle(size: 19, color: AppColors.deepTeal),
      ),
    );
  }

  Widget _prose(BuildContext context, String line, {bool exercise = false}) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: UrduTapText(
        ur: line,
        style: urStyle(
            size: 16.5,
            color: exercise ? _exerciseColor : cs.onSurface.withAlpha(225)),
      ),
    );
  }

  /// ایک داخلہ: فارسی — رومن — اردو (رومن نہ ہو تو فارسی — اردو)
  Widget _entry(BuildContext context, String seg, {bool exercise = false}) {
    final cs = Theme.of(context).colorScheme;
    final parts = seg.split(' — ');
    String fa, ur;
    String? ro;
    if (parts.length >= 3 &&
        RegExp(r'[a-zA-Z]').hasMatch(parts[parts.length - 2])) {
      fa = parts.sublist(0, parts.length - 2).join(' — ');
      ro = parts[parts.length - 2];
      ur = parts[parts.length - 1];
    } else if (parts.length >= 2) {
      fa = parts.sublist(0, parts.length - 1).join(' — ');
      ur = parts[parts.length - 1];
    } else {
      fa = parts[0];
      ur = '';
    }
    // لیبل الگ کرو، جیسے «پلیٹ: آن بشقاب است»
    String? label;
    final ci = fa.indexOf(': ');
    if (ci > 0 && ci < 14) {
      label = fa.substring(0, ci);
      fa = fa.substring(ci + 2);
    }
    // نمبر الگ کرو، جیسے «۱۔ آب»
    String? num;
    final m = RegExp(r'^([۰-۹0-9]+۔)\s*').firstMatch(fa);
    if (m != null) {
      num = m.group(1);
      fa = fa.substring(m.end);
    }
    final row = Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (num != null)
            Padding(
              padding: const EdgeInsets.only(left: 8, top: 5),
              child: Text(
                num,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.w800,
                  color: AppColors.gold,
                ),
              ),
            ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (label != null)
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: 13.5,
                      fontWeight: FontWeight.w700,
                      color: exercise ? _exerciseColor : AppColors.rose,
                    ),
                  ),
                WordTapText(
                    fa: fa,
                    style: faStyle(
                        size: 21, color: exercise ? _exerciseColor : null)),
                if (ro != null && ro.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 1),
                    child: Text(
                      ro,
                      style: TextStyle(
                        fontSize: 14,
                        fontStyle: FontStyle.italic,
                        color: exercise ? _exerciseColor : AppColors.saffron,
                        fontWeight: FontWeight.w600,
                      ),
                      textDirection: TextDirection.ltr,
                    ),
                  ),
                if (ur.isNotEmpty)
                  UrduTapText(
                    ur: ur,
                    style: urStyle(
                        size: 16,
                        color: exercise
                            ? _exerciseColor
                            : cs.onSurface.withAlpha(215)),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
    // پورا داخلہ ٹچ کرنے پر جملے کی مکمل تفصیل (معانی + گرامر) کھلتی ہے؛
    // انفرادی الفاظ پر ٹچ ان کے اپنے معنی کھولتا ہے
    return Material(
      color: Colors.transparent,
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () => openSentenceDetail(context, fa: fa, roman: ro, ur: ur),
        child: row,
      ),
    );
  }
}
