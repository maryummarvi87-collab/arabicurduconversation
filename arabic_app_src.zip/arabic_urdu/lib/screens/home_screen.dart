import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../config.dart';
import '../state.dart';
import '../theme.dart';
import '../widgets/clock_card.dart';
import '../widgets/common.dart';
import 'app_options_screen.dart';
import 'books_screen.dart';
import 'calendar_screen.dart';
import 'collection_screen.dart';
import 'dialects_screen.dart';
import 'dictionary_screen.dart';
import 'feedback_screen.dart';
import 'search_screen.dart';
import 'sentences_screen.dart';
import 'update_screen.dart';
import 'verbs_screen.dart';
import 'sarf_screen.dart';

class _Tile {
  final String title;
  final IconData icon;
  final Color color;
  final VoidCallback onTap;
  const _Tile(this.title, this.icon, this.color, this.onTap);
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  void _go(BuildContext context, Widget page) {
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => page));
  }

  Future<void> _openWebsite(BuildContext context) async {
    final uri = Uri.parse(AppConfig.appLink);
    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok && context.mounted) {
      showSnack(context, 'ویب سائٹ نہیں کھل سکی');
    }
  }

  @override
  Widget build(BuildContext context) {
    final tiles = <_Tile>[
      _Tile('کتابیں', Icons.library_books_rounded, AppColors.teal,
          () => _go(context, const BooksScreen())),
      _Tile('صرف و نحو', Icons.rule_rounded, AppColors.lapis,
          () => _go(context, const TextCollectionScreen(dataKey: 'grammar', title: 'صرف و نحو (عربی گرامر)'))),
      _Tile('بول چال', Icons.forum_rounded, AppColors.emerald,
          () => _go(context, const CollectionScreen(dataKey: 'conversation', title: 'بول چال'))),
      _Tile('مضامین', Icons.article_rounded, AppColors.saffron,
          () => _go(context, const TextCollectionScreen(dataKey: 'articles', title: 'مضامین'))),
      _Tile('کہانیاں', Icons.auto_stories_rounded, AppColors.rose,
          () => _go(context, const CollectionScreen(dataKey: 'stories', title: 'کہانیاں'))),
      _Tile('شاعری', Icons.auto_awesome_rounded, AppColors.plum,
          () => _go(context, const CollectionScreen(dataKey: 'poems', title: 'شاعری'))),
      _Tile('لغت', Icons.translate_rounded, AppColors.deepTeal,
          () => _go(context, const DictionaryScreen())),
      _Tile('قرآن و احادیث', Icons.menu_book_rounded, AppColors.gold,
          () => _go(context, const CollectionScreen(dataKey: 'quran', title: 'قرآن و احادیث'))),
      _Tile('مصادر و گردان', Icons.repeat_rounded, AppColors.lapis,
          () => _go(context, const VerbsScreen())),
      _Tile('گردان ساز', Icons.change_circle_rounded, AppColors.saffron,
          () => _go(context, const SarfScreen())),
      _Tile('جملے', Icons.format_quote_rounded, AppColors.teal,
          () => _go(context, const SentencesScreen())),
      _Tile('کیلنڈر', Icons.calendar_month_rounded, AppColors.lapis,
          () => _go(context, const CalendarScreen())),
      _Tile('عربی لہجے', Icons.record_voice_over_rounded, AppColors.emerald,
          () => _go(context, const DialectsScreen())),
      _Tile('تصحیح و اضافہ', Icons.edit_note_rounded, AppColors.saffron,
          () => _go(context, const FeedbackScreen())),
      _Tile('آن لائن اپڈیٹ', Icons.cloud_download_rounded, AppColors.rose,
          () => _go(context, const UpdateScreen())),
      _Tile('ویب سائٹ', Icons.language_rounded, AppColors.teal,
          () => _openWebsite(context)),
      _Tile('ایپ کے بارے میں', Icons.info_rounded, AppColors.deepTeal,
          () => _go(context, const AppOptionsScreen())),
      _Tile('ایپ شیئر کریں', Icons.ios_share_rounded, AppColors.plum, shareApp),
    ];

    return Scaffold(
      body: ListView(
        padding: EdgeInsets.zero,
        children: [
          _Hero(onSettings: () => _openSettings(context)),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 6),
            child: _SearchBar(onTap: () => _go(context, const SearchScreen())),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: GridView.count(
              crossAxisCount: 3,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 0.95,
              children: [for (final t in tiles) _TileView(tile: t)],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 18),
            child: Text(
              'لُغَةُ الْقُرْآنِ وَالْعَالَم',
              textAlign: TextAlign.center,
              style: faStyle(
                size: 15,
                w: FontWeight.w400,
                color: Theme.of(context).colorScheme.outline,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _openSettings(BuildContext context) {
    showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (_) => ListenableBuilder(
        listenable: settings,
        builder: (ctx, child) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text('ترتیبات', style: Theme.of(ctx).textTheme.titleLarge),
                const SizedBox(height: 14),
                SegmentedButton<ThemeMode>(
                  segments: const [
                    ButtonSegment(
                        value: ThemeMode.light,
                        label: Text('روشن'),
                        icon: Icon(Icons.light_mode_rounded)),
                    ButtonSegment(
                        value: ThemeMode.dark,
                        label: Text('تاریک'),
                        icon: Icon(Icons.dark_mode_rounded)),
                    ButtonSegment(
                        value: ThemeMode.system,
                        label: Text('خودکار'),
                        icon: Icon(Icons.brightness_auto_rounded)),
                  ],
                  selected: {settings.themeMode},
                  onSelectionChanged: (s) => settings.setThemeMode(s.first),
                ),
                SwitchListTile(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('عربی ہندسے (١٢٣)'),
                  subtitle: const Text('بند کریں تو 123 دکھائی دیں گے'),
                  value: settings.persianDigits,
                  onChanged: settings.setPersianDigits,
                ),
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  leading: const Icon(Icons.link_rounded),
                  title: const Text('ایپ کا لنک'),
                  subtitle: Text(
                    AppConfig.appLink,
                    textDirection: TextDirection.ltr,
                    textAlign: TextAlign.right,
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.copy_rounded),
                    onPressed: () => copyText(ctx, AppConfig.appLink),
                  ),
                ),
                const SizedBox(height: 6),
                FilledButton.icon(
                  onPressed: shareApp,
                  icon: const Icon(Icons.ios_share_rounded),
                  label: const Text('ایپ شیئر کریں'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Hero extends StatelessWidget {
  final VoidCallback onSettings;
  const _Hero({required this.onSettings});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [AppColors.teal, AppColors.deepTeal],
        ),
        borderRadius: BorderRadius.vertical(bottom: Radius.circular(38)),
      ),
      child: Stack(
        children: [
          Positioned(
            left: -50,
            top: -30,
            child: _circle(170, Colors.white.withAlpha(14)),
          ),
          Positioned(
            right: -40,
            bottom: 40,
            child: _circle(120, AppColors.gold.withAlpha(30)),
          ),
          Padding(
            padding: EdgeInsets.fromLTRB(
                18, MediaQuery.of(context).padding.top + 10, 18, 24),
            child: Column(
              children: [
                Row(
                  children: [
                    IconButton(
                      onPressed: onSettings,
                      icon: const Icon(Icons.tune_rounded, color: Colors.white),
                    ),
                    Expanded(
                      child: Column(
                        children: [
                          Text(
                            AppConfig.appName,
                            style: faStyle(
                                size: 25, w: FontWeight.w800, color: Colors.white),
                          ),
                          Text(
                            'عربی سیکھیں، اردو کے ذریعے',
                            style: TextStyle(
                              color: AppColors.gold.withAlpha(240),
                              fontSize: 13.5,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 48),
                  ],
                ),
                const SizedBox(height: 14),
                const ClockCard(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _circle(double size, Color color) => Container(
        width: size,
        height: size,
        decoration: BoxDecoration(shape: BoxShape.circle, color: color),
      );
}

class _SearchBar extends StatelessWidget {
  final VoidCallback onTap;
  const _SearchBar({required this.onTap});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Material(
      color: cardFill(context),
      borderRadius: BorderRadius.circular(18),
      elevation: 2,
      shadowColor: Colors.black.withAlpha(60),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Icon(Icons.search_rounded, color: cs.primary),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'اردو، عربی یا انگریزی میں تلاش کریں…',
                  style: TextStyle(color: cs.outline),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _TileView extends StatelessWidget {
  final _Tile tile;
  const _TileView({required this.tile});

  @override
  Widget build(BuildContext context) {
    final dark = Color.alphaBlend(Colors.black.withAlpha(70), tile.color);
    return Material(
      color: Colors.transparent,
      child: Ink(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [tile.color, dark],
          ),
          borderRadius: BorderRadius.circular(22),
          boxShadow: [
            BoxShadow(
              color: tile.color.withAlpha(70),
              blurRadius: 12,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: InkWell(
          borderRadius: BorderRadius.circular(22),
          onTap: tile.onTap,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.white.withAlpha(40),
                ),
                child: Icon(tile.icon, color: Colors.white, size: 26),
              ),
              const SizedBox(height: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: Text(
                  tile.title,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
