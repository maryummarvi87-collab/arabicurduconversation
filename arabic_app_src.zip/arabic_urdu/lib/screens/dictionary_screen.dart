import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';

/// لغت: فارسی ↔ اردو، تلاش کے خانے کے ساتھ
/// [dataKey] سے عام لغت یا آکسفورڈ لغت — دونوں ایک ہی انداز میں
class DictionaryScreen extends StatefulWidget {
  final String dataKey;
  final String title;
  const DictionaryScreen(
      {super.key, this.dataKey = 'dictionary', this.title = 'لغت'});

  @override
  State<DictionaryScreen> createState() => _DictionaryScreenState();
}

class _DictionaryScreenState extends State<DictionaryScreen> {
  late final List<Map<String, dynamic>> _all;
  String _q = '';
  double _scale = 1.0;
  double? _pinchStart;

  bool get _isOxford => widget.dataKey == 'oxford';

  @override
  void initState() {
    super.initState();
    _all = repo.list(widget.dataKey);
    if (!_isOxford) {
      _all.sort((a, b) =>
          normalize(str(a['fa'])).compareTo(normalize(str(b['fa']))));
    }
    SharedPreferences.getInstance().then((p) {
      if (!mounted) return;
      setState(() => _scale = p.getDouble('dict_scale') ?? 1.0);
    });
  }

  Future<void> _saveScale() async {
    final p = await SharedPreferences.getInstance();
    await p.setDouble('dict_scale', _scale);
  }

  @override
  Widget build(BuildContext context) {
    final nq = normalize(_q);
    final shown = nq.isEmpty
        ? _all
        : _all
            .where((w) => _isOxford
                ? normalize(
                        '${str(w['en'])} ${str(w['ex'])} ${str(w['fa'])} ${str(w['ur'])}')
                    .contains(nq)
                : normalize('${str(w['fa'])} ${str(w['ur'])} ${str(w['ro'])} ${str(w['en'])}').contains(nq))
            .toList();
    final cs = Theme.of(context).colorScheme;
    final intro = _isOxford ? str(repo.data['oxfordIntro']) : '';
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title),
        actions: [
          if (widget.dataKey == 'dictionary')
            IconButton(
              icon: const Icon(Icons.account_tree_outlined),
              tooltip: 'افعال کے مادے',
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const DictRootsScreen()),
              ),
            ),
        ],
      ),
      body: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onScaleStart: (d) => _pinchStart = _scale,
        onScaleUpdate: (d) {
          if (_pinchStart == null || d.scale == 1.0) return;
          setState(() => _scale = (_pinchStart! * d.scale).clamp(0.8, 1.8));
        },
        onScaleEnd: (_) {
          _pinchStart = null;
          _saveScale();
        },
        child: MediaQuery(
          data: MediaQuery.of(context)
              .copyWith(textScaler: TextScaler.linear(_scale)),
          child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _q = v),
              decoration: InputDecoration(
                hintText: _isOxford
                    ? 'لفظ تلاش کریں (انگریزی، فارسی یا اردو)'
                    : 'لفظ تلاش کریں (عربی، اردو یا انگریزی)',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: cardFill(context),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          if (_isOxford && _q.isEmpty && intro.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 2, 16, 8),
              child: Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: AppColors.gold.withAlpha(38),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.gold.withAlpha(120)),
                ),
                child: Text(
                  intro,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: cs.onSurface),
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                '${localDigits(shown.length)} الفاظ',
                style: TextStyle(color: cs.outline, fontSize: 13),
              ),
            ),
          ),
          Expanded(
            child: shown.isEmpty
                ? const EmptyState(message: 'کوئی لفظ نہیں ملا۔')
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 96),
                    itemCount: shown.length,
                    itemBuilder: (context, i) {
                      final w = shown[i];
                      if (_isOxford) {
                        final g = str(w['g']);
                        final showHeader = g.isNotEmpty &&
                            (i == 0 || str(shown[i - 1]['g']) != g);
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            if (showHeader)
                              Padding(
                                padding:
                                    const EdgeInsets.fromLTRB(20, 14, 20, 2),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 34,
                                      height: 34,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        color: AppColors.gold,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Text(
                                        g,
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 17),
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Divider(
                                          color:
                                              cs.outlineVariant.withAlpha(160)),
                                    ),
                                  ],
                                ),
                              ),
                            _OxfordCard(w: w),
                          ],
                        );
                      }
                      final pos = str(w['pos']);
                      return PhraseCard(
                        fa: str(w['fa']),
                        ur: str(w['ur']),
                        tag: pos.isEmpty ? null : pos,
                        roman: str(w['ro']),
                        vocalized: str(w['v']),
                        words: w['w'] as List<dynamic>?,
                        root: str(w['root']),
                        plural: str(w['pl']),
                        grammar: str(w['gr']),
                      );
                    },
                  ),
          ),
        ],
          ),
        ),
      ),
    );
  }
}

/// لغت کے افعال کے مادے — ہر مادے کے افعال ایک جگہ
class DictRootsScreen extends StatefulWidget {
  const DictRootsScreen({super.key});

  @override
  State<DictRootsScreen> createState() => _DictRootsScreenState();
}

class _DictRootsScreenState extends State<DictRootsScreen> {
  String _q = '';
  late final Map<String, List<Map<String, dynamic>>> _byRoot;
  late final List<String> _roots;

  @override
  void initState() {
    super.initState();
    _byRoot = <String, List<Map<String, dynamic>>>{};
    for (final w in repo.list('dictionary')) {
      final root = str(w['root']).trim();
      if (root.isEmpty || !str(w['pos']).contains('فعل')) continue;
      _byRoot.putIfAbsent(root, () => []).add(w);
    }
    _roots = _byRoot.keys.toList()
      ..sort((a, b) => _byRoot[b]!.length.compareTo(_byRoot[a]!.length));
  }

  void _showRoot(String root) {
    final verbs = _byRoot[root]!;
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(8, 16, 8, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                child: Text('مادہ: $root — ${verbs.length} افعال',
                    textDirection: TextDirection.rtl,
                    style: urStyle(size: 17)),
              ),
              const SizedBox(height: 8),
              for (final w in verbs)
                PhraseCard(
                  fa: str(w['fa']),
                  ur: str(w['ur']),
                  tag: str(w['pos']).isEmpty ? null : str(w['pos']),
                  roman: str(w['ro']),
                  vocalized: str(w['v']),
                  words: w['w'] as List<dynamic>?,
                  root: str(w['root']),
                  plural: str(w['pl']),
                  grammar: str(w['gr']),
                ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final q = _q.replaceAll(' ', '');
    final shown = _roots
        .where((r) => q.isEmpty || r.replaceAll(' ', '').contains(q))
        .toList();
    return Scaffold(
      appBar: AppBar(title: const Text('لغت — افعال کے مادے')),
      body: Column(
        children: [
          SearchBox(
            hint: 'مادہ تلاش کریں…',
            onChanged: (v) => setState(() => _q = v),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
            child: Text(
                'کل ${_roots.length} مادے — کسی مادے پر ٹیپ کریں، اس کے افعال نظر آئیں گے',
                style: urStyle(size: 13)),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.only(bottom: 32),
              itemCount: shown.length,
              itemBuilder: (context, i) {
                final r = shown[i];
                return Container(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                  decoration: BoxDecoration(
                    color: cardFill(context),
                    borderRadius: BorderRadius.circular(14),
                    border:
                        Border.all(color: AppColors.gold.withAlpha(90)),
                  ),
                  child: ListTile(
                    title: Text(r,
                        textDirection: TextDirection.rtl,
                        style: faStyle(size: 24)),
                    subtitle: Text('${_byRoot[r]!.length} افعال',
                        style: urStyle(size: 13)),
                    trailing: const Icon(Icons.chevron_left,
                        color: AppColors.gold),
                    onTap: () => _showRoot(r),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

/// آکسفورڈ لغت کا کارڈ: مخفف (انگریزی) + مکمل صورت + فارسی + اردو
class _OxfordCard extends StatelessWidget {
  final Map<String, dynamic> w;
  const _OxfordCard({required this.w});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final en = str(w['en']);
    final ex = str(w['ex']);
    final fa = str(w['fa']);
    final ur = str(w['ur']);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(16),
            blurRadius: 14,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              textDirection: TextDirection.ltr,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  en,
                  style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                      color: cs.onSurface),
                ),
                if (ex.isNotEmpty) ...[
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      ex,
                      style: TextStyle(
                          fontSize: 16,
                          fontStyle: FontStyle.italic,
                          color: cs.onSurfaceVariant),
                    ),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 8),
            Text(
              fa,
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.right,
              style: faStyle(size: 19, color: cs.onSurface),
            ),
            const SizedBox(height: 4),
            Text(
              ur,
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.right,
              style: urStyle(size: 17, color: cs.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}
