import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';

/// لغت: فارسی ↔ اردو، تلاش کے خانے کے ساتھ
/// [dataKey] سے عام لغت یا آکسفورڈ لغت — دونوں ایک ہی انداز میں
class DictionaryScreen extends StatefulWidget {
  final String dataKey;
  final String title;
  const DictionaryScreen(
      {super.key, this.dataKey = 'dictionary', this.title = 'لغت'});

  @override
  State<DictionaryScreen> createState() => _DictionaryScreenState();
}

class _DictionaryScreenState extends State<DictionaryScreen> {
  late final List<Map<String, dynamic>> _all;
  String _q = '';

  bool get _isOxford => widget.dataKey == 'oxford';

  @override
  void initState() {
    super.initState();
    _all = repo.list(widget.dataKey);
    if (!_isOxford) {
      _all.sort((a, b) =>
          normalize(str(a['fa'])).compareTo(normalize(str(b['fa']))));
    }
  }

  @override
  Widget build(BuildContext context) {
    final nq = normalize(_q);
    final shown = nq.isEmpty
        ? _all
        : _all
            .where((w) => _isOxford
                ? normalize(
                        '${str(w['en'])} ${str(w['ex'])} ${str(w['fa'])} ${str(w['ur'])}')
                    .contains(nq)
                : normalize('${str(w['fa'])} ${str(w['ur'])}').contains(nq))
            .toList();
    final cs = Theme.of(context).colorScheme;
    final intro = _isOxford ? str(repo.data['oxfordIntro']) : '';
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: TextField(
              onChanged: (v) => setState(() => _q = v),
              decoration: InputDecoration(
                hintText: _isOxford
                    ? 'لفظ تلاش کریں (انگریزی، فارسی یا اردو)'
                    : 'لفظ تلاش کریں (عربی یا اردو)',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: cardFill(context),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          if (_isOxford && _q.isEmpty && intro.isNotEmpty)
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 2, 16, 8),
              child: Container(
                width: double.infinity,
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                decoration: BoxDecoration(
                  color: AppColors.gold.withAlpha(38),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.gold.withAlpha(120)),
                ),
                child: Text(
                  intro,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w600,
                      color: cs.onSurface),
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: Text(
                '${localDigits(shown.length)} الفاظ',
                style: TextStyle(color: cs.outline, fontSize: 13),
              ),
            ),
          ),
          Expanded(
            child: shown.isEmpty
                ? const EmptyState(message: 'کوئی لفظ نہیں ملا۔')
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 24),
                    itemCount: shown.length,
                    itemBuilder: (context, i) {
                      final w = shown[i];
                      if (_isOxford) {
                        final g = str(w['g']);
                        final showHeader = g.isNotEmpty &&
                            (i == 0 || str(shown[i - 1]['g']) != g);
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            if (showHeader)
                              Padding(
                                padding:
                                    const EdgeInsets.fromLTRB(20, 14, 20, 2),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 34,
                                      height: 34,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        color: AppColors.gold,
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Text(
                                        g,
                                        style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 17),
                                      ),
                                    ),
                                    const SizedBox(width: 10),
                                    Expanded(
                                      child: Divider(
                                          color:
                                              cs.outlineVariant.withAlpha(160)),
                                    ),
                                  ],
                                ),
                              ),
                            _OxfordCard(w: w),
                          ],
                        );
                      }
                      final pos = str(w['pos']);
                      return PhraseCard(
                        fa: str(w['fa']),
                        ur: str(w['ur']),
                        tag: pos.isEmpty ? null : pos,
                        roman: str(w['ro']),
                        vocalized: str(w['v']),
                        words: w['w'] as List<dynamic>?,
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

/// آکسفورڈ لغت کا کارڈ: مخفف (انگریزی) + مکمل صورت + فارسی + اردو
class _OxfordCard extends StatelessWidget {
  final Map<String, dynamic> w;
  const _OxfordCard({required this.w});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final en = str(w['en']);
    final ex = str(w['ex']);
    final fa = str(w['fa']);
    final ur = str(w['ur']);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(16),
            blurRadius: 14,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              textDirection: TextDirection.ltr,
              crossAxisAlignment: CrossAxisAlignment.baseline,
              textBaseline: TextBaseline.alphabetic,
              children: [
                Text(
                  en,
                  style: TextStyle(
                      fontSize: 21,
                      fontWeight: FontWeight.bold,
                      color: cs.onSurface),
                ),
                if (ex.isNotEmpty) ...[
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      ex,
                      style: TextStyle(
                          fontSize: 16,
                          fontStyle: FontStyle.italic,
                          color: cs.onSurfaceVariant),
                    ),
                  ),
                ],
              ],
            ),
            const SizedBox(height: 8),
            Text(
              fa,
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.right,
              style: faStyle(size: 19, color: cs.onSurface),
            ),
            const SizedBox(height: 4),
            Text(
              ur,
              textDirection: TextDirection.rtl,
              textAlign: TextAlign.right,
              style: urStyle(size: 17, color: cs.onSurfaceVariant),
            ),
          ],
        ),
      ),
    );
  }
}
