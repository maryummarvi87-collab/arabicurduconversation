import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';

const _pronUr = {
  'من': 'میں',
  'تو': 'تو / تم',
  'او': 'وہ',
  'ما': 'ہم',
  'شما': 'آپ / تم',
  'آن\u200Cها': 'وہ سب',
};

/// گردان کے زمانوں کے انگریزی نام (Ayesh کی ہدایت — مصادر کے شروع میں زمانوں کی فہرست)
const _tenseEn = {
  'ماضی مطلق': 'Simple Past',
  'ماضی استمراری': 'Past Continuous',
  'ماضی نقلی استمراری': 'Present Perfect Continuous',
  'ماضی قریب': 'Present Perfect',
  'ماضی بعید': 'Past Perfect',
  'ماضی احتمالی': 'Probable Past',
  'مضارع التزامی': 'Present Subjunctive',
  'حال اخباری': 'Simple Present',
  'حال جاری': 'Present Continuous',
  'مستقبل': 'Simple Future',
  'امر': 'Imperative',
  'نہی': 'Prohibitive (Negative Imperative)',
  'ماضی سادہ': 'Simple Past',
  'مضارع سادہ': 'Present Subjunctive',
};

String tenseEn(String name) => _tenseEn[name] ?? '';

class _TensesCard extends StatelessWidget {
  const _TensesCard();

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    const order = [
      'ماضی مطلق', 'ماضی استمراری', 'ماضی نقلی استمراری', 'ماضی قریب',
      'ماضی بعید', 'ماضی احتمالی', 'مضارع التزامی', 'حال اخباری',
      'حال جاری', 'مستقبل', 'امر', 'نہی',
    ];
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
      ),
      child: ExpansionTile(
        title: Text(
          'گردان کے زمانے',
          style: TextStyle(
            fontSize: 16.5,
            fontWeight: FontWeight.w800,
            color: cs.primary,
          ),
        ),
        subtitle: const Text(
          'Tenses used in these conjugations',
          textDirection: TextDirection.ltr,
          textAlign: TextAlign.left,
          style: TextStyle(fontSize: 12.5),
        ),
        children: [
          for (final t in order)
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 3, 18, 3),
              child: Row(
                children: [
                  Expanded(child: Text(t, style: urStyle(size: 15.5))),
                  Text(
                    _tenseEn[t] ?? '',
                    textDirection: TextDirection.ltr,
                    style: TextStyle(
                      fontSize: 13.5,
                      color: cs.primary.withAlpha(200),
                      fontStyle: FontStyle.italic,
                    ),
                  ),
                ],
              ),
            ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}


/// مصادر و گردان: فارسی افعال، ان کے بن اور مکمل گردان — تلاش کے ساتھ
/// ڈیٹا کی شکل: [{fa, v, ro, ur, past, pres, groups: [{name, forms: [{p, fa, ro}]}]}]
class VerbsScreen extends StatefulWidget {
  const VerbsScreen({super.key});

  @override
  State<VerbsScreen> createState() => _VerbsScreenState();
}

class _VerbsScreenState extends State<VerbsScreen> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final verbs = repo.list('verbs');
    final cs = Theme.of(context).colorScheme;
    final nq = normalize(_q);
    final shown = nq.isEmpty
        ? verbs
        : verbs
            .where((v) => normalize(
                    '${str(v['fa'])} ${str(v['ur'])} ${str(v['past'])} ${str(v['pres'])} ${str(v['ro'])}')
                .contains(nq))
            .toList();
    return Scaffold(
      appBar: AppBar(title: const Text('مصادر و گردان')),
      body: verbs.isEmpty
          ? const EmptyState(
              message: 'ابھی مصادر شامل نہیں۔\nآن لائن اپڈیٹ سے نیا مواد حاصل کریں۔')
          : Column(
              children: [
                SearchBox(
                  hint: 'مصدر تلاش کریں (عربی یا اردو)…',
                  onChanged: (v) => setState(() => _q = v),
                ),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 4),
                  child: Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Text(
                      '${localDigits(shown.length)} مصادر — کسی مصدر پر ٹیپ کریں، اس کی پوری گردان کھل جائے گی',
                      style: TextStyle(color: cs.outline, fontSize: 13),
                    ),
                  ),
                ),
                Expanded(
                  child: shown.isEmpty
                      ? const EmptyState(message: 'کوئی مصدر نہیں ملا۔')
                      : ListView.builder(
                          padding: const EdgeInsets.only(bottom: 24),
                          itemCount: shown.length + 1,
                          itemBuilder: (context, i) {
                            if (i == 0) return const _TensesCard();
                            final v = shown[i - 1];
                            return _VerbCard(verb: v);
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

class _VerbCard extends StatelessWidget {
  final Map<String, dynamic> verb;
  const _VerbCard({required this.verb});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final vocal = str(verb['v']);
    final faShown = vocal.isNotEmpty ? vocal : str(verb['fa']);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(16),
            blurRadius: 14,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute(builder: (_) => VerbDetailScreen(verb: verb)),
          ),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(18, 12, 18, 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(faShown, style: faStyle(size: 22)),
                    ),
                    Expanded(
                      child: Text(
                        str(verb['ur']),
                        style: urStyle(color: cs.onSurface.withAlpha(210)),
                      ),
                    ),
                  ],
                ),
                if (str(verb['ro']).isNotEmpty)
                  Text(
                    str(verb['ro']),
                    style: TextStyle(
                      fontSize: 13.5,
                      color: cs.primary.withAlpha(200),
                      fontStyle: FontStyle.italic,
                    ),
                    textDirection: TextDirection.ltr,
                  ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 8,
                  children: [
                    _stemChip(context, 'بنِ ماضی: ${str(verb['past'])}'),
                    _stemChip(context, 'بنِ مضارع: ${str(verb['pres'])}'),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _stemChip(BuildContext context, String label) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
      decoration: BoxDecoration(
        color: cs.primary.withAlpha(26),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(label,
          style: TextStyle(
              fontSize: 13, color: cs.primary, fontWeight: FontWeight.w700)),
    );
  }
}

/// گردان کی ایک صورت کا کشادہ کارڈ: ضمیر، فارسی صورت، رومن اور اردو ترجمہ
class _FormCard extends StatelessWidget {
  final Map<String, dynamic> form;
  const _FormCard({required this.form});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final pron = str(form['p']);
    final pronLabel = '$pron · ${_pronUr[pron] ?? ''}';
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 14),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: cs.outlineVariant.withAlpha(110)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withAlpha(12),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                decoration: BoxDecoration(
                  color: AppColors.gold.withAlpha(45),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  pronLabel,
                  style: const TextStyle(
                      fontSize: 13, fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(str(form['fa']), style: faStyle(size: 22)),
              ),
            ],
          ),
          if (str(form['ro']).isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(
                str(form['ro']),
                style: TextStyle(
                  fontSize: 13.5,
                  color: cs.primary.withAlpha(200),
                  fontStyle: FontStyle.italic,
                ),
                textDirection: TextDirection.ltr,
              ),
            ),
          if (str(form['u']).isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                str(form['u']),
                style: urStyle(size: 17, color: cs.onSurface.withAlpha(215)),
              ),
            ),
        ],
      ),
    );
  }
}

/// ایک مصدر کی مکمل گردان: ماضی، حال، مستقبل، امر
class VerbDetailScreen extends StatelessWidget {
  final Map<String, dynamic> verb;
  const VerbDetailScreen({super.key, required this.verb});

  String _fullText() {
    final b = StringBuffer()
      ..writeln('${str(verb['fa'])} — ${str(verb['ur'])}')
      ..writeln('بنِ ماضی: ${str(verb['past'])} · بنِ مضارع: ${str(verb['pres'])}');
    if (asMaps(verb['derivs']).isNotEmpty) {
      b.writeln('مشتقات:');
      for (final dv in asMaps(verb['derivs'])) {
        b.writeln(
            '${str(dv['t'])}: ${str(dv['fa'])} (${str(dv['ro'])}) — ${str(dv['ur'])}');
      }
    } else if (str(verb['deriv']).isNotEmpty) {
      b.writeln('مشتقات: ${str(verb['deriv'])}');
    }
    for (final g in asMaps(verb['groups'])) {
      b.writeln('\n${str(g['name'])}');
      for (final f in asMaps(g['forms'])) {
        b.writeln('${str(f['p'])}: ${str(f['fa'])} — ${str(f['u'])}');
      }
    }
    return b.toString();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final vocal = str(verb['v']);
    final faShown = vocal.isNotEmpty ? vocal : str(verb['fa']);
    final groups = asMaps(verb['groups']);
    return Scaffold(
      appBar: AppBar(
        title: Text(str(verb['fa'])),
        actions: [
          IconButton(
            tooltip: 'کاپی',
            icon: const Icon(Icons.copy_rounded),
            onPressed: () => copyText(context, _fullText()),
          ),
          IconButton(
            tooltip: 'شیئر',
            icon: const Icon(Icons.ios_share_rounded),
            onPressed: () => shareText(_fullText()),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 28),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: cardFill(context),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: cs.outlineVariant.withAlpha(110)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(faShown, style: faStyle(size: 30)),
                if (str(verb['ro']).isNotEmpty)
                  Text(
                    str(verb['ro']),
                    style: TextStyle(
                      fontSize: 15,
                      color: cs.primary.withAlpha(210),
                      fontStyle: FontStyle.italic,
                    ),
                    textDirection: TextDirection.ltr,
                  ),
                const SizedBox(height: 6),
                Text(str(verb['ur']),
                    style: urStyle(
                        size: 18, color: cs.onSurface.withAlpha(220))),
                const Divider(height: 26),
                _stemRow(context, 'بنِ ماضی', str(verb['past']),
                    str(verb['pastRo'])),
                const SizedBox(height: 6),
                _stemRow(context, 'بنِ مضارع', str(verb['pres']),
                    str(verb['presRo'])),
                const SizedBox(height: 8),
                Text(
                  'ماضی بنِ ماضی سے اور حال بنِ مضارع سے بنتا ہے۔ نیچے اسی مصدر کی مکمل گردان دی گئی ہے۔',
                  style: TextStyle(color: cs.outline, fontSize: 13.5),
                ),
              ],
            ),
          ),
          if (asMaps(verb['derivs']).isNotEmpty) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 22, 6, 10),
              child: Text(
                'مشتقات',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w800,
                  color: cs.primary,
                ),
              ),
            ),
            for (final dv in asMaps(verb['derivs']))
              Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.fromLTRB(14, 10, 14, 12),
                decoration: BoxDecoration(
                  color: cardFill(context),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: cs.outlineVariant.withAlpha(110)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (str(dv['t']).isNotEmpty)
                      Text(
                        str(dv['t']),
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w700,
                          color: cs.primary,
                        ),
                      ),
                    Text(
                      str(dv['v']).isNotEmpty ? str(dv['v']) : str(dv['fa']),
                      style: faStyle(size: 20),
                    ),
                    if (str(dv['ro']).isNotEmpty)
                      Text(
                        str(dv['ro']),
                        style: TextStyle(
                          fontSize: 13,
                          color: cs.primary.withAlpha(190),
                          fontStyle: FontStyle.italic,
                        ),
                        textDirection: TextDirection.ltr,
                        textAlign: TextAlign.left,
                      ),
                    if (str(dv['ur']).isNotEmpty)
                      Text(
                        str(dv['ur']),
                        style: urStyle(
                            size: 15.5, color: cs.onSurface.withAlpha(215)),
                      ),
                  ],
                ),
              ),
          ],
          for (final g in groups) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(6, 22, 6, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    str(g['name']),
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: cs.primary,
                    ),
                  ),
                  if (tenseEn(str(g['name'])).isNotEmpty)
                    Text(
                      tenseEn(str(g['name'])),
                      textDirection: TextDirection.ltr,
                      textAlign: TextAlign.left,
                      style: TextStyle(
                        fontSize: 13,
                        color: cs.primary.withAlpha(190),
                        fontStyle: FontStyle.italic,
                      ),
                    ),
                ],
              ),
            ),
            for (final f in asMaps(g['forms'])) _FormCard(form: f),
          ],
          const SizedBox(height: 14),
          OutlinedButton.icon(
            onPressed: () => openFeedback(context, _fullText()),
            icon: const Icon(Icons.edit_note_rounded),
            label: const Text('تصحیح / اضافے کی تجویز'),
          ),
        ],
      ),
    );
  }

  Widget _stemRow(
      BuildContext context, String label, String fa, String ro) {
    final cs = Theme.of(context).colorScheme;
    return Row(
      children: [
        SizedBox(
          width: 92,
          child: Text(label,
              style: TextStyle(color: cs.outline, fontSize: 14.5)),
        ),
        Text(fa, style: faStyle(size: 20)),
        const SizedBox(width: 10),
        Text(
          ro,
          style: TextStyle(
            fontSize: 13.5,
            color: cs.primary.withAlpha(190),
            fontStyle: FontStyle.italic,
          ),
          textDirection: TextDirection.ltr,
        ),
      ],
    );
  }
}
