import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';
import '../theme.dart';
import 'book_page_screen.dart';
import 'collection_screen.dart';
import 'dialects_screen.dart';
import 'dictionary_screen.dart';
import 'sentences_screen.dart';
import 'verbs_screen.dart';

/// پوری ایپ میں تلاش: اردو اور فارسی دونوں زبانوں میں
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List<Hit> _hits = [];
  String _q = '';

  void _open(Hit h) {
    if (h.section == 'books') {
      final lessons = <Map<String, dynamic>>[];
      for (final b in repo.list('books')) {
        lessons.addAll(asMaps(b['lessons']));
      }
      if (h.index < 0 || h.index >= lessons.length) return;
      Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => BookPageScreen(item: lessons[h.index])));
      return;
    }
    final items = repo.list(h.section);
    if (h.index < 0 || h.index >= items.length) return;
    final item = items[h.index];
    Widget? page;
    if (const ['lessons', 'conversation', 'stories', 'poems', 'quran'].contains(h.section)) {
      page = PhraseSetScreen(data: item);
    } else if (const ['grammar', 'articles'].contains(h.section)) {
      page = TextDetailScreen(item: item);
    } else if (h.section == 'sentences') {
      page = const SentencesScreen();
    } else if (h.section == 'verbs') {
      page = VerbDetailScreen(verb: item);
    } else if (h.section == 'dictionary') {
      page = const DictionaryScreen();
    } else if (h.section == 'oxford') {
      page = const DictionaryScreen(
          dataKey: 'oxford', title: 'آکسفورڈ انگریزی فارسی اُردو لغت');
    } else if (h.section == 'dialects') {
      page = const DialectsScreen();
    }
    if (page == null) return;
    final target = page;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => target));
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('تلاش')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: TextField(
              autofocus: true,
              onChanged: (v) => setState(() {
                _q = v;
                _hits = repo.search(v);
              }),
              decoration: InputDecoration(
                hintText: 'اردو، عربی یا انگریزی میں لکھیں…',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: cardFill(context),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Expanded(
            child: _q.trim().isEmpty
                ? EmptyState(
                    message:
                        'اردو، عربی یا انگریزی میں کوئی لفظ لکھیں۔\nمثلاً: كتاب، ماء، کتاب، پانی، book')
                : _hits.isEmpty
                    ? const EmptyState(message: 'کوئی نتیجہ نہیں ملا۔')
                    : ListView.builder(
                        padding: const EdgeInsets.only(bottom: 24),
                        itemCount: _hits.length + 1,
                        itemBuilder: (context, i) {
                          if (i == 0) {
                            return Padding(
                              padding: const EdgeInsets.fromLTRB(20, 0, 20, 4),
                              child: Text(
                                '${localDigits(_hits.length)} نتائج',
                                style: TextStyle(color: cs.outline, fontSize: 13),
                              ),
                            );
                          }
                          final h = _hits[i - 1];
                          final sItems = repo.list(h.section);
                          final sItem = (h.index >= 0 && h.index < sItems.length)
                              ? sItems[h.index]
                              : null;
                          return PhraseCard(
                            fa: h.fa,
                            ur: h.ur,
                            tag: h.kind,
                            roman: sItem != null ? str(sItem['ro']) : null,
                            vocalized: sItem != null ? str(sItem['v']) : null,
                            words: sItem != null
                                ? sItem['w'] as List<dynamic>?
                                : null,
                            onTap: () => _open(h),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
