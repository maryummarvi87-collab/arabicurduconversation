import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import '../data/repository.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';
import '../widgets/detail_sheet.dart';
import '../theme.dart';
import 'book_page_screen.dart';
import 'collection_screen.dart';
import 'dialects_screen.dart';
import 'verbs_screen.dart';

/// سرچ انجن: ایک لفظ لکھیں — معنی، گردان، جملے اور گرامر ایک جگہ۔
/// آفلائن: ایپ کے موجود/محفوظ مواد میں تلاش۔ آن لائن: کھلتے ہی تازہ مواد
/// خود حاصل کر کے اسی میں تلاش؛ نتیجہ نہ ملے تو ویب تلاش کی سہولت بھی۔
class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  List<Hit> _hits = [];
  String _q = '';
  bool _refreshing = false;
  bool _onlineTried = false;
  // انٹرنیٹ تلاش کے نتائج
  List<Map<String, String>> _web = [];
  bool _webLoading = false;
  bool _webDone = false;

  @override
  void initState() {
    super.initState();
    _refreshOnline(silent: true);
  }

  Future<void> _refreshOnline({bool silent = false}) async {
    if (_refreshing) return;
    _refreshing = true;
    final before = repo.version;
    final r = await repo.checkForUpdate();
    _refreshing = false;
    if (!mounted) return;
    setState(() {
      _onlineTried = true;
      if (_q.trim().isNotEmpty) _hits = repo.search(_q);
    });
    if (!silent && repo.version == before) {
      showSnack(context, r.message);
    }
  }

  void _open(Hit h) {
    final items = repo.list(h.section);
    if (h.index < 0 || h.index >= items.length) {
      if (h.section == 'books') _openBook(h);
      return;
    }
    final item = items[h.index];
    // معنی اور جملے: سیدھا تفصیل کھولیں
    if (h.section == 'dictionary' ||
        h.section == 'oxford' ||
        h.section == 'sentences') {
      openDetail(
        context,
        fa: h.fa,
        ur: h.ur,
        vocalized: str(item['v']),
        roman: str(item['ro']),
        words: item['w'] as List<dynamic>?,
        tag: h.kind,
        root: str(item['root']),
        plural: str(item['pl']),
        grammar: str(item['gr']),
        english: str(item['en']),
        transitivity: str(item['tr']),
        pos: str(item['pos']),
      );
      return;
    }
    if (h.section == 'wordbank') {
      openDetail(
        context,
        fa: h.fa,
        ur: h.ur,
        roman: str(item['ro']),
        grammar: str(item['gr']),
        tag: h.kind,
      );
      return;
    }
    if (h.section == 'sarfbank') {
      openDetail(
        context,
        fa: h.fa,
        ur: h.ur,
        tag: h.kind,
        root: str(item['root']),
        english: str(item['en']),
        transitivity: str(item['tr']),
      );
      return;
    }
    if (h.section == 'books') {
      _openBook(h);
      return;
    }
    Widget? page;
    if (const ['lessons', 'conversation', 'stories', 'poems', 'quran']
        .contains(h.section)) {
      page = PhraseSetScreen(data: item);
    } else if (const ['grammar', 'articles'].contains(h.section)) {
      page = TextDetailScreen(item: item);
    } else if (h.section == 'verbs') {
      page = VerbDetailScreen(verb: item);
    } else if (h.section == 'dialects') {
      page = const DialectsScreen();
    }
    if (page == null) return;
    final target = page;
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => target));
  }

  void _openBook(Hit h) {
    final lessons = <Map<String, dynamic>>[];
    for (final b in repo.list('books')) {
      lessons.addAll(asMaps(b['lessons']));
    }
    if (h.index < 0 || h.index >= lessons.length) return;
    Navigator.of(context).push(MaterialPageRoute(
        builder: (_) => BookPageScreen(item: lessons[h.index])));
  }

  Future<void> _webSearch() async {
    final q = Uri.encodeComponent(_q.trim());
    final uri = Uri.parse('https://www.google.com/search?q=$q');
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  }

  String _stripHtml(String s) => s
      .replaceAll(RegExp(r'<[^>]+>'), '')
      .replaceAll('&amp;', '&')
      .replaceAll('&quot;', '"')
      .replaceAll('&#39;', "'")
      .replaceAll('&lt;', '<')
      .replaceAll('&gt;', '>')
      .trim();

  /// انٹرنیٹ سے لائیو تلاش — نتائج ایپ کے اندر ہی دکھائے جاتے ہیں
  Future<void> _runWebSearch() async {
    final query = _q.trim();
    if (query.isEmpty || _webLoading) return;
    setState(() {
      _webLoading = true;
      _webDone = false;
      _web = [];
    });
    try {
      final uri = Uri.parse(
          'https://www.bing.com/search?q=${Uri.encodeComponent(query)}');
      final res = await http.get(uri, headers: {
        'User-Agent':
            'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36',
      }).timeout(const Duration(seconds: 20));
      final html = res.body;
      final linkRe = RegExp(r'<a[^>]*href="(http[^"]+)"[^>]*>\s*<h2[^>]*>(.*?)</h2>',
          dotAll: true);
      final snipRe = RegExp(r'<p[^>]*>(.*?)</p>', dotAll: true);
      final out = <Map<String, String>>[];
      for (final chunk in html.split('class="b_algo"').skip(1)) {
        final m = linkRe.firstMatch(chunk);
        if (m == null) continue;
        final title = _stripHtml(m.group(2) ?? '');
        if (title.isEmpty) continue;
        final sm = snipRe.firstMatch(chunk);
        out.add({
          'title': title,
          'url': m.group(1) ?? '',
          'snippet': sm != null ? _stripHtml(sm.group(1) ?? '') : '',
        });
        if (out.length >= 10) break;
      }
      if (!mounted) return;
      setState(() {
        _web = out;
        _webLoading = false;
        _webDone = true;
      });
      if (out.isEmpty) {
        showSnack(context, 'انٹرنیٹ سے کوئی نتیجہ نہیں ملا۔');
      }
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _webLoading = false;
        _webDone = true;
      });
      showSnack(context, 'انٹرنیٹ سے رابطہ نہیں ہو سکا۔');
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    // گروپ بندی: معنی، گردان، جملے، گرامر، باقی متن
    final groups = <String, List<Hit>>{};
    for (final h in _hits) {
      final g = switch (h.section) {
        'dictionary' || 'oxford' || 'wordbank' => 'معنی',
        'verbs' || 'sarfbank' => 'گردان',
        'sentences' => 'جملے',
        'quran' => 'قرآن و احادیث',
        'grammar' || 'articles' => 'گرامر و مضامین',
        _ => 'اسباق و متن',
      };
      groups.putIfAbsent(g, () => []).add(h);
    }
    const order = ['معنی', 'گردان', 'جملے', 'قرآن و احادیث', 'گرامر و مضامین', 'اسباق و متن'];

    return Scaffold(
      appBar: AppBar(title: const Text('سرچ انجن')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
            child: TextField(
              autofocus: true,
              onChanged: (v) => setState(() {
                _q = v;
                _hits = repo.search(v, limit: 300);
                _web = [];
                _webDone = false;
              }),
              decoration: InputDecoration(
                hintText: 'عربی (اعراب کے بغیر بھی)، اُردو یا انگریزی میں لفظ لکھیں',
                prefixIcon: const Icon(Icons.search_rounded),
                filled: true,
                fillColor: cardFill(context),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(18),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 12, 4),
            child: Row(
              children: [
                Icon(
                  _onlineTried ? Icons.cloud_done_rounded : Icons.cloud_off_rounded,
                  size: 16,
                  color: cs.outline,
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    'مواد ورژن ${localDigits(repo.version)}'
                    '${_onlineTried ? ' · آن لائن جانچ ہو گئی' : ' · آفلائن مواد'}',
                    style: TextStyle(color: cs.outline, fontSize: 12.5),
                  ),
                ),
                TextButton.icon(
                  onPressed: _refreshing ? null : () => _refreshOnline(),
                  icon: const Icon(Icons.refresh_rounded, size: 17),
                  label: const Text('آن لائن تازہ کریں'),
                ),
              ],
            ),
          ),
          Expanded(
            child: _q.trim().isEmpty
                ? const EmptyState(
                    message:
                        'عربی میں اعراب کے بغیر بھی لکھ سکتے ہیں، اُردو معنی یا انگریزی لفظ بھی۔\nمثلاً: كتاب، پانی، water، كَتَبَ')
                : _hits.isEmpty && !_webDone && !_webLoading
                    ? Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const EmptyState(message: 'ایپ کے مواد میں یہ لفظ نہیں ملا۔'),
                          const SizedBox(height: 8),
                          FilledButton.icon(
                            onPressed: _runWebSearch,
                            icon: const Icon(Icons.travel_explore_rounded),
                            label: const Text('انٹرنیٹ سے تلاش کریں'),
                          ),
                          const SizedBox(height: 6),
                          TextButton.icon(
                            onPressed: _webSearch,
                            icon: const Icon(Icons.language_rounded),
                            label: const Text('گوگل پر کھولیں'),
                          ),
                        ],
                      )
                    : ListView(
                        padding: const EdgeInsets.only(bottom: 96),
                        children: [
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 2, 20, 2),
                            child: Text(
                              '${localDigits(_hits.length)} نتائج',
                              style:
                                  TextStyle(color: cs.outline, fontSize: 13),
                            ),
                          ),
                          for (final g in order)
                            if (groups[g] != null) ...[
                              Padding(
                                padding:
                                    const EdgeInsets.fromLTRB(20, 14, 20, 2),
                                child: Text(
                                  '$g (${localDigits(groups[g]!.length)})',
                                  style: TextStyle(
                                    fontSize: 17,
                                    fontWeight: FontWeight.w800,
                                    color: cs.primary,
                                  ),
                                ),
                              ),
                              for (final h in groups[g]!)
                                Builder(builder: (context) {
                                  final sItems = repo.list(h.section);
                                  final sItem = (h.index >= 0 &&
                                          h.index < sItems.length)
                                      ? sItems[h.index]
                                      : null;
                                  return PhraseCard(
                                    fa: h.fa,
                                    ur: h.ur,
                                    tag: h.kind,
                                    roman:
                                        sItem != null ? str(sItem['ro']) : null,
                                    vocalized:
                                        sItem != null ? str(sItem['v']) : null,
                                    words: sItem != null
                                        ? sItem['w'] as List<dynamic>?
                                        : null,
                                    onTap: () => _open(h),
                                  );
                                }),
                            ],
                          // ---------- انٹرنیٹ کے نتائج ----------
                          Padding(
                            padding: const EdgeInsets.fromLTRB(20, 18, 20, 2),
                            child: Text(
                              'انٹرنیٹ سے تلاش',
                              style: TextStyle(
                                fontSize: 17,
                                fontWeight: FontWeight.w800,
                                color: cs.primary,
                              ),
                            ),
                          ),
                          if (_webLoading)
                            const Padding(
                              padding: EdgeInsets.all(16),
                              child: Center(child: CircularProgressIndicator()),
                            )
                          else if (!_webDone)
                            Padding(
                              padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
                              child: FilledButton.icon(
                                onPressed: _runWebSearch,
                                icon: const Icon(Icons.travel_explore_rounded),
                                label: const Text('انٹرنیٹ سے بھی تلاش کریں'),
                              ),
                            )
                          else if (_web.isEmpty)
                            const Padding(
                              padding: EdgeInsets.fromLTRB(20, 6, 20, 0),
                              child: Text('انٹرنیٹ سے کوئی نتیجہ نہیں ملا۔'),
                            )
                          else
                            for (final w in _web)
                              Card(
                                margin: const EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 5),
                                child: ListTile(
                                  title: Text(w['title'] ?? '',
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w700,
                                          fontSize: 15)),
                                  subtitle: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      if ((w['snippet'] ?? '').isNotEmpty)
                                        Text(w['snippet'] ?? '',
                                            style: const TextStyle(fontSize: 13.5)),
                                      Text(
                                        Uri.tryParse(w['url'] ?? '')
                                                ?.host ??
                                            '',
                                        textDirection: TextDirection.ltr,
                                        textAlign: TextAlign.end,
                                        style: TextStyle(
                                            color: cs.outline, fontSize: 12),
                                      ),
                                    ],
                                  ),
                                  trailing: const Icon(Icons.open_in_new_rounded,
                                      size: 19),
                                  onTap: () => launchUrl(
                                      Uri.parse(w['url'] ?? ''),
                                      mode: LaunchMode.externalApplication),
                                ),
                              ),
                        ],
                      ),
          ),
        ],
      ),
    );
  }
}
