import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../sarf/sarf_engine.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import '../widgets/common.dart';
import '../widgets/detail_sheet.dart';

const _babLabels = {
  1: 'باب ۱ — نَصَرَ يَنْصُرُ',
  2: 'باب ۲ — ضَرَبَ يَضْرِبُ',
  3: 'باب ۳ — فَتَحَ يَفْتَحُ',
  4: 'باب ۴ — عَلِمَ يَعْلَمُ',
  5: 'باب ۵ — كَرُمَ يَكْرُمُ',
  6: 'باب ۶ — حَسِبَ يَحْسِبُ',
};

Widget _card(BuildContext context, Widget child, {VoidCallback? onTap}) {
  final cs = Theme.of(context).colorScheme;
  return Container(
    margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
    decoration: BoxDecoration(
      color: cardFill(context),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: cs.outlineVariant.withAlpha(110)),
    ),
    child: Material(
      color: Colors.transparent,
      borderRadius: BorderRadius.circular(20),
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: onTap,
        child: child,
      ),
    ),
  );
}

Widget _chip(BuildContext context, String text) => Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(
        color: AppColors.gold.withAlpha(46),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Text(text,
          style: TextStyle(
              fontSize: 12.5,
              fontWeight: FontWeight.w700,
              // ڈارک موڈ میں deepTeal مدھم سنہرے پس منظر پر گم ہو جاتا تھا — روشن پیلا
              color: Theme.of(context).brightness == Brightness.dark
                  ? const Color(0xFFFFD740)
                  : AppColors.deepTeal)),
    );

class SarfScreen extends StatefulWidget {
  const SarfScreen({super.key});
  @override
  State<SarfScreen> createState() => _SarfScreenState();
}

class _SarfScreenState extends State<SarfScreen> {
  String _q = '';
  final _root = TextEditingController();
  final _ur = TextEditingController();
  int _bab = 1;

  @override
  void dispose() {
    _root.dispose();
    _ur.dispose();
    super.dispose();
  }

  void _openResult(SarfResult r,
      {String ur = '', String en = '', String type = '', String? amrNote}) {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => SarfResultScreen(
                result: r, ur: ur, en: en, type: type, amrNote: amrNote)));
  }

  void _openBank(Map<String, dynamic> e) {
    final urFull = str(e['ur']);
    final urFirst = urFull.split('،').first.trim();
    _openResult(
      conjugate(str(e['root']), (e['bab'] as num).toInt(), str(e['masdar']),
          urFirst.isEmpty ? 'کرنا' : urFirst),
      ur: urFull,
      en: str(e['en']),
      type: str(e['type']),
      amrNote: e['amrNote']?.toString(),
    );
  }

  void _openCustom() {
    final root = _root.text.trim();
    if (root.length != 3) {
      showSnack(context, 'مادے کے پورے تین حروف لکھیں، مثلاً: كتب');
      return;
    }
    final ur = _ur.text.trim();
    try {
      _openResult(
        conjugate(root, _bab, '', ur.isEmpty ? 'کرنا' : ur),
        ur: ur,
        type: 'ثلاثی مجرد',
      );
    } catch (_) {
      showSnack(context, 'گردان نہ بن سکی — مادہ جانچ کر دوبارہ کوشش کریں');
    }
  }

  @override
  Widget build(BuildContext context) {
    final bank = repo.list('sarfbank');
    final nq = normalize(_q);
    final hits = nq.isEmpty
        ? bank
        : bank
            .where((e) => normalize(
                    '${str(e['root'])} ${str(e['masdar'])} ${str(e['ur'])} ${str(e['en'])}')
                .contains(nq))
            .toList();
    return Scaffold(
      appBar: AppBar(title: const Text('گردان ساز')),
      body: Column(
        children: [
          const SizedBox(height: 10),
          SearchBox(
            hint: 'فعل تلاش کریں — اُردو، عربی یا انگریزی (لکھنا، write)',
            onChanged: (v) => setState(() => _q = v),
          ),
          _card(
            context,
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('اپنا فعل بنائیں — مادہ اور باب لکھیں',
                      style: TextStyle(
                          fontSize: 16.5,
                          fontWeight: FontWeight.w800,
                          color:
                              Theme.of(context).brightness == Brightness.dark
                                  ? const Color(0xFFFFD740)
                                  : AppColors.teal)),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _root,
                          textAlign: TextAlign.center,
                          style: faStyle(size: 19),
                          decoration: const InputDecoration(
                              labelText: 'مادہ (۳ حروف)',
                              border: OutlineInputBorder()),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: DropdownButtonFormField<int>(
                          initialValue: _bab,
                          isExpanded: true,
                          decoration: const InputDecoration(
                              labelText: 'باب', border: OutlineInputBorder()),
                          items: [
                            for (var i = 1; i <= 6; i++)
                              DropdownMenuItem(
                                  value: i,
                                  child: Text(_babLabels[i]!,
                                      style: const TextStyle(fontSize: 13.5)))
                          ],
                          onChanged: (v) => setState(() => _bab = v ?? 1),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _ur,
                          decoration: const InputDecoration(
                              labelText: 'اُردو مصدر (مثلاً لکھنا)',
                              border: OutlineInputBorder()),
                        ),
                      ),
                      const SizedBox(width: 8),
                      FilledButton(
                          onPressed: _openCustom,
                          child: const Text('گردان بنائیں')),
                    ],
                  ),
                ],
              ),
            ),
          ),
          Expanded(
            child: hits.isEmpty
                ? const EmptyState(message: 'کوئی فعل نہیں ملا')
                : ListView.builder(
                    padding: const EdgeInsets.only(bottom: 16),
                    itemCount: hits.length,
                    itemBuilder: (context, i) {
                      final e = hits[i];
                      return _card(
                        context,
                        Padding(
                          padding: const EdgeInsets.all(13),
                          child: Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(str(e['masdar']),
                                        style: faStyle(size: 21)),
                                    Text('${str(e['ur'])}  •  ${str(e['en'])}',
                                        style: urStyle(size: 14.5)),
                                  ],
                                ),
                              ),
                              _chip(context, str(e['type'])),
                            ],
                          ),
                        ),
                        onTap: () => _openBank(e),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class SarfResultScreen extends StatelessWidget {
  final SarfResult result;
  final String ur, en, type;
  final String? amrNote;
  const SarfResultScreen(
      {super.key,
      required this.result,
      this.ur = '',
      this.en = '',
      this.type = '',
      this.amrNote});

  @override
  Widget build(BuildContext context) {
    final r = result;
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(
          title: Text('گردان: ${r.masdar.isEmpty ? r.root : r.masdar}')),
      body: ListView(
        padding: const EdgeInsets.only(top: 8, bottom: 20),
        children: [
          _card(
            context,
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (r.masdar.isNotEmpty) Text(r.masdar, style: faStyle(size: 27)),
                  if (ur.isNotEmpty || en.isNotEmpty)
                    Text([ur, en].where((s) => s.isNotEmpty).join('  •  '),
                        style: urStyle(size: 16)),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    runSpacing: 6,
                    children: [
                      _chip(context, 'مادہ: ${r.root}'),
                      _chip(context, r.babName),
                      if (type.isNotEmpty) _chip(context, type),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text('اسم فاعل: ${r.fael}ٌ   •   اسم مفعول: ${r.mafool}ٌ',
                      style: faStyle(size: 17)),
                  Text('${r.faelRoman}  •  ${r.mafoolRoman}',
                      style: TextStyle(
                          fontSize: 13.5,
                          fontStyle: FontStyle.italic,
                          color:
                              Theme.of(context).brightness == Brightness.dark
                                  ? const Color(0xFF82B1FF)
                                  : const Color(0xFF1565C0))),
                  if (amrNote != null && amrNote!.isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 6),
                      child: Text(amrNote!, style: urStyle(size: 14)),
                    ),
                ],
              ),
            ),
          ),
          for (final g in r.groups) ...[
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 2),
              child: Text('${g.name} — ${g.nameAr}',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.w800,
                      color: cs.primary)),
            ),
            for (final f in g.forms)
              _card(
                context,
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                              child: Text(f.form, style: faStyle(size: 20))),
                          _chip(context, f.pronounAr),
                        ],
                      ),
                      if (f.roman.isNotEmpty)
                        Text(f.roman,
                            style: TextStyle(
                                fontSize: 13,
                                fontStyle: FontStyle.italic,
                                color: Theme.of(context).brightness ==
                                        Brightness.dark
                                    ? const Color(0xFF82B1FF)
                                    : const Color(0xFF1565C0))),
                      Text(f.urdu, style: urStyle(size: 15)),
                    ],
                  ),
                ),
                onTap: () => openDetail(context, fa: f.form, ur: f.urdu, roman: f.roman, grammar: 'گردان ساز — مادہ: ${r.root}، ${r.babName}')),
          ],
        ],
      ),
    );
  }
}
