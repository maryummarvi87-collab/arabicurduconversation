import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

/// مکمل قرآن مجید کا ڈیٹا — نورِ قرآن خط (انڈوپاک رسم الخط) + لفظی معانی
/// ڈیٹا: assets/data/quran_indopak.json + assets/data/quran_words.json
/// مصحف اسکرین اور آیت میچر (کتابی صفحات کے ﴿ ﴾ بلاک) دونوں یہی کیش استعمال کرتے ہیں
class MushafData {
  static Map<String, dynamic>? _quran;
  static Map<String, dynamic>? _words;
  static Future<Map<String, dynamic>> loadQuran() async {
    if (_quran != null) return _quran!;
    final s = await rootBundle.loadString('assets/data/quran_indopak.json');
    _quran = jsonDecode(s) as Map<String, dynamic>;
    return _quran!;
  }

  static Future<Map<String, dynamic>> loadWords() async {
    if (_words != null) return _words!;
    final s = await rootBundle.loadString('assets/data/quran_words.json');
    _words = jsonDecode(s) as Map<String, dynamic>;
    return _words!;
  }
}
