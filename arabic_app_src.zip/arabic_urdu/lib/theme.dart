import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  // مرکزی رنگ: بھورا (Ayesh کی ہدایت) — باقی رنگ بھی بھورے کے شیڈز
  static const Color teal = Color(0xFF8B5A2B);
  static const Color deepTeal = Color(0xFF4E2E1B);
  static const Color gold = Color(0xFFC9A227);
  static const Color ivory = Color(0xFFFFF8EC);
  static const Color night = Color(0xFF1E130C);
  static const Color lapis = Color(0xFF6D4C41);
  static const Color rose = Color(0xFF9C5B3C);
  static const Color emerald = Color(0xFF7A5C33);
  static const Color saffron = Color(0xFFB07D2B);
  static const Color plum = Color(0xFF5D4037);
}

ThemeData buildTheme(Brightness b) {
  final scheme = ColorScheme.fromSeed(seedColor: AppColors.teal, brightness: b);
  final base = ThemeData(useMaterial3: true, colorScheme: scheme);
  final text = GoogleFonts.notoNaskhArabicTextTheme(base.textTheme)
      .apply(bodyColor: scheme.onSurface, displayColor: scheme.onSurface);
  return base.copyWith(
    scaffoldBackgroundColor:
        b == Brightness.light ? AppColors.ivory : AppColors.night,
    textTheme: text,
    appBarTheme: AppBarTheme(
      centerTitle: true,
      backgroundColor: Colors.transparent,
      elevation: 0,
      scrolledUnderElevation: 0,
      foregroundColor: scheme.onSurface,
      titleTextStyle: GoogleFonts.notoNaskhArabic(
        fontSize: 21,
        fontWeight: FontWeight.w700,
        color: scheme.onSurface,
      ),
    ),
    snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
  );
}

/// کارڈ کا پس منظر (روشن/تاریک دونوں کے لیے)
Color cardFill(BuildContext context) =>
    Theme.of(context).brightness == Brightness.dark
        ? const Color(0xFF2A1B11)
        : const Color(0xFFFFFBF3);

/// عربی متن کا انداز — جمیل نوری نستعلیق خط (Ayesh کی ہدایت، v1.6.3)؛ اردو کے لیے نستعلیق (urStyle)
TextStyle faStyle({double size = 24, FontWeight w = FontWeight.w600, Color? color}) =>
    TextStyle(fontFamily: 'JameelNoori', fontSize: size, fontWeight: w, color: color, height: 2.2);

/// اردو متن کا انداز (نستعلیق)
TextStyle urStyle({double size = 17, Color? color}) =>
    GoogleFonts.notoNastaliqUrdu(fontSize: size, color: color, height: 2.0);
