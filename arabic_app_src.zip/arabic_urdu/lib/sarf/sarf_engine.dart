/// عربی گردان ساز — بنیادی انجن (v1)
/// ثلاثی مجرد، صحیح سالم افعال، چھ ابواب۔
/// مادہ (3 حروف، بغیر اعراب) + باب → ماضی، مضارع (مرفوع/منصوب/مجزوم)، امر، نہی،
/// اسم فاعل، اسم مفعول — تمام صیغے اعراب کے ساتھ + اُردو ترجمے (سانچوں سے)۔

class SarfForm {
  final String pronounAr; // ضمیر: هُوَ، هُمَا ...
  final String pronounUr; // اُردو ضمیر/اشارہ
  final String form; // عربی صورت (اعراب دار)
  final String urdu; // اُردو ترجمہ
  const SarfForm(this.pronounAr, this.pronounUr, this.form, this.urdu);
}

class SarfGroup {
  final String name; // زمانے کا نام (اُردو)
  final String nameAr; // عربی نام
  final List<SarfForm> forms;
  const SarfGroup(this.name, this.nameAr, this.forms);
}

class SarfResult {
  final String root; // مادہ
  final String babName; // باب کا نام
  final String masdar; // مصدر (بینک سے)
  final String fael; // اسم فاعل
  final String mafool; // اسم مفعول
  final List<SarfGroup> groups;
  const SarfResult(this.root, this.babName, this.masdar, this.fael,
      this.mafool, this.groups);
}

// اعراب
const _a = 'َ'; // فتحہ
const _i = 'ِ'; // کسرہ
const _u = 'ُ'; // ضمہ
const _s = 'ْ'; // سکون

/// ہر باب کی عین کی حرکت: [ماضی کی عین، مضارع کی عین]
const Map<int, List<String>> babVowels = {
  1: [_a, _u], // نَصَرَ يَنْصُرُ
  2: [_a, _i], // ضَرَبَ يَضْرِبُ
  3: [_a, _a], // فَتَحَ يَفْتَحُ
  4: [_i, _a], // عَلِمَ يَعْلَمُ
  5: [_u, _u], // كَرُمَ يَكْرُمُ
  6: [_i, _i], // حَسِبَ يَحْسِبُ
};

const Map<int, String> babNames = {
  1: 'نَصَرَ يَنْصُرُ (فَعَلَ يَفْعُلُ)',
  2: 'ضَرَبَ يَضْرِبُ (فَعَلَ يَفْعِلُ)',
  3: 'فَتَحَ يَفْتَحُ (فَعَلَ يَفْعَلُ)',
  4: 'عَلِمَ يَعْلَمُ (فَعِلَ يَفْعَلُ)',
  5: 'كَرُمَ يَكْرُمُ (فَعُلَ يَفْعُلُ)',
  6: 'حَسِبَ يَحْسِبُ (فَعِلَ يَفْعِلُ)',
};

/// 14 صیغوں کی ترتیب: ضمیر، [بن کی آخری حرکت کے بعد لگنے والا حصہ]
class _Row {
  final String prAr, prUr;
  const _Row(this.prAr, this.prUr);
}

const List<_Row> _rows14 = [
  _Row('هُوَ', 'وہ (مذکر)'),
  _Row('هُمَا', 'وہ دونوں (مذکر)'),
  _Row('هُمْ', 'وہ سب (مذکر)'),
  _Row('هِيَ', 'وہ (مؤنث)'),
  _Row('هُمَا', 'وہ دونوں (مؤنث)'),
  _Row('هُنَّ', 'وہ سب (مؤنث)'),
  _Row('أَنْتَ', 'تم (مذکر)'),
  _Row('أَنْتُمَا', 'تم دونوں (مذکر)'),
  _Row('أَنْتُمْ', 'تم سب (مذکر)'),
  _Row('أَنْتِ', 'تم (مؤنث)'),
  _Row('أَنْتُمَا', 'تم دونوں (مؤنث)'),
  _Row('أَنْتُنَّ', 'تم سب (مؤنث)'),
  _Row('أَنَا', 'میں'),
  _Row('نَحْنُ', 'ہم'),
];

/// ماضی کے اختتام (بن = C1 + فتحہ + C2 + عین حرکت + C3، پھر یہ حصے)
const List<String> _pastEndings = [
  'َ', 'َا', 'ُوا', 'َتْ', 'َتَا', 'ْنَ',
  'ْتَ', 'ْتُمَا', 'ْتُمْ', 'ْتِ', 'ْتُمَا', 'ْتُنَّ',
  'ْتُ', 'ْنَا',
];

/// مضارع: [سابقہ، اختتام] — بن = سابقہ + C1 ساکن + C2 + عین حرکت + C3 + اختتام
const List<List<String>> _presRows = [
  ['ي', 'ُ'], ['ي', 'َانِ'], ['ي', 'ُونَ'],
  ['ت', 'ُ'], ['ت', 'َانِ'], ['ي', 'ْنَ'],
  ['ت', 'ُ'], ['ت', 'َانِ'], ['ت', 'ُونَ'],
  ['ت', 'ِينَ'], ['ت', 'َانِ'], ['ت', 'ْنَ'],
  ['أ', 'ُ'], ['ن', 'ُ'],
];

/// اُردو ترجمے کے سانچے — s = اُردو مصدر کا بن (مثلاً لکھنا ← لکھ)
List<String> _pastUrdu(String s) => [
      'اس نے $sا',
      'ان دونوں نے $sا',
      'ان سب نے $sا',
      'اس نے $sی (مؤنث)',
      'ان دونوں نے $sی (مؤنث)',
      'ان سب نے $sی (مؤنث)',
      'تم نے $sا',
      'تم دونوں نے $sا',
      'تم سب نے $sا',
      'تم نے $sی (مؤنث)',
      'تم دونوں نے $sی (مؤنث)',
      'تم سب نے $sی (مؤنث)',
      'میں نے $sا / $sی',
      'ہم نے $sا',
    ];

List<String> _presUrdu(String s) => [
      'وہ ${s}تا ہے',
      'وہ دونوں ${s}تے ہیں',
      'وہ سب ${s}تے ہیں',
      'وہ ${s}تی ہے',
      'وہ دونوں ${s}تی ہیں',
      'وہ سب ${s}تی ہیں',
      'تم ${s}تے ہو',
      'تم دونوں ${s}تے ہو',
      'تم سب ${s}تے ہو',
      'تم ${s}تی ہو',
      'تم دونوں ${s}تی ہو',
      'تم سب ${s}تی ہو',
      'میں ${s}تا ہوں / ${s}تی ہوں',
      'ہم ${s}تے ہیں',
    ];

/// گردان بناؤ۔ root: تین حروف بغیر اعراب (مثلاً كتب)؛ bab: 1..6؛
/// masdarVocalized: بینک سے مصدر (اعراب دار)؛ urduInfinitive: مثلاً «لکھنا»۔
SarfResult conjugate(String root, int bab, String masdarVocalized,
    String urduInfinitive) {
  final r = root.replaceAll(RegExp('[ً-ٰٟـ ]'), '');
  if (r.length != 3) {
    throw ArgumentError('مادہ تین حروف کا ہونا چاہیے: $root');
  }
  final c1 = r[0], c2 = r[1], c3 = r[2];
  final v = babVowels[bab]!;
  final pastStem = '$c1$_a$c2${v[0]}$c3';
  final presStemCore = '$c1$_s$c2${v[1]}$c3'; // بغیر سابقے/اختتام کے
  final urduStem = urduInfinitive.endsWith('نا')
      ? urduInfinitive.substring(0, urduInfinitive.length - 2)
      : urduInfinitive;

  // ---------- ماضی ----------
  final pastUr = _pastUrdu(urduStem);
  final past = SarfGroup('ماضی', 'الْمَاضِي', [
    for (var i = 0; i < 14; i++)
      SarfForm(_rows14[i].prAr, _rows14[i].prUr,
          '$pastStem${_pastEndings[i]}', pastUr[i]),
  ]);

  // ---------- مضارع مرفوع ----------
  String presForm(int i, String ending) =>
      '${_presRows[i][0]}$_a$presStemCore$ending';
  final presUr = _presUrdu(urduStem);
  final pres = SarfGroup('مضارع (حال)', 'الْمُضَارِع', [
    for (var i = 0; i < 14; i++)
      SarfForm(_rows14[i].prAr, _rows14[i].prUr,
          presForm(i, _presRows[i][1]), presUr[i]),
  ]);

  // ---------- مضارع منصوب (لَنْ) اور مجزوم (لَمْ) ----------
  String moodEnding(String e) {
    if (e == 'ُ') return 'َ'; // مرفوع ← منصوب
    return e;
  }

  String jazmEnding(String e) {
    if (e == 'ُ') return 'ْ';
    if (e == 'َانِ') return 'َا';
    if (e == 'ُونَ') return 'ُوا';
    if (e == 'ِينَ') return 'ِي';
    return e;
  }

  final nasbUr = [
    'وہ ہرگز نہ ${urduStem}ے گا',
    'وہ دونوں ہرگز نہ ${urduStem}یں گے',
    'وہ سب ہرگز نہ ${urduStem}یں گے',
    'وہ (مؤنث) ہرگز نہ ${urduStem}ے گی',
    'وہ دونوں (مؤنث) ہرگز نہ ${urduStem}یں گی',
    'وہ سب (مؤنث) ہرگز نہ ${urduStem}یں گی',
    'تم ہرگز نہ ${urduStem}و گے',
    'تم دونوں ہرگز نہ ${urduStem}و گے',
    'تم سب ہرگز نہ ${urduStem}و گے',
    'تم (مؤنث) ہرگز نہ ${urduStem}و گی',
    'تم دونوں (مؤنث) ہرگز نہ ${urduStem}و گی',
    'تم سب (مؤنث) ہرگز نہ ${urduStem}و گی',
    'میں ہرگز نہ ${urduStem}وں گا / گی',
    'ہم ہرگز نہ ${urduStem}یں گے',
  ];
  final nasb = SarfGroup('مضارع منصوب (لَنْ)', 'الْمَنْصُوب', [
    for (var i = 0; i < 14; i++)
      SarfForm(_rows14[i].prAr, _rows14[i].prUr,
          'لَنْ ${presForm(i, moodEnding(_presRows[i][1]))}', nasbUr[i]),
  ]);
  final jazm = SarfGroup('مضارع مجزوم (لَمْ)', 'الْمَجْزُوم', [
    for (var i = 0; i < 14; i++)
      SarfForm(_rows14[i].prAr, _rows14[i].prUr,
          'لَمْ ${presForm(i, jazmEnding(_presRows[i][1]))}',
          pastUr[i].replaceFirst(' نے ', ' نے نہیں ')),
  ]);

  // ---------- امر و نہی (مخاطب کے 6 صیغے) ----------
  final wasl = v[1] == _u ? 'اُ' : 'اِ';
  const amrIdx = [6, 7, 8, 9, 10, 11];
  const amrEndings = ['ْ', 'َا', 'ُوا', 'ِي', 'َا', 'ْنَ'];
  final amrUr = [
    '${urduStem}و',
    'تم دونوں ${urduStem}و',
    'تم سب ${urduStem}و',
    'تم (مؤنث) ${urduStem}و',
    'تم دونوں (مؤنث) ${urduStem}و',
    'تم سب (مؤنث) ${urduStem}و',
  ];
  final amr = SarfGroup('امر', 'الْأَمْر', [
    for (var k = 0; k < 6; k++)
      SarfForm(_rows14[amrIdx[k]].prAr, _rows14[amrIdx[k]].prUr,
          '$wasl$presStemCore${amrEndings[k]}', amrUr[k]),
  ]);
  final nahi = SarfGroup('نہی', 'النَّهْي', [
    for (var k = 0; k < 6; k++)
      SarfForm(
          _rows14[amrIdx[k]].prAr,
          _rows14[amrIdx[k]].prUr,
          'لَا ${presForm(amrIdx[k], jazmEnding(_presRows[amrIdx[k]][1]))}',
          'مت ${urduStem}و'),
  ]);

  // ---------- مشتقات ----------
  String faelOf() {
    if (c1 == 'أ') return 'آ$c2$_i$c3'; // آكِل
    if (c2 == 'أ') return '$c1${_a}ائ$_i$c3'; // سَائِل
    if (c3 == 'أ') return '$c1$_aا$c2$_iئ'; // قَارِئ
    return '$c1$_aا$c2$_i$c3'; // فَاعِل
  }

  String mafoolOf() {
    if (c3 == 'أ') return 'م$_a$c1$_s$c2$_uوء'; // مَقْرُوء
    return 'م$_a$c1$_s$c2$_uو$c3'; // مَفْعُول
  }

  final fael = faelOf();
  final mafool = mafoolOf();

  return SarfResult(
    r,
    babNames[bab]!,
    masdarVocalized,
    fael,
    mafool,
    [past, pres, nasb, jazm, amr, nahi],
  );
}
