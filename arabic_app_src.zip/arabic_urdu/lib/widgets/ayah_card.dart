import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../services/ayah_matcher.dart';
import '../services/tts_service.dart';
import '../theme.dart';
import 'ayah_word_sheet.dart';
import 'common.dart';

/// ﴿ آیت ﴾ بلاک (کتابی صفحات میں) — قرآنی عربی پر کمپیوٹر آواز کبھی نہیں:
/// یقینی میچ ہو تو اصل تلاوت (مشاری العفاسی) کا بٹن اور لفظ بہ لفظ ٹچ ایبل
/// متن (مصحف والی لفظی تفصیل شیٹ)؛ میچ نہ ہو تو سادہ سنہرا کارڈ، بے اسپیکر۔
class AyahCard extends StatefulWidget {
  final String text;
  const AyahCard({super.key, required this.text});

  @override
  State<AyahCard> createState() => _AyahCardState();
}

class _AyahCardState extends State<AyahCard> {
  AyahMatch? _match;
  bool _done = false;
  final List<TapGestureRecognizer> _recs = [];

  /// سنہرا رنگ — ڈارک موڈ میں روشن پیلا (اس ایپ کا قائم اصول)
  Color _gold(BuildContext context) =>
      Theme.of(context).brightness == Brightness.dark
          ? const Color(0xFFFFD740)
          : AppColors.gold;

  @override
  void initState() {
    super.initState();
    AyahMatcher.instance.match(widget.text).then((m) {
      if (!mounted) return;
      setState(() {
        _match = m;
        _done = true;
      });
    }).catchError((_) {
      if (mounted) setState(() => _done = true);
    });
  }

  @override
  void dispose() {
    for (final r in _recs) {
      r.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final text = widget.text;
    var marks = 0, letters = 0;
    for (final r in text.runes) {
      if ((r >= 0x064B && r <= 0x0652) ||
          r == 0x0670 ||
          (r >= 0x06D6 && r <= 0x06ED)) {
        marks++;
      }
      if (r >= 0x0621 && r <= 0x06D3) letters++;
    }
    final isArabic = letters > 0 && marks * 3 >= letters;
    final style = isArabic
        ? TextStyle(
            fontFamily: 'NoorQuran',
            fontSize: 27,
            height: 1.9,
            color: _gold(context))
        : urStyle(size: 19, color: _gold(context))
            .copyWith(fontWeight: FontWeight.w800);
    final m = _match;
    final touchable = m != null && m.wordRec != null && m.tokenWords.isNotEmpty;
    final Widget textWidget;
    if (touchable) {
      final spans = <TextSpan>[];
      final wordRe = RegExp(r'\S+');
      var last = 0;
      var disp = -1;
      for (final mt in wordRe.allMatches(text)) {
        if (mt.start > last) {
          spans.add(TextSpan(text: text.substring(last, mt.start)));
        }
        final part = mt.group(0)!;
        List<int>? tapIdxs;
        if (normTokenForm(part).isNotEmpty) {
          disp++;
          tapIdxs = m.tokenWords[disp];
        }
        if (tapIdxs != null && tapIdxs.isNotEmpty) {
          final ii = tapIdxs;
          final rec = TapGestureRecognizer()
            ..onTap = () => showAyahWordSheet(context,
                token: part, wordIdxs: ii, wordRec: m.wordRec!);
          _recs.add(rec);
          spans.add(TextSpan(
            text: part,
            style: const TextStyle(
              decoration: TextDecoration.underline,
              decorationStyle: TextDecorationStyle.dotted,
            ),
            recognizer: rec,
          ));
        } else {
          spans.add(TextSpan(text: part));
        }
        last = mt.end;
      }
      if (last < text.length) {
        spans.add(TextSpan(text: text.substring(last)));
      }
      textWidget = Text.rich(
        TextSpan(style: style, children: spans),
        textAlign: TextAlign.center,
        textDirection: TextDirection.rtl,
      );
    } else {
      textWidget = Text(
        text,
        textAlign: TextAlign.center,
        textDirection: isArabic ? TextDirection.rtl : null,
        style: style,
      );
    }
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
      decoration: BoxDecoration(
        color: cardFill(context),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.gold.withAlpha(140)),
      ),
      child: Column(
        children: [
          textWidget,
          if (_done && m != null) ...[
            const SizedBox(height: 6),
            ValueListenableBuilder<int?>(
              valueListenable: recitation.playingAyah,
              builder: (context, playing, _) {
                final isPlaying = playing == m.global;
                return IconButton(
                  tooltip: isPlaying ? 'تلاوت روکیں' : 'تلاوت سنیں — مشاری العفاسی',
                  visualDensity: VisualDensity.compact,
                  icon: Icon(
                    isPlaying
                        ? Icons.stop_circle_rounded
                        : Icons.play_circle_fill_rounded,
                    size: 30,
                    color: AppColors.gold,
                  ),
                  onPressed: () async {
                    try {
                      await recitation.toggle(m.global);
                    } catch (_) {
                      if (context.mounted) {
                        showSnack(context, 'انٹرنیٹ سے تلاوت نہیں آ سکی');
                      }
                    }
                  },
                );
              },
            ),
          ],
        ],
      ),
    );
  }
}
