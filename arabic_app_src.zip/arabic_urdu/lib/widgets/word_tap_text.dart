import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../sarf/sarf_engine.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import 'detail_sheet.dart';

/// لغت میں فارسی لفظ کا معنی تلاش کرو (اعراب اتار کر مقابلہ)
Map<String, String>? lookupFaWord(String word) {
  final nw = normalize(word);
  if (nw.isEmpty) return null;
  for (final e in repo.list('dictionary')) {
    if (normalize(str(e['fa'])) == nw) {
      return {
        'fa': str(e['fa']),
        'ro': str(e['ro']),
        'ur': str(e['ur']),
        'v': str(e['v']),
      };
    }
  }
  return null;
}

/// لغت میں اردو لفظ کا فارسی ترجمہ تلاش کرو (اُلٹی تلاش)
Map<String, String>? lookupUrWord(String word) {
  final nw = normalize(word);
  if (nw.isEmpty) return null;
  for (final e in repo.list('dictionary')) {
    final ur = str(e['ur']);
    if (ur.isEmpty) continue;
    final parts = normalize(ur).split(RegExp(r'[/،,؛|]'));
    if (parts.any((p) => p.trim() == nw)) {
      return {
        'fa': str(e['fa']),
        'ro': str(e['ro']),
        'ur': ur,
        'v': str(e['v']),
      };
    }
  }
  return null;
}


/// لفظ بینک (اسباق سے اکٹھے کیے گئے الفاظ) میں تلاش
Map<String, String>? lookupBankWord(String word) {
  final nw = normalize(word);
  if (nw.isEmpty) return null;
  for (final e in repo.list('wordbank')) {
    if (normalize(str(e['fa'])) == nw) {
      return {'fa': str(e['fa']), 'ur': str(e['ur']), 'gr': str(e['gr'])};
    }
  }
  return null;
}

/// صرف بینک کی گردانوں میں تلاش — صورت ملے تو اس کا مادہ، باب اور معنی
Map<String, Map<String, String>>? _sarfIndex;
Map<String, Map<String, String>> sarfFormIndex() {
  if (_sarfIndex != null) return _sarfIndex!;
  final idx = <String, Map<String, String>>{};
  for (final e in repo.list('sarfbank')) {
    try {
      final res = conjugate(str(e['root']), (e['bab'] as num?)?.toInt() ?? 1,
          str(e['masdar']), str(e['ur']));
      for (final g in res.groups) {
        for (final f in g.forms) {
          final k = normalize(f.form);
          if (k.isNotEmpty && !idx.containsKey(k)) {
            idx[k] = {
              'fa': f.form,
              'ur': f.urdu,
              'gr':
                  'گردان: ${g.name} — مادہ «${str(e['root'])}»، باب نمبر ${e['bab']}، مصدر: ${str(e['masdar'])} (${str(e['ur'])})',
            };
          }
        }
      }
    } catch (_) {}
  }
  _sarfIndex = idx;
  return idx;
}

/// سابقے اتار کر تلاش (ال، وَ، فَ، بِ، لِ، كَ)
Map<String, String>? lookupStripped(String word) {
  var w = normalize(word);
  for (final pre in ['وال', 'فال', 'بال', 'كال', 'لل', 'ال', 'و', 'ف', 'ب', 'ل', 'ك']) {
    if (w.startsWith(pre) && w.length > pre.length + 1) {
      final cand = w.substring(pre.length);
      final hit = lookupFaWord(cand) ?? lookupBankWord(cand);
      if (hit != null) return hit;
    }
  }
  return null;
}

/// فارسی متن جس کا ہر لفظ ٹیپ کیا جا سکتا ہے — ٹیپ پر اردو معنی کھلتا ہے
class WordTapText extends StatelessWidget {
  final String fa;
  final List<dynamic>? words;
  final TextStyle? style;

  /// قرآن سیکشن میں لفظی شیٹ کا عربی اسپیکر چھپاؤ (کمپیوٹر آواز نہیں)
  final bool hideFaSpeaker;

  const WordTapText(
      {super.key,
      required this.fa,
      this.words,
      this.style,
      this.hideFaSpeaker = false});

  /// لفظ کا اردو معنی تلاش کرو: پہلے w فہرست، پھر لغت
  Map<String, String>? _lookup(String word) {
    final nw = normalize(word);
    if (nw.isEmpty) return null;
    // 1. w breakdown
    if (words != null) {
      for (final wd in words!) {
        final m = wd as Map<String, dynamic>;
        if (normalize(str(m['f'])) == nw) {
          return {'fa': str(m['f']), 'ro': str(m['r']), 'ur': str(m['u'])};
        }
      }
    }
    // 2. dictionary
    for (final e in repo.list('dictionary')) {
      if (normalize(str(e['fa'])) == nw) {
        return {
          'fa': str(e['fa']),
          'ro': str(e['ro']),
          'ur': str(e['ur']),
          'v': str(e['v']),
          'gr': str(e['gr']),
          'root': str(e['root']),
        };
      }
    }
    // 3. wordbank (اسباق کے الفاظ)
    final bank = lookupBankWord(word);
    if (bank != null) return bank;
    // 4. صرف بینک کی گردانیں (گرامر کے ساتھ)
    final sf = sarfFormIndex()[nw];
    if (sf != null) return sf;
    // 5. سابقے اتار کر (ال، و، ف...)
    return lookupStripped(word);
  }

  void _onWordTap(BuildContext context, String word) {
    final found = _lookup(word);
    if (found != null) {
      openDetail(
        context,
        fa: found['fa'] ?? word,
        ur: found['ur'] ?? '',
        vocalized: found['v'],
        roman: found['ro'],
        grammar: found['gr'],
        root: found['root'],
        tag: 'لفظ کا معنی و گرامر',
        hideFaSpeaker: hideFaSpeaker,
      );
    } else {
      openDetail(
        context,
        fa: word,
        ur: 'اس لفظ کا معنی ابھی شامل نہیں۔',
        tag: 'لفظ کا معنی و گرامر',
        hideFaSpeaker: hideFaSpeaker,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    // الفاظ کے درمیان خالی جگہ برقرار رکھو (split خالی جگہ کھا جاتا ہے)
    final spans = <TextSpan>[];
    final wordRe = RegExp(r'\S+');
    var last = 0;
    for (final m in wordRe.allMatches(fa)) {
      if (m.start > last) {
        spans.add(TextSpan(text: fa.substring(last, m.start)));
      }
      final part = m.group(0)!;
      // صرف حروف والے ٹکڑے ٹیپ کے قابل ہیں — نمبر، نشانات (—، ✓) سادہ رہیں
      final tappable = RegExp(r'[ء-يa-zA-Z]').hasMatch(part);
      spans.add(
        TextSpan(
          text: part,
          style: tappable
              ? TextStyle(
                  color: cs.primary,
                  decoration: TextDecoration.underline,
                  decorationStyle: TextDecorationStyle.dotted,
                )
              : null,
          recognizer: tappable
              ? (TapGestureRecognizer()
                ..onTap = () => _onWordTap(context, part))
              : null,
        ),
      );
      last = m.end;
    }
    if (last < fa.length) {
      spans.add(TextSpan(text: fa.substring(last)));
    }
    return RichText(
      text: TextSpan(
        style: style ?? faStyle(size: 22),
        children: spans,
      ),
    );
  }
}

/// اردو متن جس کا ہر لفظ ٹیپ کیا جا سکتا ہے — ٹیپ پر اس کا فارسی ترجمہ کھلتا ہے
class UrduTapText extends StatelessWidget {
  final String ur;
  final TextStyle? style;

  /// قرآن سیکشن میں لفظی شیٹ کا عربی اسپیکر چھپاؤ (کمپیوٹر آواز نہیں)
  final bool hideFaSpeaker;

  const UrduTapText(
      {super.key, required this.ur, this.style, this.hideFaSpeaker = false});

  void _onWordTap(BuildContext context, String word) {
    final found = lookupUrWord(word);
    if (found != null) {
      openDetail(
        context,
        fa: found['fa'] ?? word,
        ur: found['ur'] ?? '',
        vocalized: found['v'],
        roman: found['ro'],
        tag: 'عربی ترجمہ',
        hideFaSpeaker: hideFaSpeaker,
      );
    } else {
      openDetail(
        context,
        fa: word,
        ur: 'اس لفظ کا عربی ترجمہ ابھی شامل نہیں۔',
        tag: 'عربی ترجمہ',
        hideFaSpeaker: hideFaSpeaker,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final spans = <TextSpan>[];
    final wordRe = RegExp(r'\S+');
    var last = 0;
    for (final m in wordRe.allMatches(ur)) {
      if (m.start > last) {
        spans.add(TextSpan(text: ur.substring(last, m.start)));
      }
      final part = m.group(0)!;
      final tappable = RegExp(r'[ء-يa-zA-Z]').hasMatch(part);
      spans.add(
        TextSpan(
          text: part,
          style: tappable
              ? TextStyle(
                  color: cs.primary,
                  decoration: TextDecoration.underline,
                  decorationStyle: TextDecorationStyle.dotted,
                )
              : null,
          recognizer: tappable
              ? (TapGestureRecognizer()
                ..onTap = () => _onWordTap(context, part))
              : null,
        ),
      );
      last = m.end;
    }
    if (last < ur.length) {
      spans.add(TextSpan(text: ur.substring(last)));
    }
    return RichText(
      text: TextSpan(
        style: style ?? urStyle(size: 16.5),
        children: spans,
      ),
    );
  }
}

/// عربی لفظ کی مکمل تلاش: لغت، لفظ بینک، صرف بینک گردان، سابقے اتار کر
Map<String, String>? lookupArabicWord(String word) {
  final d = lookupFaWord(word);
  if (d != null) return d;
  final b = lookupBankWord(word);
  if (b != null) return b;
  final sf = sarfFormIndex()[normalize(word)];
  if (sf != null) return sf;
  return lookupStripped(word);
}

/// لفظ ٹیپ ہونے پر تفصیل کھولو (سمت خود پہچانو: عربی لفظ → اردو معنی؛ اردو لفظ → عربی ترجمہ)
void openAnyWord(BuildContext context, String word) {
  final isUrdu = RegExp(r'[ےھٹڈڑں]').hasMatch(word) ||
      !RegExp(r'[ا-ي]').hasMatch(word);
  if (!isUrdu) {
    final f = lookupArabicWord(word);
    if (f != null) {
      openDetail(context,
          fa: f['fa'] ?? word,
          ur: f['ur'] ?? '',
          vocalized: f['v'],
          roman: f['ro'],
          grammar: f['gr'],
          root: f['root'],
          tag: 'لفظ کا معنی و گرامر');
      return;
    }
    openDetail(context,
        fa: word, ur: 'اس لفظ کا معنی ابھی شامل نہیں۔', tag: 'لفظ کا معنی و گرامر');
    return;
  }
  // اردو لفظ: پہلے لغت الٹی تلاش، پھر لفظ بینک الٹی تلاش
  var found = lookupUrWord(word);
  if (found == null) {
    final nw = normalize(word);
    for (final e in repo.list('wordbank')) {
      final parts = normalize(str(e['ur'])).split(RegExp(r'[/،,؛|]'));
      if (parts.any((x) => x.trim() == nw)) {
        found = {'fa': str(e['fa']), 'ur': str(e['ur']), 'gr': str(e['gr'])};
        break;
      }
    }
  }
  if (found != null) {
    openDetail(context,
        fa: found['fa'] ?? word,
        ur: found['ur'] ?? '',
        vocalized: found['v'],
        roman: found['ro'],
        grammar: found['gr'],
        tag: 'عربی ترجمہ');
  } else {
    openDetail(context,
        fa: word, ur: 'اس لفظ کا عربی ترجمہ ابھی شامل نہیں۔', tag: 'عربی ترجمہ');
  }
}

/// مخلوط متن (عربی + اردو ایک ہی بہاؤ میں) — ہر لفظ ٹیپ ایبل، سمت کے مطابق معنی/ترجمہ
class AnyTapText extends StatelessWidget {
  final String text;
  final TextStyle arabicStyle;
  final TextStyle urduStyle;
  const AnyTapText(
      {super.key,
      required this.text,
      required this.arabicStyle,
      required this.urduStyle});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final spans = <TextSpan>[];
    final wordRe = RegExp(r'\S+');
    var last = 0;
    for (final m in wordRe.allMatches(text)) {
      if (m.start > last) {
        spans.add(TextSpan(text: text.substring(last, m.start)));
      }
      final part = m.group(0)!;
      final hasArabic = RegExp(r'[ا-ي]').hasMatch(part);
      final isUrdu = RegExp(r'[ےھٹڈڑں]').hasMatch(part);
      final tappable = RegExp(r'[ء-يa-zA-Z]').hasMatch(part);
      final base = (hasArabic && !isUrdu) ? arabicStyle : urduStyle;
      spans.add(TextSpan(
        text: part,
        style: tappable
            ? base.copyWith(
                color: cs.primary,
                decoration: TextDecoration.underline,
                decorationStyle: TextDecorationStyle.dotted)
            : base,
        recognizer: tappable
            ? (TapGestureRecognizer()..onTap = () => openAnyWord(context, part))
            : null,
      ));
      last = m.end;
    }
    if (last < text.length) {
      spans.add(TextSpan(text: text.substring(last)));
    }
    return RichText(text: TextSpan(style: urduStyle, children: spans));
  }
}
