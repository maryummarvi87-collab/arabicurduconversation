import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../screens/ask_ai_screen.dart';
import '../screens/sarf_screen.dart';
import '../theme.dart';
import 'common.dart';
import 'word_tap_text.dart';

/// کسی لفظ یا جملے کی تفصیل: اعراب، رومن، لفظی معانی
class DetailSheet extends StatelessWidget {
  final String fa;
  final String ur;
  final String? vocalized;
  final String? roman;
  final List<dynamic>? words;
  final String? tag;
  final String? root;
  final String? plural;
  final String? grammar;
  final String? english;
  final String? transitivity;
  final String? pos;

  const DetailSheet({
    super.key,
    required this.fa,
    required this.ur,
    this.vocalized,
    this.roman,
    this.words,
    this.tag,
    this.root,
    this.plural,
    this.grammar,
    this.english,
    this.transitivity,
    this.pos,
  });

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final text = ur.isEmpty ? fa : '$fa\n$ur';
    final faShown =
        (vocalized != null && vocalized!.isNotEmpty) ? vocalized! : fa;
    return SafeArea(
      child: ConstrainedBox(
        constraints: BoxConstraints(
            maxHeight: MediaQuery.of(context).size.height * 0.88),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
            child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 44,
                height: 5,
                margin: const EdgeInsets.only(bottom: 14),
                decoration: BoxDecoration(
                  color: cs.outlineVariant,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            ),
            if (tag != null && tag!.isNotEmpty)
              Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
                decoration: BoxDecoration(
                  color: cs.primary.withAlpha(30),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(tag!,
                    style: TextStyle(
                        fontSize: 13,
                        color: cs.primary,
                        fontWeight: FontWeight.w700)),
              ),
            WordTapText(fa: faShown, words: words, style: faStyle(size: 26)),
            if (vocalized != null &&
                vocalized!.isNotEmpty &&
                vocalized != fa &&
                faShown != vocalized)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  vocalized!,
                  style: faStyle(size: 22, color: AppColors.gold),
                ),
              ),
            if (roman != null && roman!.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  roman!,
                  style: TextStyle(
                      fontSize: 17,
                      color: cs.primary,
                      fontStyle: FontStyle.italic),
                  textDirection: TextDirection.ltr,
                ),
              ),
            if (english != null && english!.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 4),
                child: Text(
                  english!,
                  style: TextStyle(
                      fontSize: 15,
                      color: cs.outline,
                      fontStyle: FontStyle.italic),
                  textDirection: TextDirection.ltr,
                ),
              ),
            if (ur.isNotEmpty)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(ur,
                    style: urStyle(
                        size: 20, color: cs.onSurface.withAlpha(220))),
              ),
            if ((root != null && root!.isNotEmpty) ||
                (plural != null && plural!.isNotEmpty) ||
                (grammar != null && grammar!.isNotEmpty) ||
                (pos != null && pos!.isNotEmpty) ||
                (transitivity != null && transitivity!.isNotEmpty)) ...[
              const SizedBox(height: 12),
              if (pos != null && pos!.isNotEmpty)
                Text('قسمِ کلام: $pos', style: urStyle(size: 15.5)),
              if (transitivity != null && transitivity!.isNotEmpty)
                Text('فعل $transitivity', style: urStyle(size: 15.5)),
              if (root != null && root!.isNotEmpty)
                Text('مادہ: $root', style: faStyle(size: 17)),
              if (plural != null && plural!.isNotEmpty)
                Text('جمع: $plural', style: faStyle(size: 17)),
              if (grammar != null && grammar!.isNotEmpty)
                Text(grammar!, style: urStyle(size: 15.5)),
            ],
            ..._relatives(context),
            ..._moreButtons(context, faShown),
            if (words != null && words!.isNotEmpty) ...[
              const SizedBox(height: 14),
              Text('لفظی معانی',
                  style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: cs.primary)),
              const SizedBox(height: 6),
              ...words!.map((wd) {
                final m = wd as Map<String, dynamic>;
                return InkWell(
                  onTap: () => openDetail(
                    context,
                    fa: str(m['f']),
                    ur: str(m['u']),
                    roman: str(m['r']),
                    grammar: str(m['g']),
                    root: str(m['root']),
                  ),
                  child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Row(
                    children: [
                      Expanded(
                          child: Text(str(m['f']),
                              style: faStyle(size: 18))),
                      Expanded(
                        child: Text(
                          str(m['r']),
                          style: const TextStyle(
                              fontSize: 14, fontStyle: FontStyle.italic),
                          textDirection: TextDirection.ltr,
                        ),
                      ),
                      Expanded(
                          child: Text(str(m['u']),
                              style: urStyle(size: 16),
                              textAlign: TextAlign.end)),
                    ],
                  ),
                  ),
                );
              }),
            ],
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                IconButton(
                  tooltip: 'کاپی',
                  icon: const Icon(Icons.copy_rounded),
                  onPressed: () => copyText(context, text),
                ),
                IconButton(
                  tooltip: 'شیئر',
                  icon: const Icon(Icons.ios_share_rounded),
                  onPressed: () => shareText(text),
                ),
              ],
            ),
            ],
            ),
          ),
        ),
      ),
    );
  }

  /// اسی مادے (root) کے دوسرے الفاظ — لغت سے براہِ راست
  List<Widget> _relatives(BuildContext context) {
    final r = (root ?? '').replaceAll(' ', '');
    if (r.isEmpty) return const [];
    final rel = <Map<String, dynamic>>[];
    for (final e in repo.list('dictionary')) {
      if (str(e['root']).replaceAll(' ', '') != r) continue;
      if (str(e['fa']) == fa && str(e['ur']) == ur) continue;
      rel.add(e);
      if (rel.length >= 12) break;
    }
    if (rel.isEmpty) return const [];
    final cs = Theme.of(context).colorScheme;
    return [
      const SizedBox(height: 14),
      Text('متعلقہ الفاظ — اسی مادے سے',
          style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.bold, color: cs.primary)),
      const SizedBox(height: 6),
      ...rel.map((e) => InkWell(
            onTap: () => openDetail(
              context,
              fa: str(e['fa']),
              ur: str(e['ur']),
              vocalized: str(e['v']),
              roman: str(e['ro']),
              root: str(e['root']),
              plural: str(e['pl']),
              grammar: str(e['gr']),
              english: str(e['en']),
              transitivity: str(e['tr']),
              pos: str(e['pos']),
              tag: 'لغت',
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(
                children: [
                  Expanded(
                      child: Text(
                          str(e['v']).isNotEmpty ? str(e['v']) : str(e['fa']),
                          style: faStyle(size: 18))),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(str(e['ur']),
                        style: urStyle(size: 15.5),
                        textAlign: TextAlign.end,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis),
                  ),
                ],
              ),
            ),
          )),
    ];
  }

  /// مزید جانیں: مترادف، متضاد، واحد/تثنیہ/جمع، مذکر و مؤنث، صرفی تجزیہ،
  /// مثالی جملے — AI سے اسی لفظ کے جواب؛ فعل ہو تو گردان ساز کا بٹن بھی۔
  List<Widget> _moreButtons(BuildContext context, String word) {
    final cs = Theme.of(context).colorScheme;
    final w = word.trim();
    if (w.isEmpty) return const [];
    Widget chip(String label, VoidCallback onTap) => ActionChip(
          label: Text(label, style: const TextStyle(fontSize: 14)),
          backgroundColor: cs.primary.withAlpha(24),
          side: BorderSide(color: cs.primary.withAlpha(70)),
          onPressed: onTap,
        );
    void askAi(int topic) {
      Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => AskAiScreen(initialQuery: w, initialTopic: topic)));
    }

    final isVerb = pos == 'فعل' ||
        (transitivity != null && transitivity!.isNotEmpty) ||
        (root != null && root!.isNotEmpty && pos == null);
    return [
      const SizedBox(height: 14),
      Text('مزید جانیں',
          style: TextStyle(
              fontSize: 16, fontWeight: FontWeight.bold, color: cs.primary)),
      const SizedBox(height: 8),
      Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          chip('مترادفات', () => askAi(3)),
          chip('متضاد', () => askAi(4)),
          chip('مذکر و مؤنث', () => askAi(5)),
          chip('واحد · تثنیہ · جمع', () => askAi(6)),
          chip('صرفی تجزیہ', () => askAi(7)),
          chip('مثالی جملے', () => askAi(9)),
          if (isVerb)
            chip('گردان ساز', () {
              Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const SarfScreen()));
            }),
        ],
      ),
    ];
  }
}

/// تفصیل شیٹ کھولو
void openDetail(
  BuildContext context, {
  required String fa,
  required String ur,
  String? vocalized,
  String? roman,
  List<dynamic>? words,
  String? tag,
  String? root,
  String? plural,
  String? grammar,
  String? english,
  String? transitivity,
  String? pos,
}) {
  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (_) => DetailSheet(
      fa: fa,
      ur: ur,
      vocalized: vocalized,
      roman: roman,
      words: words,
      root: root,
      plural: plural,
      grammar: grammar,
      tag: tag,
      english: english,
      transitivity: transitivity,
      pos: pos,
    ),
  );
}
