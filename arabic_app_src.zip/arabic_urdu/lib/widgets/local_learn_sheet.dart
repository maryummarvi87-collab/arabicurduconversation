import 'package:flutter/material.dart';

import '../data/repository.dart';
import '../screens/ask_ai_screen.dart';
import '../screens/collection_screen.dart';
import '../screens/sarf_screen.dart';
import '../theme.dart';
import '../utils/text_utils.dart';
import 'detail_sheet.dart';
import 'sentence_detail.dart';

/// «مزید جانیں» کے موضوعات: (عنوان، AI موضوع نمبر)
const arLearnCats = <(String, int)>[
  ('مترادفات', 3),
  ('متضاد', 4),
  ('مذکر و مؤنث', 5),
  ('واحد · تثنیہ · جمع', 6),
  ('گرامر', 2),
  ('صرفی تجزیہ', 7),
  ('مثالی جملے', 9),
];

Map<String, dynamic>? _entryFor(String w) {
  final nw = normalize(w);
  for (final key in ['dictionary', 'wordbank']) {
    for (final e in repo.list(key)) {
      if (normalize(str(e['fa'])) == nw || normalize(str(e['v'])) == nw) {
        return e;
      }
    }
  }
  return null;
}

List<Map<String, dynamic>> _relatedByRoot(String root) {
  final nr = normalize(root);
  if (nr.isEmpty) return const [];
  final out = <Map<String, dynamic>>[];
  for (final e in repo.list('dictionary')) {
    if (normalize(str(e['root'])) == nr) {
      out.add(e);
      if (out.length >= 10) break;
    }
  }
  return out;
}

List<Map<String, dynamic>> _sentencesWith(String w) {
  final nw = normalize(w);
  if (nw.length < 2) return const [];
  final out = <Map<String, dynamic>>[];
  for (final s in repo.list('sentences')) {
    if (normalize(str(s['fa'])).contains(nw)) {
      out.add(s);
      if (out.length >= 10) break;
    }
  }
  return out;
}

List<Map<String, dynamic>> _topicsWhere(bool Function(String) test) {
  return repo
      .list('grammar')
      .where((t) => test('${str(t['title'])} ${str(t['body'])}'))
      .toList();
}

/// پہلے ایپ کے اندر موجود مواد سے تفصیل (مادہ، جمع، گرامر نوٹ، صرف و نحو کے
/// اسباق، گردان ساز، ایپ کے جملے)، پھر چاہیں تو نیچے AI کا بٹن۔
void openLocalLearnAr(BuildContext context,
    {required String word, required int cat}) {
  final label = arLearnCats[cat].$1;
  final aiTopic = arLearnCats[cat].$2;
  final entry = _entryFor(word);
  final root = entry == null ? '' : str(entry['root']);
  final nw = normalize(word);

  final sections = <Widget>[];
  void head(String t) {
    sections.add(Padding(
      padding: const EdgeInsets.only(top: 14, bottom: 6),
      child: Text(t,
          style: const TextStyle(fontSize: 15.5, fontWeight: FontWeight.bold)),
    ));
  }

  void note(String t) {
    sections.add(Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Text(t, style: urStyle(size: 15)),
    ));
  }

  void entryRow(Map<String, dynamic> e) {
    sections.add(InkWell(
      onTap: () => openDetail(
        context,
        fa: str(e['fa']),
        ur: str(e['ur']),
        vocalized: str(e['v']),
        roman: str(e['ro']),
        root: str(e['root']),
        plural: str(e['pl']),
        grammar: str(e['gr']),
        english: str(e['en']),
        transitivity: str(e['tr']),
        pos: str(e['pos']),
        tag: 'لغت',
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          children: [
            Expanded(
                child: Text(
                    str(e['v']).isNotEmpty ? str(e['v']) : str(e['fa']),
                    style: faStyle(size: 18))),
            const SizedBox(width: 8),
            Expanded(
                child: Text(str(e['ur']),
                    style: urStyle(size: 15), textAlign: TextAlign.end)),
          ],
        ),
      ),
    ));
  }

  void topicRow(Map<String, dynamic> t) {
    sections.add(InkWell(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => TextDetailScreen(item: t))),
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 5),
        child: Row(
          children: [
            const Icon(Icons.menu_book_rounded, size: 19),
            const SizedBox(width: 8),
            Expanded(
                child: Text(str(t['title']), style: urStyle(size: 15.5))),
            const Icon(Icons.chevron_left_rounded, size: 19),
          ],
        ),
      ),
    ));
  }

  switch (cat) {
    case 0:
    case 1:
      final rel = _relatedByRoot(root);
      if (rel.isNotEmpty) {
        head('اسی مادے کے الفاظ (ایپ کی لغت سے)');
        for (final e in rel) {
          entryRow(e);
        }
      }
      note(cat == 0
          ? 'اس لفظ کے مترادفات لغت میں الگ سے درج نہیں ہیں۔ نیچے AI سے معلوم کیے جا سکتے ہیں۔'
          : 'اس لفظ کے متضاد الفاظ لغت میں الگ سے درج نہیں ہیں۔ نیچے AI سے معلوم کیے جا سکتے ہیں۔');
      break;
    case 2: // مذکر و مؤنث
      final tops = _topicsWhere(
          (s) => s.contains('مؤنث') || s.contains('مذکر') || s.contains('تأنيث'));
      if (entry != null && str(entry['gr']).isNotEmpty) {
        head('لغت کا گرامر نوٹ');
        note(str(entry['gr']));
      }
      if (tops.isNotEmpty) {
        head('صرف و نحو کے متعلقہ اسباق');
        for (final t in tops.take(6)) {
          topicRow(t);
        }
      }
      if (tops.isEmpty && (entry == null || str(entry['gr']).isEmpty)) {
        note('مذکر و مؤنث کے بارے میں ایپ میں الگ مواد نہیں ملا۔ نیچے AI سے وضاحت مل سکتی ہے۔');
      }
      break;
    case 3: // واحد · تثنیہ · جمع
      if (entry != null && str(entry['pl']).isNotEmpty) {
        head('جمع (لغت میں درج)');
        note(str(entry['pl']));
      }
      final tops = _topicsWhere(
          (s) => s.contains('جمع') || s.contains('تثنية') || s.contains('مثنى'));
      if (tops.isNotEmpty) {
        head('صرف و نحو کے متعلقہ اسباق');
        for (final t in tops.take(6)) {
          topicRow(t);
        }
      }
      if ((entry == null || str(entry['pl']).isEmpty) && tops.isEmpty) {
        note('اس لفظ کی جمع ایپ میں درج نہیں ملی۔ نیچے AI سے پوچھی جا سکتی ہے۔');
      }
      break;
    case 4: // گرامر
      final tops = _topicsWhere((s) =>
          normalize(s).contains(nw) ||
          (root.isNotEmpty && normalize(s).contains(normalize(root))));
      if (entry != null && str(entry['gr']).isNotEmpty) {
        head('لغت کا گرامر نوٹ');
        note(str(entry['gr']));
      }
      if (tops.isNotEmpty) {
        head('صرف و نحو کے متعلقہ اسباق (ایپ میں موجود)');
        for (final t in tops.take(8)) {
          topicRow(t);
        }
      } else if (entry == null || str(entry['gr']).isEmpty) {
        note('اس لفظ سے متعلق گرامر مواد ایپ میں نہیں ملا۔ نیچے AI سے وضاحت مل سکتی ہے۔');
      }
      break;
    case 5: // صرفی تجزیہ
      if (entry != null) {
        if (root.isNotEmpty) note('مادہ: $root');
        if (str(entry['pos']).isNotEmpty) {
          note('قسمِ کلام: ${str(entry['pos'])}');
        }
        if (str(entry['tr']).isNotEmpty) {
          note('فعل: ${str(entry['tr'])}');
        }
        if (str(entry['gr']).isNotEmpty) note(str(entry['gr']));
      }
      Map<String, dynamic>? sarf;
      if (root.isNotEmpty) {
        for (final s in repo.list('sarfbank')) {
          if (normalize(str(s['root'])) == normalize(root)) {
            sarf = s;
            break;
          }
        }
      }
      if (sarf != null) {
        head('گردان ساز میں موجود مصدر');
        note('${str(sarf['masdar'])} — ${str(sarf['ur'])} (باب ${sarf['bab']}، ${str(sarf['type'])}، ${str(sarf['tr'])})');
        sections.add(Padding(
          padding: const EdgeInsets.only(top: 6),
          child: OutlinedButton.icon(
            onPressed: () => Navigator.of(context)
                .push(MaterialPageRoute(builder: (_) => const SarfScreen())),
            icon: const Icon(Icons.construction_rounded, size: 18),
            label: const Text('گردان ساز کھولیں'),
          ),
        ));
      }
      if (entry == null && sarf == null) {
        note('اس لفظ کی صرفی تفصیل ایپ میں نہیں ملی۔ نیچے AI سے تجزیہ مل سکتا ہے۔');
      }
      break;
    case 6: // مثالی جملے
      final sents = _sentencesWith(word);
      if (sents.isNotEmpty) {
        head('ایپ کے جملوں سے مثالیں');
        for (final s in sents) {
          sections.add(InkWell(
            onTap: () => openSentenceDetail(context,
                fa: str(s['fa']), roman: str(s['ro']), ur: str(s['ur'])),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(str(s['v']).isNotEmpty ? str(s['v']) : str(s['fa']),
                      style: faStyle(size: 17)),
                  Text(str(s['ur']), style: urStyle(size: 14.5)),
                ],
              ),
            ),
          ));
        }
      } else {
        note('ایپ کے جملوں میں اس لفظ کی مثال نہیں ملی۔ نیچے AI سے مثالی جملے بنوائے جا سکتے ہیں۔');
      }
      break;
  }

  showModalBottomSheet(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(
      borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
    ),
    builder: (ctx) {
      final cs = Theme.of(ctx).colorScheme;
      return SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 44,
                  height: 5,
                  margin: const EdgeInsets.only(bottom: 14),
                  decoration: BoxDecoration(
                    color: cs.outlineVariant,
                    borderRadius: BorderRadius.circular(3),
                  ),
                ),
              ),
              Text('$label — $word',
                  style: TextStyle(
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                      color: cs.primary)),
              ...sections,
              const SizedBox(height: 18),
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: () => Navigator.of(ctx).push(MaterialPageRoute(
                      builder: (_) => AskAiScreen(
                          initialQuery: word, initialTopic: aiTopic))),
                  icon: const Icon(Icons.auto_awesome_rounded, size: 18),
                  label: const Text('AI سے مزید تفصیل'),
                ),
              ),
            ],
          ),
        ),
      );
    },
  );
}
