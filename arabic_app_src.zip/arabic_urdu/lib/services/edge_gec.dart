/// Microsoft Edge Read-Aloud (edge-tts) کے لیے Sec-MS-GEC v2 ٹوکن کی تیاری۔
/// یہ edge-tts (Python) کے drm.py کی عین مطابق Dart نقل ہے — ٹوکن غلط ہو تو
/// سرور 403 دیتا ہے، اس لیے تمام حساب کتاب بٹ در بٹ ویسی ہی رکھی گئی ہے۔
/// ٹوکن: "<CS64 hex>-<custom SHA-256 hex>" — وقت کو 300 سیکنڈ پر گول کر کے۔
library;

const String _trustedClientToken = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
const int _winEpoch = 11644473600;
const int _mask = 0xFFFFFFFF;

const List<int> _sha256Initial = [
  0x6A09E667, 0xBB67AE85, 0x3C6EF372, 0xA54FF53A,
  0x510E527F, 0x9B05688C, 0x1F83D9AB, 0x5BE0CD19,
];
const List<int> _sha256State = [
  0xFD9FBEA2, 0x91243CE7, 0xBE499094, 0xCD2E1E0A,
  0x6C006F49, 0x04BD35AB, 0xFEB0A7E4, 0x03EFFBD2,
];
const List<int> _sha256Schedule = [
  0xEB24BF9E, 0x1558691F, 0xA0C09EE2, 0x0CFA32BA,
  0xA622EE8C, 0xD1DD9491, 0xC0DD25A0, 0xF9E70AB6,
  0xF0C31573, 0x7058CE4E, 0x7188E606, 0x00E5AB33,
  0xD258B060, 0x72766564,
];
const List<int> _sha256RoundConstants = [
  0x428A2F98, 0x71374491, 0xB5C0FBCF, 0xE9B5DBA5,
  0x3956C25B, 0x59F111F1, 0x923F82A4, 0xAB1C5ED5,
  0xD807AA98, 0x12835B01, 0x243185BE, 0x550C7DC3,
  0x72BE5D74, 0x80DEB1FE, 0x9BDC06A7, 0xC19BF174,
  0xE49B69C1, 0xEFBE4786, 0x0FC19DC6, 0x240CA1CC,
  0x2DE92C6F, 0x4A7484AA, 0x5CB0A9DC, 0x76F988DA,
  0x983E5152, 0xA831C66D, 0xB00327C8, 0xBF597FC7,
  0xC6E00BF3, 0xD5A79147, 0x06CA6351, 0x14292967,
  0x27B70A85, 0x2E1B2138, 0x4D2C6DFC, 0x53380D13,
  0x650A7354, 0x766A0ABB, 0x81C2C92E, 0x92722C85,
  0xA2BFE8A1, 0xA81A664B, 0xC24B8B70, 0xC76C51A3,
  0xD192E819, 0xD6990624, 0xF40E3585, 0x106AA070,
  0x19A4C116, 0x1E376C08, 0x2748774C, 0x34B0BCB5,
  0x391C0CB3, 0x4ED8AA4A, 0x5B9CCA4F, 0x682E6FF3,
  0x748F82EE, 0x78A5636F, 0x84C87814, 0x8CC70208,
  0x90BEFFFA, 0xA4506CEB, 0xBEF9A3F7, 0xC67178F2,
];
const int _sha256Adjustment = 0xC9DC06A7;
const int _sha256Sigma0Adjustment = 0x059C0B80;
const int _sha256Sigma1Adjustment = 0x000B92C0;

List<int> get _sha256BlockConstants => [
      ..._sha256RoundConstants.sublist(0, 14),
      _sha256Adjustment,
      ..._sha256RoundConstants.sublist(15),
    ];

const List<(int, int)> _cs64Coefficients = [
  (0xE82E91B1, 0xB32700D0),
  (0x44DE24C6, 0x88DFF51D),
  (0x3BEB65BC, 0x29514038),
  (0xC89C5933, 0xB328CBDF),
  (0x8D1EC211, 0xD405B4D5),
  (0x314EF5D5, 0x26E55F3C),
  (0xE92491B1, 0x607801C6),
  (0xF0A5B9D5, 0x82B2C1FB),
  (0x06064CF3, 0xFA51A3DA),
  (0xDA79FA60, 0x207CC464),
  (0xBED20560, 0x3C3C74F3),
  (0x89F9C9F8, 0xD2D14B61),
  (0x35FA38C6, 0xBB04A2C1),
  (0xCB49E3C6, 0xC5626167),
];
const int _cs64Factor = 0x82893933;
const int _cs64Adjustment0 = 0xF2F90B1A;
const int _cs64Adjustment1 = 0x0B1A0000;

int _rol16(int value) {
  value &= _mask;
  return ((value << 16) | (value >> 16)) & _mask;
}

int _sigma0(int value) =>
    ((value >> 7) ^ (value << 25) ^ (value >> 18) ^ (value << 14) ^ (value >> 3)) & _mask;

int _sigma1(int value) =>
    ((value >> 17) ^ (value << 15) ^ (value >> 19) ^ (value << 13) ^ (value >> 10)) & _mask;

/// بڑا سگما صفر (Σ0) — گھماؤ کا کم 32 بٹ حصہ ہی مؤثر ہے۔
int _bigSigma0(int value) =>
    (((value * 0x100000001) >> 2) ^ ((value * 0x100000001) >> 13) ^ ((value * 0x100000001) >> 22));

int _bigSigma1(int value) =>
    (((value * 0x100000001) >> 6) ^ ((value * 0x100000001) >> 11) ^ ((value * 0x100000001) >> 25));

List<int> _sha256Rounds(List<int> state, List<int> words, [int firstRound = 0]) {
  var a = state[0], b = state[1], c = state[2], d = state[3];
  var e = state[4], f = state[5], g = state[6], h = state[7];
  final constants = firstRound == 14 ? _sha256BlockConstants : _sha256RoundConstants;
  final aligned = firstRound + 7 < 64 ? ((firstRound + 7) ~/ 8) * 8 : 64;
  final limit = aligned > 64 ? 64 : aligned;
  for (var index = firstRound; index < limit; index++) {
    final t1 = h +
        _bigSigma1(e) +
        (g ^ (e & (f ^ g))) +
        constants[index] +
        words[index];
    final t2 = _bigSigma0(a) + ((a & b) | (c & (a | b)));
    final na = (t1 + t2) & _mask;
    final ne = (d + t1) & _mask;
    h = g; g = f; f = e; e = ne; d = c; c = b; b = a; a = na;
  }
  for (var index = limit; index < 64; index += 8) {
    var t1 = h + _bigSigma1(e) + (g ^ (e & (f ^ g))) + constants[index] + words[index];
    d = (d + t1) & _mask;
    h = (t1 + _bigSigma0(a) + ((a & b) | (c & (a | b)))) & _mask;
    t1 = g + _bigSigma1(d) + (f ^ (d & (e ^ f))) + constants[index + 1] + words[index + 1];
    c = (c + t1) & _mask;
    g = (t1 + _bigSigma0(h) + ((h & a) | (b & (h | a)))) & _mask;
    t1 = f + _bigSigma1(c) + (e ^ (c & (d ^ e))) + constants[index + 2] + words[index + 2];
    b = (b + t1) & _mask;
    f = (t1 + _bigSigma0(g) + ((g & h) | (a & (g | h)))) & _mask;
    t1 = e + _bigSigma1(b) + (d ^ (b & (c ^ d))) + constants[index + 3] + words[index + 3];
    a = (a + t1) & _mask;
    e = (t1 + _bigSigma0(f) + ((f & g) | (h & (f | g)))) & _mask;
    t1 = d + _bigSigma1(a) + (c ^ (a & (b ^ c))) + constants[index + 4] + words[index + 4];
    h = (h + t1) & _mask;
    d = (t1 + _bigSigma0(e) + ((e & f) | (g & (e | f)))) & _mask;
    t1 = c + _bigSigma1(h) + (b ^ (h & (a ^ b))) + constants[index + 5] + words[index + 5];
    g = (g + t1) & _mask;
    c = (t1 + _bigSigma0(d) + ((d & e) | (f & (d | e)))) & _mask;
    t1 = b + _bigSigma1(g) + (a ^ (g & (h ^ a))) + constants[index + 6] + words[index + 6];
    f = (f + t1) & _mask;
    b = (t1 + _bigSigma0(c) + ((c & d) | (e & (c | d)))) & _mask;
    t1 = a + _bigSigma1(f) + (h ^ (f & (g ^ h))) + constants[index + 7] + words[index + 7];
    e = (e + t1) & _mask;
    a = (t1 + _bigSigma0(b) + ((b & c) | (d & (b | c)))) & _mask;
  }
  return [a, b, c, d, e, f, g, h];
}

void _expandSchedule(List<int> words, [int firstWord = 16]) {
  for (var index = firstWord; index < 64; index++) {
    final x = words[index - 2];
    final y = words[index - 15];
    final sigma1 = (x >> 17) ^ (x << 15) ^ (x >> 19) ^ (x << 13) ^ (x >> 10);
    final sigma0 = (y >> 7) ^ (y << 25) ^ (y >> 18) ^ (y << 14) ^ (y >> 3);
    words.add((sigma1 + words[index - 7] + sigma0 + words[index - 16]) & _mask);
  }
}

int _be32(List<int> bytes, int offset) =>
    (bytes[offset] << 24) | (bytes[offset + 1] << 16) | (bytes[offset + 2] << 8) | bytes[offset + 3];

int _le32(List<int> bytes, int offset) =>
    bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24);

List<int> _sha256Init(List<int> data) {
  final words = <int>[
    ...List.filled(14, 0),
    (data[0] << 16) | (data[1] << 8) | data[2],
    _be32(data, 3),
  ];
  for (var index = 16; index < 30; index++) {
    var value = _sha256Schedule[index - 16];
    if (index - 2 >= 14) {
      value += index == 16
          ? (_sigma1(words[index - 2]) ^ _sha256Sigma1Adjustment)
          : _sigma1(words[index - 2]);
    }
    if (index - 7 >= 14) {
      value += words[index - 7];
    }
    if (index - 15 >= 14) {
      value += index == 29
          ? (_sigma0(words[index - 15]) ^ _sha256Sigma0Adjustment)
          : _sigma0(words[index - 15]);
    }
    words.add(value & _mask);
  }
  words.add((_sigma1(words[28]) +
          words[23] +
          _sigma0(words[15]) +
          words[14] +
          _sha256Adjustment -
          _sha256RoundConstants[14]) &
      _mask);
  _expandSchedule(words, 31);
  final working = _sha256Rounds(_sha256State, words, 14);
  return List.generate(8, (i) => (_sha256Initial[i] + working[i]) & _mask);
}

List<int> _customSha256(List<int> data) {
  final length = 57 + data.length;
  final padded = <int>[
    ...data.sublist(7),
    0x80,
    ...List.filled((55 - length) % 64, 0),
  ];
  final bitLength = length * 8;
  for (var i = 7; i >= 0; i--) {
    padded.add((bitLength >> (i * 8)) & 0xFF);
  }
  var state = _sha256Init(data.sublist(0, 7));
  for (var offset = 0; offset < padded.length; offset += 64) {
    final words = List.generate(16, (i) => _be32(padded, offset + i * 4));
    _expandSchedule(words);
    final working = _sha256Rounds(state, words);
    state = List.generate(8, (i) => (state[i] + working[i]) & _mask);
  }
  final out = <int>[];
  for (final w in state) {
    out.addAll([(w >> 24) & 0xFF, (w >> 16) & 0xFF, (w >> 8) & 0xFF, w & 0xFF]);
  }
  return out;
}

List<int> _wordsLe4Even(List<int> data) {
  final padded = [...data, ...List.filled((-data.length) % 4, 0)];
  final words = <int>[];
  for (var i = 0; i < padded.length; i += 4) {
    words.add(_le32(padded, i));
  }
  if (words.length % 2 == 1) words.add(0);
  return words;
}

(int, int) _cs64Digest(List<int> data, List<int> digest) {
  final keyA = _le32(digest, 0) | 1;
  final keyB = _le32(digest, 4) | 1;
  final factors = [
    (keyA * _cs64Factor) & _mask,
    (keyB * _cs64Factor) & _mask,
  ];
  final terms = <int>[
    for (var i = 0; i < _cs64Coefficients.length; i++)
      (_cs64Coefficients[i].$1 * factors[i % 2]) & _mask,
  ];
  final offsets = <int>[for (final c in _cs64Coefficients) c.$2];
  final dataWords = _wordsLe4Even([0, ...data]);
  for (var index = 0; index < dataWords.length; index++) {
    final word = dataWords[index];
    var term = word * (index % 2 == 0 ? keyA : keyB);
    var offset = _rol16(word) * (index % 2 == 0 ? 0xEF0569FB : 0xC31713DB);
    if (index == 0) {
      term += _cs64Adjustment0 * factors[0];
      offset += _cs64Adjustment1;
    }
    terms.add(term & _mask);
    offsets.add(offset & _mask);
  }
  var swapAcc = 0, swapLast = 0, state = 0, acc = 0;
  for (var index = 0; index < terms.length; index += 2) {
    final x = terms[index];
    final y = terms[index + 1];
    var t = _rol16((offsets[index] + x) & _mask);
    var q = (t * 0x76F50F34) & _mask;
    swapAcc += (_rol16(q) * 0xC3EFEA97 + q) & _mask;
    t = _rol16((offsets[index + 1] + y) & _mask);
    q = (t * 0x1881CE3C) & _mask;
    swapLast = (_rol16(q) * 0x35BD1EC9 + q) & _mask;
    swapAcc = (swapAcc + swapLast) & _mask;
    state = (state * keyA + x) & _mask;
    state = (_rol16(state) * 0xCF98B111) & _mask;
    state = (_rol16(state) * 0x87085B9F) & _mask;
    state = (_rol16(state) * 0x12CEB96D) & _mask;
    state = (_rol16(state) * 0x257E1D83) & _mask;
    acc += state;
    t = (state * keyB + y) & _mask;
    t = (_rol16(t) * 0xA27416F5) & _mask;
    t = (_rol16(t) * 0xD38396FF) & _mask;
    state = (_rol16((_rol16(t) * 0x7C932B89) & _mask) * 0xBFA49F69) & _mask;
    acc = (acc + state) & _mask;
  }
  return (swapLast ^ state, swapAcc ^ acc);
}

String _hexUpper(List<int> bytes) =>
    bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join().toUpperCase();

List<int> _leBytes(int w) => [w & 0xFF, (w >> 8) & 0xFF, (w >> 16) & 0xFF, (w >> 24) & 0xFF];

/// موجودہ وقت (یا دیے گئے یونکس ٹائم اسٹیمپ) کے لیے Sec-MS-GEC v2 ٹوکن۔
String generateSecMsGec([int? unixSeconds, int skewSeconds = 0]) {
  var ticks = (unixSeconds ?? DateTime.now().millisecondsSinceEpoch ~/ 1000) +
      skewSeconds +
      _winEpoch;
  ticks -= ticks % 300;
  ticks *= 10000000;
  final data = '$ticks$_trustedClientToken'.codeUnits;
  final digest = _customSha256(data);
  final (csA, csB) = _cs64Digest(data, digest);
  final cs64 = _hexUpper([..._leBytes(csA), ..._leBytes(csB)]);
  return '$cs64-${_hexUpper(digest)}';
}
