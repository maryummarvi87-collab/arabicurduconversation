/// آن لائن قدرتی آواز (Microsoft Edge نیورل TTS) + قرآن کی تلاوت (CDN اسٹریمنگ)۔
///
/// شرائط (Ayesh، 24 نومبر 2026): آواز قدرتی (نیورل) ہو، آن لائن ہو،
/// ایپ کا سائز نہ بڑھے — کوئی آڈیو فائل APK میں شامل نہیں۔
/// **کیش آن پلے (Ayesh کا انتخاب):** جو لفظ/جملہ/آیت ایک بار سنی جائے اس
/// کی آواز ایپ کے **کیش فولڈر** (getTemporaryDirectory — Android کا
/// عارضی کیش، دستاویزات/اسٹوریج نہیں) میں محفوظ ہو جاتی ہے تاکہ اگلی بار
/// وہی چیز آف لائن بھی چل سکے۔ ترتیبات میں سائز کی نمائش اور «محفوظ
/// آوازیں صاف کریں» کا بٹن موجود ہے۔
///
/// نوٹ: dart:io کے تیار WebSocket سے اس سروس کا ہینڈ شیک 403 دیتا ہے،
/// اس لیے یہاں چھوٹا سا اپنا WebSocket کلائنٹ (SecureSocket پر) شامل ہے
/// جو edge-tts کے عین مطابق ہیڈرز بھیجتا ہے۔
library;

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import '../state.dart';
import 'edge_gec.dart';

// ---------------- ایپ کے لحاظ سے آوازیں ----------------
/// اس ایپ کی بنیادی زبان ('fa' فارسی ایپ میں، 'ar' عربی ایپ میں)۔
const String _appLang = 'ar';

/// زبان + صارف کی جنس پسند کے حساب سے نیورل آواز۔
/// انگریزی آواز بھی شامل ہے: ایپ میں انگریزی معانی/تراجم موجود ہیں
/// اور آئندہ اسباق انگریزی سمیت آئیں گے (Ayesh، 24 نومبر 2026)۔
String _voiceFor(String lang) {
  final male = settings.maleVoice;
  switch (lang) {
    case 'en':
      return male ? 'en-US-GuyNeural' : 'en-US-AriaNeural';
    case 'ar':
      return male ? 'ar-SA-HamedNeural' : 'ar-SA-ZariyahNeural';
    case 'ur':
      return male ? 'ur-PK-AsadNeural' : 'ur-PK-UzmaNeural';
    case 'fa':
    default:
      return male ? 'fa-IR-FaridNeural' : 'fa-IR-DilaraNeural';
  }
}

String _xmlLang(String lang) => lang == 'en'
    ? 'en-US'
    : (lang == 'ar' ? 'ar-SA' : (lang == 'ur' ? 'ur-PK' : 'fa-IR'));

const String _token = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
const String _gecVersion = '2-143.0.3650.75';
const String _userAgent =
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
    '(KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0';
const String _ttsHost = 'speech.platform.bing.com';

/// مشترکہ ایک ہی پلیئر — TTS اور تلاوت ایک دوسرے کو روکتے ہیں۔
final AudioPlayer _player = AudioPlayer();

String _uuidHex() {
  final r = Random.secure();
  final b = List.generate(16, (_) => r.nextInt(256));
  return b.map((x) => x.toRadixString(16).padLeft(2, '0')).join();
}

String _dateString() {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const months = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  final n = DateTime.now().toUtc();
  String two(int v) => v.toString().padLeft(2, '0');
  return '${days[n.weekday - 1]} ${months[n.month - 1]} ${two(n.day)} ${n.year} '
      '${two(n.hour)}:${two(n.minute)}:${two(n.second)} GMT+0000 (Coordinated Universal Time)';
}

String _escapeXml(String s) => s
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;');

/// متن کو جملوں کی حد پر چھوٹے ٹکڑوں میں توڑو (ہر ٹکڑا علیحدہ درخواست)۔
List<String> splitForSpeech(String text, [int maxLen = 240]) {
  final t = text.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (t.isEmpty) return const [];
  final sentences = <String>[];
  final buf = StringBuffer();
  for (var i = 0; i < t.length; i++) {
    buf.write(t[i]);
    if ('.!?؟۔…'.contains(t[i]) ||
        (t[i] == '؛' && buf.length > 60) ||
        (t[i] == '،' && buf.length > 140)) {
      sentences.add(buf.toString());
      buf.clear();
    }
  }
  if (buf.isNotEmpty) sentences.add(buf.toString());
  final chunks = <String>[];
  var cur = '';
  void push(String s) {
    final v = s.trim();
    if (v.isNotEmpty) chunks.add(v);
  }

  for (final s in sentences) {
    if (s.length > maxLen) {
      if (cur.isNotEmpty) {
        push(cur);
        cur = '';
      }
      var rest = s.trim();
      while (rest.length > maxLen) {
        var cut = rest.lastIndexOf(' ', maxLen);
        if (cut < 40) cut = maxLen;
        push(rest.substring(0, cut));
        rest = rest.substring(cut).trim();
      }
      cur = rest;
    } else if (cur.length + s.length <= maxLen) {
      cur += s;
    } else {
      push(cur);
      cur = s;
    }
  }
  if (cur.isNotEmpty) push(cur);
  return chunks;
}

// ---------------- کیش آن پلے (ایپ کا عارضی کیش فولڈر) ----------------
/// FNV-1a 64-bit ہیش — کیش فائل کے نام کے لیے۔
String _hashKey(String s) {
  var h = 0xcbf29ce484222325;
  for (final byte in utf8.encode(s)) {
    h ^= byte;
    h = (h * 0x100000001b3) & 0xFFFFFFFFFFFFFFFF;
  }
  return '${s.length}_${h.toUnsigned(64).toRadixString(16)}';
}

Directory? _cacheDirMemo;

Future<Directory> _audioCacheDir() async {
  // ہر ٹکڑے پر پلیٹ فارم کال کی دیر ختم کرنے کے لیے راستہ ایک بار یاد رکھو۔
  final memo = _cacheDirMemo;
  if (memo != null) return memo;
  final tmp = await getTemporaryDirectory();
  final dir = Directory('${tmp.path}/audio_cache');
  if (!await dir.exists()) await dir.create(recursive: true);
  _cacheDirMemo = dir;
  return dir;
}

/// کیش چابی: آواز کا نام + رفتار + متن (رفتار بدلنے سے نئی آواز بنتی ہے)۔
Future<File> _ttsCacheFile(String voice, String rate, String chunk) async {
  final dir = await _audioCacheDir();
  return File('${dir.path}/tts_${_hashKey('$voice|$rate|$chunk')}.mp3');
}

Future<File> _ayahCacheFile(int globalAyah) async {
  final dir = await _audioCacheDir();
  return File('${dir.path}/ayah_$globalAyah.mp3');
}

/// محفوظ آوازوں کا کل سائز (بائٹس) — ترتیبات میں دکھانے کے لیے۔
Future<int> audioCacheSizeBytes() async {
  try {
    final dir = await _audioCacheDir();
    var total = 0;
    await for (final e in dir.list()) {
      if (e is File) total += await e.length();
    }
    return total;
  } catch (_) {
    return 0;
  }
}

/// تمام محفوظ آوازیں حذف کر دیں۔
Future<void> clearAudioCache() async {
  try {
    final tmp = await getTemporaryDirectory();
    final dir = Directory('${tmp.path}/audio_cache');
    if (await dir.exists()) await dir.delete(recursive: true);
  } catch (_) {}
}

// ---------------- چھوٹا WebSocket کلائنٹ (SecureSocket پر) ----------------
class _EdgeWs {
  final SecureSocket _socket;
  final StreamController<dynamic> _messages =
      StreamController<dynamic>.broadcast();
  final BytesBuilder _buffer = BytesBuilder(copy: false);
  final Completer<void> _hsCompleter = Completer<void>();
  bool _handshakeDone = false;
  bool _closed = false;

  /// کنکشن بند ہو چکا ہو تو true — مشترکہ کنکشن دوبارہ استعمال کی جانچ کے لیے۔
  bool get isClosed => _closed;
  int _fragOpcode = -1;
  final BytesBuilder _fragData = BytesBuilder(copy: false);

  _EdgeWs._(this._socket) {
    _socket.listen(_onData, onError: (Object e) {
      _closed = true;
      if (!_hsCompleter.isCompleted) _hsCompleter.completeError(e);
      if (!_messages.isClosed) _messages.addError(e);
    }, onDone: () {
      _closed = true;
      if (!_hsCompleter.isCompleted) {
        _hsCompleter.completeError(StateError('connection closed'));
      }
      if (!_messages.isClosed) _messages.close();
    });
  }

  Stream<dynamic> get messages => _messages.stream;

  static Future<_EdgeWs> connect(String path) async {
    final secure = await SecureSocket.connect(_ttsHost, 443)
        .timeout(const Duration(seconds: 20));
    final ws = _EdgeWs._(secure);
    final key =
        base64Encode(List.generate(16, (_) => Random.secure().nextInt(256)));
    final sb = StringBuffer()
      ..write('GET $path HTTP/1.1\r\n')
      ..write('Host: $_ttsHost\r\n')
      ..write('Upgrade: websocket\r\n')
      ..write('Connection: Upgrade\r\n')
      ..write('Sec-WebSocket-Key: $key\r\n')
      ..write('Sec-WebSocket-Version: 13\r\n')
      ..write('Origin: chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold\r\n')
      ..write('User-Agent: $_userAgent\r\n')
      ..write('Pragma: no-cache\r\n')
      ..write('Cache-Control: no-cache\r\n')
      ..write('Cookie: muid=${_uuidHex().toUpperCase()};\r\n')
      ..write('\r\n');
    secure.write(sb.toString());
    await ws._hsCompleter.future.timeout(const Duration(seconds: 20));
    return ws;
  }

  void _onData(Uint8List data) {
    _buffer.add(data);
    if (!_handshakeDone) {
      final bytes = _buffer.toBytes();
      final s = latin1.decode(bytes, allowInvalid: true);
      final idx = s.indexOf('\r\n\r\n');
      if (idx < 0) return;
      final head = s.substring(0, idx);
      if (!head.startsWith('HTTP/1.1 101')) {
        _hsCompleter.completeError(
            StateError('upgrade rejected: ${head.split('\r\n').first}'));
        return;
      }
      _handshakeDone = true;
      _hsCompleter.complete();
      final rest = bytes.sublist(idx + 4);
      _buffer.clear();
      if (rest.isNotEmpty) _buffer.add(rest);
      if (rest.isEmpty) return;
    }
    _parseFrames();
  }

  void _parseFrames() {
    while (true) {
      final bytes = _buffer.toBytes();
      if (bytes.length < 2) return;
      final fin = (bytes[0] & 0x80) != 0;
      final opcode = bytes[0] & 0x0F;
      final masked = (bytes[1] & 0x80) != 0;
      var len = bytes[1] & 0x7F;
      var offset = 2;
      if (len == 126) {
        if (bytes.length < 4) return;
        len = (bytes[2] << 8) | bytes[3];
        offset = 4;
      } else if (len == 127) {
        if (bytes.length < 10) return;
        len = 0;
        for (var i = 0; i < 8; i++) {
          len = (len << 8) | bytes[2 + i];
        }
        offset = 10;
      }
      var maskKey = const <int>[];
      if (masked) {
        if (bytes.length < offset + 4) return;
        maskKey = bytes.sublist(offset, offset + 4);
        offset += 4;
      }
      if (bytes.length < offset + len) return;
      var payload = bytes.sublist(offset, offset + len);
      if (masked) {
        payload = Uint8List.fromList(
            List.generate(payload.length, (i) => payload[i] ^ maskKey[i % 4]));
      }
      final remaining = bytes.sublist(offset + len);
      _buffer.clear();
      if (remaining.isNotEmpty) _buffer.add(remaining);
      _handleFrame(fin, opcode, payload);
    }
  }

  void _handleFrame(bool fin, int opcode, Uint8List payload) {
    if (opcode == 0x9) {
      _sendFrame(0xA, payload);
      return;
    }
    if (opcode == 0x8) {
      _closed = true;
      if (!_messages.isClosed) _messages.close();
      return;
    }
    if (opcode == 0xA) return;
    if (opcode == 0x0) {
      _fragData.add(payload);
      if (fin) {
        final full = _fragData.takeBytes();
        _emit(_fragOpcode, full);
        _fragOpcode = -1;
      }
      return;
    }
    if (!fin) {
      _fragOpcode = opcode;
      _fragData.add(payload);
      return;
    }
    _emit(opcode, payload);
  }

  void _emit(int opcode, Uint8List payload) {
    if (_messages.isClosed) return;
    if (opcode == 1) {
      _messages.add(utf8.decode(payload, allowMalformed: true));
    } else if (opcode == 2) {
      _messages.add(payload);
    }
  }

  void sendText(String text) => _sendFrame(0x1, utf8.encode(text));

  void _sendFrame(int opcode, List<int> payload) {
    final mask = List.generate(4, (_) => Random.secure().nextInt(256));
    final header = BytesBuilder(copy: false);
    header.addByte(0x80 | opcode);
    final len = payload.length;
    if (len < 126) {
      header.addByte(0x80 | len);
    } else if (len < 65536) {
      header.addByte(0x80 | 126);
      header.addByte((len >> 8) & 0xFF);
      header.addByte(len & 0xFF);
    } else {
      header.addByte(0x80 | 127);
      for (var i = 7; i >= 0; i--) {
        header.addByte((len >> (i * 8)) & 0xFF);
      }
    }
    header.add(mask);
    final masked = List.generate(len, (i) => payload[i] ^ mask[i % 4]);
    try {
      _socket.add([...header.toBytes(), ...masked]);
    } catch (_) {}
  }

  /// خراب کنکشن: دوبارہ استعمال کے قابل نہیں — بند بھی کر دو۔
  void markBroken() {
    _closed = true;
    try {
      _socket.destroy();
    } catch (_) {}
    if (!_messages.isClosed) _messages.close();
  }

  Future<void> close() async {
    _closed = true;
    try {
      _sendFrame(0x8, const []);
    } catch (_) {}
    try {
      await _socket.close();
    } catch (_) {}
    try {
      _socket.destroy();
    } catch (_) {}
  }
}

// ---------------- Edge نیورل TTS ----------------
class TtsService {
  TtsService._();
  static final TtsService instance = TtsService._();

  /// اس وقت جو متن بولا جا رہا ہے اس کی شناخت (بٹن کی حالت کے لیے)۔
  final ValueNotifier<String?> speakingId = ValueNotifier<String?>(null);
  int _session = 0;
  int _skewSeconds = 0;
  bool _skewTried = false;

  // ---- رفتار کی اصلاح: کنکشن دوبارہ استعمال + GEC کیش + ترتیب ----
  // پہلے ہر ٹکڑے کے لیے نیا SecureSocket (DNS+TCP+TLS) اور WebSocket
  // اپ گریڈ کھلتا تھا — یہی «بعض اوقات آواز دیر سے آتی ہے» کی بڑی وجہ تھی۔
  // اب ایک کنکشن زندہ رکھا جاتا ہے اور تمام درخواستیں اسی پر جاتی ہیں۔
  _EdgeWs? _ws;
  Future<_EdgeWs>? _wsOpening;
  Timer? _wsIdleTimer;
  String? _gecCache;
  int _gecCacheSkew = 0;
  DateTime? _gecCacheUntil;
  Future<void> _synthLock = Future<void>.value();

  /// Sec-MS-GEC ٹوکن 300 سیکنڈ کی ونڈو کے لیے کارآمد ہوتا ہے — ونڈو کے
  /// اندر کیش شدہ ٹوکن ہی دوبارہ دو (ہر ٹیپ پر از سر نو حساب نہیں)۔
  String _gec() {
    final now = DateTime.now();
    if (_gecCache != null &&
        _gecCacheSkew == _skewSeconds &&
        _gecCacheUntil != null &&
        now.isBefore(_gecCacheUntil!)) {
      return _gecCache!;
    }
    final token = generateSecMsGec(null, _skewSeconds);
    // ونڈو کی سرحد (یونکس+فرق) کے 300 کے ضرب پر آتی ہے؛ آخری 5 سیکنڈ
    // میں نیا ٹوکن بنے تاکہ سرحد پار کرتے ہی 403 نہ آئے۔
    final secs = now.millisecondsSinceEpoch ~/ 1000 + _skewSeconds;
    final remain = 300 - (secs % 300);
    _gecCache = token;
    _gecCacheSkew = _skewSeconds;
    _gecCacheUntil =
        now.add(Duration(seconds: remain > 5 ? remain - 5 : remain));
    return token;
  }

  /// زندہ مشترکہ کنکشن لو — نہ ہو یا بند ہو چکا ہو تو نیا کھولو۔
  Future<_EdgeWs> _connection() {
    final live = _ws;
    if (live != null && !live.isClosed) {
      _armIdleClose();
      return Future<_EdgeWs>.value(live);
    }
    final opening = _wsOpening;
    if (opening != null) return opening;
    final fut = _openConnection();
    _wsOpening = fut;
    return fut;
  }

  Future<_EdgeWs> _openConnection() async {
    try {
      final path = '/consumer/speech/synthesize/readaloud/edge/v1'
          '?TrustedClientToken=$_token'
          '&ConnectionId=${_uuidHex()}'
          '&Sec-MS-GEC=${_gec()}'
          '&Sec-MS-GEC-Version=$_gecVersion';
      final ws = await _EdgeWs.connect(path);
      _ws = ws;
      _armIdleClose();
      return ws;
    } finally {
      _wsOpening = null;
    }
  }

  /// 90 سیکنڈ بے کار رہے تو کنکشن خود بند — بیٹری/وسائل کی بچت۔
  void _armIdleClose() {
    _wsIdleTimer?.cancel();
    _wsIdleTimer = Timer(const Duration(seconds: 90), () {
      final ws = _ws;
      _ws = null;
      if (ws != null) unawaited(ws.close());
    });
  }

  void _dropConnection(_EdgeWs ws) {
    if (identical(_ws, ws)) {
      _ws = null;
      _wsIdleTimer?.cancel();
    }
    unawaited(ws.close());
  }

  /// ایپ کھلتے ہی پس منظر میں کنکشن گرم کر دو تاکہ پہلا ٹیپ «ٹھنڈا»
  /// (DNS+TLS+اپ گریڈ والا) نہ ہو۔ کوئی آواز نہیں چلتی، ناکامی خاموش۔
  Future<void> warmUp() async {
    try {
      _gec();
      await _connection();
    } catch (_) {}
  }

  /// مشترکہ کنکشن پر ایک وقت میں ایک ہی ترکیب — دو درخواستوں کے فریم
  /// آپس میں نہ ملیں، اس لیے قطار لازمی ہے۔
  Future<Uint8List> _synthesizeQueued(String chunk, String lang) {
    final run = _synthLock.then((_) => _synthesize(chunk, lang));
    _synthLock = run.then<void>((_) {}, onError: (Object _) {});
    return run;
  }

  String get _rate {
    final pct = ((settings.speechRate - 1) * 100).round();
    return pct >= 0 ? '+$pct%' : '$pct%';
  }

  Future<void> stop() async {
    _session++;
    speakingId.value = null;
    try {
      await _player.stop();
    } catch (_) {}
  }

  /// وہی متن دوبارہ دبائیں تو رک جائیں، ورنہ بولنا شروع کریں۔
  /// [lang]: 'fa' | 'ar' | 'en' | 'ur' — آواز اسی زبان کی لگے گی۔
  Future<void> toggle(String text, {String? id, String lang = _appLang}) async {
    final key = id ?? text;
    if (speakingId.value == key) {
      await stop();
      return;
    }
    await speak(text, id: key, lang: lang);
  }

  Future<void> speak(String text, {String? id, String lang = _appLang}) async {
    final clean = text.trim();
    if (clean.isEmpty) return;
    recitation._stopInternal();
    try {
      await _player.stop();
    } catch (_) {}
    final session = ++_session;
    speakingId.value = id ?? clean;
    try {
      final chunks = splitForSpeech(clean);
      // اگلا ٹکڑا موجودہ کے چلتے ہوئے پس منظر میں تیار رہے — پہلے اگلا
      // ٹکڑا پچھلے کے ختم ہونے کے بعد بننا شروع ہوتا تھا، اس لیے لمبے
      // متن میں ہر ٹکڑے کے بیچ پوری ترکیب جتنی خاموشی آ جاتی تھی۔
      Future<File>? next;
      Future<File> prepare(String c) async {
        // کیش میں ہو تو بغیر نیٹ ورک کے؛ نہ ہو تو آن لائن بنا کر کیش
        // میں محفوظ کریں تاکہ اگلی بار آف لائن چلے۔
        final file = await _ttsCacheFile(_voiceFor(lang), _rate, c);
        if (!await file.exists()) {
          final bytes = await _synthesizeQueued(c, lang);
          try {
            await file.writeAsBytes(bytes, flush: true);
          } catch (_) {}
        }
        return file;
      }

      if (chunks.isNotEmpty) {
        next = prepare(chunks.first);
        next.ignore();
      }
      for (var i = 0; i < chunks.length; i++) {
        if (session != _session) return;
        final file = await next!;
        if (session != _session) return;
        if (i + 1 < chunks.length) {
          next = prepare(chunks[i + 1]);
          next.ignore();
        }
        await _playAndWait(DeviceFileSource(file.path), session);
      }
    } finally {
      if (session == _session) speakingId.value = null;
    }
  }

  Future<void> _playAndWait(Source source, int session) async {
    var completed = false;
    final sub = _player.onPlayerComplete.listen((_) => completed = true);
    try {
      await _player.play(source);
      while (!completed && session == _session) {
        await Future.delayed(const Duration(milliseconds: 120));
        final st = _player.state;
        if (st == PlayerState.stopped || st == PlayerState.completed) break;
      }
    } finally {
      await sub.cancel();
      if (session != _session) {
        try {
          await _player.stop();
        } catch (_) {}
      }
    }
  }

  /// آخر کی سطری علامات ہٹا کر متن دو — ان علامات کی اپنی کوئی آواز
  /// نہیں ہوتی، مگر ان کی موجودگی انجن کو وقف کی صورت پر مجبور کرتی ہے۔
  String _stripTrailingPunct(String s) {
    var out = s.trim();
    while (out.isNotEmpty && '.۔…؟?!؛،,»"'.contains(out[out.length - 1])) {
      out = out.substring(0, out.length - 1).trim();
    }
    return out;
  }

  /// کیا یہ عربی ٹکڑا تنوین والے لفظ پر ختم ہوتا ہے؟
  bool _endsWithTanwinWord(String chunk) {
    final s = _stripTrailingPunct(chunk);
    if (s.isEmpty) return false;
    bool isTanwin(int c) => c >= 0x064B && c <= 0x064D;
    final last = s.codeUnitAt(s.length - 1);
    if (isTanwin(last)) return true;
    // فتحتین اکثر الف/الف مقصورہ پر لکھی جاتی ہے (كِتَابًا) — تنوین اس
    // سے پہلے والے حرف پر ہوتی ہے۔
    if ((last == 0x0627 || last == 0x0649) && s.length >= 2) {
      return isTanwin(s.codeUnitAt(s.length - 2));
    }
    return false;
  }

  Future<Uint8List> _synthesize(String chunk, String lang) async {
    // عربی تنوین کی اصلاح (Ayesh کی رپورٹ، 24 نومبر 2026): ٹکڑا تنوین
    // والے لفظ پر ختم ہو تو Edge انجن اسے وقف کی صورت میں پڑھتا ہے —
    // آخری حرف جزم کے ساتھ، تنوین غائب (جانچ میں تصدیق شدہ: اکیلا لفظ
    // اور بغیر تنوین والا لفظ بالکل ایک جتنی لمبی آواز دیتے ہیں)۔
    // حل: آخر میں «وَ» جوڑ کر ترکیب کرواؤ تاکہ آخری لفظ وصل کی صورت
    // میں پڑھا جائے، پھر WordBoundary کے وقت سے «وَ» کا حصہ کاٹ دو۔
    if (lang == 'ar' && _endsWithTanwinWord(chunk)) {
      try {
        return await _synthesizeWithTail(chunk, lang);
      } catch (_) {
        // اصلاح ناکام ہو تو عام (وقف والی) ترکیب ہی سہی — آواز تو آئے۔
      }
    }
    return _synthesizePlain(chunk, lang);
  }

  /// تنوین والے ٹکڑے کی «وَ» والی ترکیب + آڈیو کی کٹائی۔
  Future<Uint8List> _synthesizeWithTail(String chunk, String lang) async {
    _EdgeWs? ws;
    try {
      ws = await _connection();
      final base = _stripTrailingPunct(chunk);
      final r = await _synthesizeOn(ws, '$base وَ', lang, wantBoundaries: true);
      final cut = _trimPoint(r.bytes, r.lastBoundaryTicks);
      if (cut == null) throw StateError('trim boundary missing');
      return Uint8List.sublistView(r.bytes, 0, cut);
    } catch (_) {
      if (ws != null) _dropConnection(ws);
      rethrow;
    }
  }

  /// آخری WordBoundary («وَ» کا آغاز) سے آڈیو کاٹنے کی جگہ (بائٹس میں)۔
  /// سرحدی گھڑی اور MP3 سلسلے کے درمیان ~100ms کی فطری تاخیر (انکوڈر
  /// ڈیلے) sandbox جانچ میں ناپی گئی — اسی لیے 100ms کا اضافہ؛ کٹائی
  /// MP3 فریم (48kbps/24kHz = 144 بائٹ) کی حد پر، فریم sync جانچ کر۔
  int? _trimPoint(Uint8List bytes, int? boundaryTicks) {
    if (boundaryTicks == null) return null;
    final cutMs = boundaryTicks ~/ 10000 + 100;
    var cut = cutMs * 6; // 48kbps = 6 بائٹ فی ملی سیکنڈ
    cut -= cut % 144;
    while (cut > 0 &&
        (cut + 1 >= bytes.length ||
            bytes[cut] != 0xFF ||
            (bytes[cut + 1] & 0xE0) != 0xE0)) {
      cut -= 144;
    }
    if (cut <= 0 || cut + 1 >= bytes.length) return null;
    return cut;
  }

  Future<Uint8List> _synthesizePlain(String chunk, String lang) async {
    _EdgeWs? ws;
    try {
      ws = await _connection();
      return (await _synthesizeOn(ws, chunk, lang)).bytes;
    } catch (_) {
      // کنکشن خراب/پرانا ہو تو پھینک کر نئے کنکشن پر ایک بار پھر؛
      // گھڑی کا فرق ہو تو سرور کے وقت سے ملا کر بھی یہی کوشش ہو گی۔
      if (ws != null) _dropConnection(ws);
      if (!_skewTried) {
        _skewTried = true;
        await _refreshSkew();
      }
      _EdgeWs? fresh;
      try {
        fresh = await _connection();
        return (await _synthesizeOn(fresh, chunk, lang)).bytes;
      } catch (_) {
        if (fresh != null) _dropConnection(fresh);
        rethrow;
      }
    }
  }

  Future<void> _refreshSkew() async {
    try {
      final client = HttpClient();
      final req = await client.getUrl(Uri.parse(
          'https://speech.platform.bing.com/consumer/speech/synthesize/readaloud/voices/list?trustedclienttoken=$_token'));
      req.headers.set('User-Agent', _userAgent);
      final res = await req.close();
      final date = res.headers.value('date');
      await res.drain<void>();
      client.close();
      if (date != null) {
        final server = HttpDate.parse(date).toUtc();
        _skewSeconds = server.difference(DateTime.now().toUtc()).inSeconds;
      }
    } catch (_) {}
  }

  /// دیے گئے (مشترکہ) کنکشن پر ایک ٹکڑے کی ترکیب — کنکشن یہاں نہ
  /// کھلتا ہے نہ بند ہوتا؛ وہ TtsService کے پاس زندہ رہتا ہے۔
  Future<({Uint8List bytes, int? lastBoundaryTicks})> _synthesizeOn(
      _EdgeWs ws, String chunk, String lang,
      {bool wantBoundaries = false}) async {
    try {
      final date = _dateString();
      ws.sendText('X-Timestamp:$date\r\n'
          'Content-Type:application/json; charset=utf-8\r\n'
          'Path:speech.config\r\n\r\n'
          '{"context":{"synthesis":{"audio":{"metadataoptions":'
          '{"sentenceBoundaryEnabled":"true","wordBoundaryEnabled":"$wantBoundaries"},'
          '"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}\r\n');
      final ssml = "<speak version='1.0' "
          "xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='${_xmlLang(lang)}'>"
          "<voice name='${_voiceFor(lang)}'>"
          "<prosody pitch='+0Hz' rate='$_rate' volume='+0%'>"
          '${_escapeXml(chunk)}</prosody></voice></speak>';
      ws.sendText('X-RequestId:${_uuidHex()}\r\n'
          'Content-Type:application/ssml+xml\r\n'
          'X-Timestamp:${date}Z\r\n'
          'Path:ssml\r\n\r\n$ssml');
      final audio = BytesBuilder(copy: false);
      int? lastBoundaryTicks;
      final done = Completer<void>();
      final sub = ws.messages.listen(
        (dynamic data) {
          if (data is List<int>) {
            if (data.length < 2) return;
            final headerLen = (data[0] << 8) | data[1];
            if (data.length < 2 + headerLen) return;
            final headers = utf8.decode(data.sublist(2, 2 + headerLen),
                allowMalformed: true);
            if (headers.contains('Path:audio')) {
              audio.add(data.sublist(2 + headerLen));
            }
          } else if (data is String) {
            if (data.contains('Path:audio.metadata')) {
              // آخری لفظ کی سرحد (ٹِکس، 100ns اکائی) — تنوین والی
              // ترکیب میں «وَ» کاٹنے کے لیے۔
              try {
                final body = data.split('\r\n\r\n').last;
                final meta = jsonDecode(body) as Map<String, dynamic>;
                for (final m in (meta['Metadata'] as List? ?? const [])) {
                  if (m is Map && m['Type'] == 'WordBoundary') {
                    final off = (m['Data'] as Map?)?['Offset'];
                    if (off is num) lastBoundaryTicks = off.toInt();
                  }
                }
              } catch (_) {}
            }
            if (data.contains('Path:turn.end')) {
              if (!done.isCompleted) done.complete();
            }
          }
        },
        onError: (Object e) {
          if (!done.isCompleted) done.completeError(e);
        },
        onDone: () {
          if (!done.isCompleted) done.complete();
        },
      );
      await done.future.timeout(const Duration(seconds: 45));
      await sub.cancel();
      final bytes = audio.takeBytes();
      if (bytes.isEmpty) throw StateError('no audio received');
      return (bytes: bytes, lastBoundaryTicks: lastBoundaryTicks);
    } catch (_) {
      // اس کنکشن پر مانگ ادھوری رہی — اسے خراب شمار کرو تاکہ اگلی
      // کوشش (اوپر والی) نئے کنکشن پر ہو۔
      ws.markBroken();
      rethrow;
    }
  }
}

final TtsService tts = TtsService.instance;

// ---------------- قرآن کی تلاوت (اصل قاری، CDN اسٹریمنگ) ----------------
class RecitationService {
  RecitationService._();
  static final RecitationService instance = RecitationService._();

  /// اس وقت چلنے والی آیت کا عالمی نمبر (1–6236)۔
  final ValueNotifier<int?> playingAyah = ValueNotifier<int?>(null);
  StreamSubscription<void>? _sub;

  void _stopInternal() {
    playingAyah.value = null;
    _sub?.cancel();
    _sub = null;
  }

  Future<void> stop() async {
    _stopInternal();
    try {
      await _player.stop();
    } catch (_) {}
  }

  Future<void> toggle(int globalAyah) async {
    if (playingAyah.value == globalAyah) {
      await stop();
      return;
    }
    await play(globalAyah);
  }

  Future<void> play(int globalAyah) async {
    await tts.stop();
    _stopInternal();
    playingAyah.value = globalAyah;
    _sub = _player.onPlayerComplete.listen((_) {
      if (playingAyah.value == globalAyah) playingAyah.value = null;
    });
    try {
      final file = await _ayahCacheFile(globalAyah);
      if (await file.exists()) {
        // پہلے سنی ہوئی آیت — کیش سے، آف لائن بھی چلتی ہے
        await _player.play(DeviceFileSource(file.path));
      } else {
        final url =
            'https://cdn.islamic.network/quran/audio/128/ar.alafasy/$globalAyah.mp3';
        await _player.play(UrlSource(url));
        // ساتھ ساتھ کیش میں محفوظ کریں (اگلی بار آف لائن چلے گی)
        unawaited(_downloadToCache(file, url));
      }
    } catch (_) {
      if (playingAyah.value == globalAyah) playingAyah.value = null;
      rethrow;
    }
  }

  Future<void> _downloadToCache(File file, String url) async {
    try {
      final resp =
          await http.get(Uri.parse(url)).timeout(const Duration(seconds: 60));
      if (resp.statusCode == 200 && resp.bodyBytes.isNotEmpty) {
        await file.writeAsBytes(resp.bodyBytes, flush: true);
      }
    } catch (_) {
      // کیش نہ بھی بنے تو اسٹریمنگ چلتی رہتی ہے
    }
  }
}

final RecitationService recitation = RecitationService.instance;

// ---------------- اسپیکر بٹن ----------------
/// لفظ/جملے کے لیے اسپیکر بٹن — چل رہا ہو تو رکاوٹ (اسٹاپ) بن جاتا ہے۔
class SpeakButton extends StatelessWidget {
  final String text;
  final String? id;
  final double size;
  final Color? color;

  /// متن کی زبان: 'fa' | 'ar' | 'en' | 'ur' (انگریزی کے لیے 'en'، اردو کے لیے 'ur' دیں)۔
  final String lang;

  const SpeakButton({
    super.key,
    required this.text,
    this.id,
    this.size = 22,
    this.color,
    this.lang = _appLang,
  });

  @override
  Widget build(BuildContext context) {
    final key = id ?? (lang == _appLang ? text : '$lang:$text');
    return ValueListenableBuilder<String?>(
      valueListenable: tts.speakingId,
      builder: (context, speaking, _) {
        final isPlaying = speaking == key;
        return IconButton(
          tooltip: isPlaying ? 'روکیں' : 'آواز سنیں',
          icon: Icon(
            isPlaying ? Icons.stop_circle_rounded : Icons.volume_up_rounded,
            size: size,
            color: color ?? Theme.of(context).colorScheme.primary,
          ),
          onPressed: text.trim().isEmpty
              ? null
              : () async {
                  try {
                    await tts.toggle(text, id: key, lang: lang);
                  } catch (_) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text('انٹرنیٹ سے آواز نہیں آ سکی')),
                      );
                    }
                  }
                },
        );
      },
    );
  }
}

/// لمبے متن (مثلاً AI جواب) کے لیے «سنوائیں» بٹن۔
class SpeakAnswerButton extends StatelessWidget {
  final String text;
  final String lang;
  const SpeakAnswerButton({super.key, required this.text, this.lang = _appLang});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<String?>(
      valueListenable: tts.speakingId,
      builder: (context, speaking, _) {
        final key = lang == _appLang ? text : '$lang:$text';
        final isPlaying = speaking == key;
        return OutlinedButton.icon(
          icon: Icon(
              isPlaying ? Icons.stop_circle_rounded : Icons.volume_up_rounded,
              size: 19),
          label: Text(isPlaying ? 'روکیں' : 'سنوائیں'),
          onPressed: text.trim().isEmpty
              ? null
              : () async {
                  try {
                    await tts.toggle(text, id: key, lang: lang);
                  } catch (_) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text('انٹرنیٹ سے آواز نہیں آ سکی')),
                      );
                    }
                  }
                },
        );
      },
    );
  }
}

// ---------------- ترتیبات: محفوظ آوازیں ----------------
/// محفوظ آوازوں کا سائز اور «صاف کریں» بٹن (ترتیبات میں لگتا ہے)۔
class AudioCacheTile extends StatefulWidget {
  const AudioCacheTile({super.key});

  @override
  State<AudioCacheTile> createState() => _AudioCacheTileState();
}

class _AudioCacheTileState extends State<AudioCacheTile> {
  int _bytes = 0;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  Future<void> _reload() async {
    final b = await audioCacheSizeBytes();
    if (mounted) setState(() => _bytes = b);
  }

  Future<void> _clear() async {
    await tts.stop();
    await recitation.stop();
    await clearAudioCache();
    await _reload();
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('محفوظ آوازیں صاف ہو گئیں')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final mb = (_bytes / (1024 * 1024)).toStringAsFixed(1);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 2, 16, 12),
      child: Row(
        children: [
          Expanded(child: Text('محفوظ آوازیں: $mb MB')),
          TextButton.icon(
            onPressed: _bytes == 0 ? null : _clear,
            icon: const Icon(Icons.delete_sweep_rounded, size: 19),
            label: const Text('محفوظ آوازیں صاف کریں'),
          ),
        ],
      ),
    );
  }
}
